#include <stdlib.h>
#include <iostream>

#include "ArbolAA.h"
#include "nodoAA.h"
#include "ArbolAA.cpp"

using namespace std;

int main(){
    ArbolAAInventarios aux1;
    
    aux1.crearListaDeInventarios();
    
    InordenR(aux1.raiz);
    return 0;
}
