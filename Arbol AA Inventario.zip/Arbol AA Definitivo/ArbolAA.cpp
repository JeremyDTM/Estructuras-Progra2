#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fstream>

#include "ArbolAA.h"
#include "nodoAA.h"

using namespace std;


pnodoAAInventarios insertar(int pCodSuper, int pCodProducto, string pNombre, int pCantProducto, int pPrecioUnitario,nodoAAInventarios *raiz){
	if(raiz == NULL){
		raiz = new nodoAAInventarios(pCodSuper,pCodProducto, pNombre, pCantProducto, pPrecioUnitario);
		return raiz;
	}
	else if(pCodProducto <= raiz->codProducto){
		raiz->Hizq = insertar(pCodSuper,pCodProducto, pNombre, pCantProducto, pPrecioUnitario,raiz->Hizq);
	}
	else if(pCodProducto > raiz->codProducto){
		raiz->Hder = insertar(pCodSuper,pCodProducto, pNombre, pCantProducto, pPrecioUnitario,raiz->Hder);
	}
	raiz= torsion(raiz);
	raiz = division(raiz);
	return raiz;
}

void InordenR(nodoAAInventarios *R){

    if(R==NULL){
        return;
    }else{
        InordenR(R->Hizq);
        cout<<R->codProducto<<" - ";
        InordenR(R->Hder);
    }
}

pnodoAAInventarios torsion(nodoAAInventarios *T){
	if(T == NULL){
		return NULL;
	}
	else if(T->Hizq == NULL){
		return T;
	}
	else if(T->Hizq->nivel == T->nivel){
		pnodoAAInventarios L;
		L = T->Hizq;
		T->Hizq = L->Hder;
		L->Hder = T;
		return L;
	}
	else{
		return T;
	}
}

pnodoAAInventarios division(nodoAAInventarios *T){
	if(T == NULL){
		return NULL;
	}
	else if(T->Hder == NULL){
		return T;
	}
	else if(T->Hder->Hder == NULL){
		return T;
	}
	else if(T->nivel == T->Hder->Hder->nivel){
		pnodoAAInventarios R;
		R = T->Hder;
		T->Hder = R->Hizq;
		R->Hizq = T;
		R->nivel = R->nivel + 1;
		return R;
	}
	else{
		return T;
	}
}

void ArbolAAInventarios::crearListaDeInventarios(){
	ifstream archivo;
	string texto;
	string msg = "";
	int codProducto = 0;
	int codSuper = 0;
	string nombre = "";
	int cantProducto = 0;

	archivo.open("Inventariodatos.txt",ios::in);

	if(archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}

	while(!archivo.eof()){
        msg = "";
        codProducto = 0;
        codSuper = 0;
        nombre = "";
        cantProducto = 0;
		getline(archivo,texto);
		//cout<<texto<<endl;
		for(int i=0;i<=texto.size();i++){
          if(texto[i] != ';')
		    msg += texto[i];
          else if(codSuper == 0){
            codSuper = atoi(msg.c_str());
            //cout<<codCiudad<<endl;
            msg = "";
          }
          else if(codProducto == 0){
            codProducto = atoi(msg.c_str());
            msg = "";
          }
          else if(nombre == ""){
            nombre = msg;
            msg = "";
          }
          else if(cantProducto == 0){
            cantProducto = atoi(msg.c_str());
            msg = "";
          }
		}

		raiz = insertar(codSuper,codProducto,nombre,cantProducto,atoi(msg.c_str()),raiz);
		//cout<<msg<<endl;
	}
	archivo.close();
}
