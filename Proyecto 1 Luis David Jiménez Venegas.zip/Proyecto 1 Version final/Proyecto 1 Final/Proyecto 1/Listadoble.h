#ifndef listadoble_H_INCLUDED
#define listadoble_H_INCLUDED
#include "listaSimple.h"
#include <iostream>
#include<string.h>
#include<fstream>

using namespace std;

class nodoDoble {
   public:
    nodoDoble(string pCodCiudad, string pCodSuper, string pNombre)
    {
       codCiudad = pCodCiudad;
       codSuper = pCodSuper;
       nombre = pNombre;
       siguiente = NULL;
       anterior =NULL;
    }

nodoDoble(string pCodCiudad, string pCodSuper, string pNombre, nodoDoble * signodoDoble)
    {
       codCiudad = pCodCiudad;
       codSuper = pCodSuper;
       nombre = pNombre;
       siguiente = signodoDoble;
    }

   public:
    string codCiudad;
    string codSuper;
    string nombre;
    nodoDoble *siguiente;
    nodoDoble *anterior;


   friend class listaD;
};

typedef nodoDoble *pnodoDoble;

class listaD {
   public:
    listaD() { primero = actual = NULL; }

    void InsertarInicioListaDoble(string pCodCiudad, string pCodSuper, string pNombre);
    void InsertarFinalListaDoble(string pCodCiudad, string pCodSuper, string pNombre,pnodoSimple auxListaCiudades);
    //void InsertarPosListaDoble(string pCodCiudad, string pCodSuper, string pNombre);
    /*void EliminarInicioListaDoble();
    void EliminarFinalListaDoble();
    void EliminarPosListaDoble(int pos);*/
    bool ListaVaciaListaDoble() { return primero == NULL; }
    void ImprimirListaDoble();
    //void BorrarListaDoble(int v);
    void MostrarListaDoble();
    void SiguienteListaDoble();
    void PrimeroListaDoble();
    void UltimoListaDoble();
    /*void BorrarFinalListaDoble();
    void BorrarInicioListaDoble();
    void borrarPosicionListaDoble(int pos);*/
    int largoListaListaDoble();
    void crearListaSupermercados(pnodoSimple auxListaCiudades);

   public:
    pnodoDoble primero;
    pnodoDoble actual;
};

int listaD::largoListaListaDoble(){
    int cont=0;

    pnodoDoble aux;
    aux = primero;
    if(ListaVaciaListaDoble()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }
}

void listaD::InsertarInicioListaDoble(string pCodCiudad, string pCodSuper, string pNombre)
{
   if (ListaVaciaListaDoble())
     primero = new nodoDoble(pCodCiudad, pCodSuper, pNombre);
   else
   {
     primero=new nodoDoble (pCodCiudad, pCodSuper, pNombre, primero);
     primero->siguiente->anterior=primero;
   }
}

void listaD::InsertarFinalListaDoble(string pCodCiudad, string pCodSuper, string pNombre,pnodoSimple auxListaCiudades)
{

   pnodoSimple auxListaCiudadesAux;
   auxListaCiudadesAux = auxListaCiudades;
   if (ListaVaciaListaDoble())
     {primero = new nodoDoble(pCodCiudad, pCodSuper, pNombre);}
   else{
      auxListaCiudadesAux = auxListaCiudades;
      while(auxListaCiudadesAux->siguiente != NULL){
        if(auxListaCiudadesAux->codCiudad == pCodCiudad){break;}
        else if(auxListaCiudadesAux->siguiente->siguiente == NULL){return;}
        auxListaCiudadesAux = auxListaCiudadesAux->siguiente;
      }
      pnodoDoble aux = primero;
        while ( aux->siguiente != NULL){
          if(aux->codSuper == pCodSuper){return;}
          aux= aux->siguiente;}
        aux->siguiente=new nodoDoble(pCodCiudad, pCodSuper, pNombre);
        aux->siguiente->anterior=aux;
      }
}

void listaD::MostrarListaDoble()
{
   nodoDoble *aux;

   aux = primero;
   while(aux) {
      cout <<aux->codCiudad<<";"<<aux->codSuper<<";"<<aux->nombre<<"-> ";
      aux = aux->siguiente;
   }
   cout << endl;
}

void listaD::SiguienteListaDoble()
{
   if(actual) actual = actual->siguiente;
}

void listaD::PrimeroListaDoble(){
   actual = primero;
}

void listaD::UltimoListaDoble()
{
   actual = primero;
   if(!ListaVaciaListaDoble())
      while(actual->siguiente) SiguienteListaDoble();
}

void listaD::crearListaSupermercados(pnodoSimple auxListaCiudades)
{
    ifstream archivo;
	string texto;

	string msg = "";
	string codCiudad = "";
	string codSuper = "";

	archivo.open("supermercado.txt",ios::in);

	if(archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}

	while(!archivo.eof()){
        msg = "";
        codCiudad = "";
        codSuper = "";
		getline(archivo,texto);
		for(int i=0;i<=texto.size();i++){
          if(texto[i] != ';')
		    msg += texto[i];
          else if(codCiudad == ""){
            codCiudad = msg;
            msg = "";
          }
          else if(codSuper == ""){
            codSuper = msg;
            msg = "";
          }
        }
		InsertarFinalListaDoble(codCiudad,codSuper,msg,auxListaCiudades);
	}
	archivo.close();
}

#endif // listadoble_H_INCLUDED
