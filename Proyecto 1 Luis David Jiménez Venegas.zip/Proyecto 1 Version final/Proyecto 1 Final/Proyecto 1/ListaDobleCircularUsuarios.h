#ifndef LISTADOBLECIRCULARUSUARIOS_H_INCLUDED
#define LISTADOBLECIRCULARUSUARIOS_H_INCLUDED

#include "ListaDobleCircularInventario.h"
#include <iostream>

using namespace std;

class nodoDobleCircularUsuarios {
   public:
    nodoDobleCircularUsuarios(string pCodCiudad, string pCedula, string pNombre, string pTelefono, int pTipo)
    {
       codCiudad = pCodCiudad;
       cedula = pCedula;
       nombre = pNombre;
       telefono = pTelefono;
       tipo = pTipo;
       siguiente = NULL;
       anterior =NULL;
       carrito = NULL;
    }

   nodoDobleCircularUsuarios(string pCodCiudad, string pCedula, string pNombre, string pTelefono, int pTipo, nodoDobleCircularUsuarios * signodoDobleCircularUsuarios)
    {
       codCiudad = pCodCiudad;
       cedula = pCedula;
       nombre = pNombre;
       telefono = pTelefono;
       tipo = pTipo;
       siguiente = signodoDobleCircularUsuarios;
       carrito = NULL;
    }

 public:
    string codCiudad;
    string cedula;
    string nombre;
    string telefono;
    int tipo;
    nodoDobleCircularUsuarios *siguiente;
    nodoDobleCircularUsuarios *anterior;
    nodoDobleCircularInventario *carrito;


   friend class listaDCUsuarios;
};
typedef nodoDobleCircularUsuarios *pnodoDobleCircularUsuarios;
#endif // LISTADOBLECIRCULARUSUARIOS_H_INCLUDED
