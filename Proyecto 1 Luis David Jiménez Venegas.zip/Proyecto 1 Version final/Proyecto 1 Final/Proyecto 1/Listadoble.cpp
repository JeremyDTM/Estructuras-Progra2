
#include <iostream>
using namespace std;

class nodo {
   public:
    nodo(int v)
    {
       valor = v;
       siguiente = NULL;
       anterior =NULL;
    }

nodo(int v, nodo * signodo)
    {
       valor = v;
       siguiente = signodo;
    }

   private:
    int valor;
    nodo *siguiente;
    nodo *anterior;
    nodo *actual;


   friend class listaD;
};

typedef nodo *pnodo;

class listaD {
   public:
    listaD() { primero = actual = NULL; }
    ~listaD();

    void InsertarInicioListaDoble(int v);
    void InsertarFinalListaDoble(int v);
    void InsertarPosDoble(int v, int pos);
    void EliminarInicioListaDoble();
    void EliminarFinalListaDoble();
    void EliminarPosListaDoble(int pos);
    bool ListaVaciaListaDoble() { return primero == NULL; }
    void ImprimirListaDoble();
    void BorrarListaDoble(int v);
    void MostrarListaDoble();
    void SiguienteListaDoble();
    void PrimeroListaDoble();
    void UltimoListaDoble();
    void BorrarFinalListaDoble();
    void BorrarInicioListaDoble();
    void borrarPosicionListaDoble(int pos);
    int largoListaListaDoble();

   private:
    pnodo primero;
    pnodo actual;
};

listaD::~listaD()
{
   pnodo aux;

   while(primero) {
      aux = primero;
      primero = primero->siguiente;
      delete aux;
   }
   actual = NULL;
}

int listaD::largoListaListaDoble(){
    int cont=0;

    pnodo aux;
    aux = primero;
    if(ListaVaciaListaDoble()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }
}

void listaD::InsertarInicioListaDoble(int v)
{
   if (ListaVaciaListaDoble())
     primero = new nodo(v);
   else
   {
     primero=new nodo (v,primero);
     primero->siguiente->anterior=primero;
   }
}

void listaD::InsertarFinalListaDoble(int v)
{
   if (ListaVaciaListaDoble())
     primero = new nodo(v);
   else
     { pnodo aux = primero;
        while ( aux->siguiente != NULL)
          aux= aux->siguiente;
        aux->siguiente=new nodo(v);
        aux->siguiente->anterior=aux;
      }
}


void listaD::InsertarPosListaDoble(int v,int pos)
{
   if (ListaVaciaListaDoble())
     primero = new nodo(v);
   else{
        if(pos <=1)
          InsertarInicioListaDoble(v);
        else
        {
             pnodo aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= NULL)){
                   i++;
                   aux=aux->siguiente;
             }
             pnodo nuevo= new nodo(v);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             aux->siguiente->anterior=aux;
             nuevo->siguiente->anterior=nuevo;
        }
        }
}

void listaD::BorrarFinalListaDoble()
{
    if (ListaVaciaListaDoble()){
     cout << "No hay elementos en la lista:" << endl;

   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodo aux = primero;
                while (aux->siguiente->siguiente != NULL)
                {
                    aux = aux->siguiente;
                }

              pnodo temp = aux->siguiente;
              aux->siguiente= NULL;


                delete temp;
            }
        }
}

void listaD::BorrarInicioListaDoble()
{
    if (ListaVaciaListaDoble()){
     cout << "No hay elementos en la lista:" << endl;

   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodo aux = primero;
                primero=primero->siguiente;
                delete aux;
            }
        }
}



void listaD:: borrarPosicionListaDoble(int pos)
{
     if(ListaVaciaListaDoble())
     {
              cout << "Lista vacia" <<endl;
     }
     else
     {
        if((pos>largoListaListaDoble())||(pos<0))
        {
        cout << "Error en posicion" << endl;
        }
        else
        {
        if(pos==1)
           BorrarInicioListaDoble();
        else
        {
          if (pos == largoListaListaDoble())
             BorrarFinalListaDoble();
          else
          {
            int cont=2;
            pnodo aux=  primero;
            while(cont<pos)
            {
             aux=aux->siguiente;
             cont++;
            }
            pnodo temp=aux->siguiente;
            aux->siguiente=aux->siguiente->siguiente;
            aux->siguiente->anterior=aux;
            delete temp;
          }//else
        }//else
      }//else
    }//else
}


void listaD::MostrarListaDoble()
{
   nodo *aux;

   aux = primero;
   while(aux) {
      cout << aux->valor << "-> ";
      aux = aux->siguiente;
   }
   cout << endl;
}

void listaD::SiguienteListaDoble()
{
   if(actual) actual = actual->siguiente;
}

void listaD::PrimeroListaDoble()
{
   actual = primero;
}

void listaD::UltimoListaDoble()
{
   actual = primero;
   if(!ListaVaciaListaDoble())
      while(actual->siguiente) SiguienteListaDoble();
}

/*int main()
{
   listaD Lista;



   Lista.InsertarInicio(20);
   Lista.InsertarInicio(2);
   Lista.InsertarFinal(10);
   Lista.InsertarFinal(11);
   Lista.InsertarPos(5, 3);
   Lista.InsertarPos(6, 4);
   Lista.InsertarInicio(30);
   Lista.InsertarInicio(1);
   Lista.InsertarFinal(5);
   Lista.InsertarPos(1, 3);
   Lista.Mostrar();
   //Lista.BorrarInicio();
   Lista.Mostrar();
  // Lista.BorrarFinal();
   Lista.Mostrar();
   Lista.borrarPosicion(10);
   Lista.Mostrar();

   cout << "Lista de elementos:" << endl;
   Lista.Primero();
   Lista.Primero();
   Lista.UltimoListaDoble();

//   Lista.BorrarFinal();
   //Lista.Borrar(15);
  // Lista.Borrar(45);
   //Lista.Borrar(30);
   //Lista.Borrar(40);

   Lista.Mostrar();

   cin.get();
   return 0;
}*/
