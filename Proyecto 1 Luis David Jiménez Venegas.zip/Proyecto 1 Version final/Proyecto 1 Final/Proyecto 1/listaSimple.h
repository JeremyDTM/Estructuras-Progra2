#ifndef listaSimple_H_INCLUDED
#define listaSimple_H_INCLUDED
#include <iostream>
#include<string.h>
#include<fstream>
using namespace std;

class nodoSimple {
   public:
    nodoSimple(string pCodCiudad, string pNombre)
    {
       codCiudad = pCodCiudad;
       nombre = pNombre;
       siguiente = NULL;
    }

nodoSimple(string pCodCiudad,string pNombre, nodoSimple * signodoSimple)
    {
       codCiudad = pCodCiudad;
       nombre = pNombre;
       siguiente = signodoSimple;
    }

   public:
    string codCiudad;
    string nombre;
    nodoSimple *siguiente;


   friend class lista;
};

typedef nodoSimple *pnodoSimple;

class lista {
   public:
    lista() { primero = actual = NULL; }

    void InsertarInicioListaSimple(string pCodCiudad, string pNombre);
    void InsertarFinalListaSimple(string pCodCiudad, string pNombre);
    /*void InsertarPosListaSimple(int v, int pos);
    void EliminarInicioListaSimple();
    void EliminarFinalListaSimple();
    void EliminarPosListaSimple(int pos);*/
    bool ListaVaciaListaSimple() { return primero == NULL; }
    void ImprimirListaSimple();
    //void BorrarListaSimple(int v);
    void MostrarListaSimple();
    void SiguienteListaSimple();
    void PrimeroListaSimple();
    void UltimoListaSimple();
    /*void BorrarFinalListaSimple();
    void BorrarInicioListaSimple();
    void borrarPosicionListaSimple(int pos);*/
    int largoListaListaSimple();
    void crearListaCiudades();

   public:
    pnodoSimple primero;
    pnodoSimple actual;
};

int lista::largoListaListaSimple(){
    int cont=0;

    pnodoSimple aux;
    aux = primero;
    if(ListaVaciaListaSimple()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }

}

void lista::InsertarInicioListaSimple(string pCodCiudad, string pNombre)
{
   if (ListaVaciaListaSimple())
     primero = new nodoSimple(pCodCiudad, pNombre);
   else
     primero=new nodoSimple (pCodCiudad, pNombre ,primero);
}

void lista::InsertarFinalListaSimple(string pCodCiudad, string pNombre)
{
   if (ListaVaciaListaSimple())
     primero = new nodoSimple(pCodCiudad, pNombre);
   else
     { pnodoSimple aux = primero;
        while ( aux->siguiente != NULL){
          if(aux->codCiudad == pCodCiudad){return;}
          aux= aux->siguiente;}
        aux->siguiente=new nodoSimple(pCodCiudad, pNombre);
      }
}

void lista::MostrarListaSimple()
{
   nodoSimple *aux;

   aux = primero;
   while(aux) {
      cout << aux->codCiudad;
      cout << ";";
      cout << aux->nombre<<"-> ";
      aux = aux->siguiente;
   }
   cout << endl;
}

void lista::SiguienteListaSimple()
{
   if(actual) actual = actual->siguiente;
}

void lista::PrimeroListaSimple()
{
   actual = primero;
}

void lista::UltimoListaSimple()
{
   actual = primero;
   if(!ListaVaciaListaSimple())
      while(actual->siguiente) SiguienteListaSimple();
}

void lista::crearListaCiudades()
{
    ifstream archivo;
	string texto;

	string msg = "";
	string codCiudad = "";

	archivo.open("Ciudad.txt",ios::in);

	if(archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}

	while(!archivo.eof()){
		getline(archivo,texto);
		for(int i=0;i<=texto.size();i++){
          if(texto[i] != ';')
		    msg += texto[i];
          else{
            codCiudad = msg;
            msg = "";
          }
		}
		InsertarFinalListaSimple(codCiudad,msg);
		msg = "";
	}
	archivo.close();
}

#endif // listaSimple_H_INCLUDED

