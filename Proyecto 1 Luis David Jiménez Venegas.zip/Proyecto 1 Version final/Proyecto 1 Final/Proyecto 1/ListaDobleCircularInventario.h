#ifndef LISTADOBLECIRCULARINVENTARIO_H_INCLUDED
#define LISTADOBLECIRCULARINVENTARIO_H_INCLUDED

#include "Listadoble.h"
#include <iostream>


using namespace std;

class nodoDobleCircularInventario {
   public:
    nodoDobleCircularInventario(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario)
    {
       codSuper = pCodSuper;
       codProducto = pCodProducto;
       nombre = pNombre;
       cantidadProducto = pCantidadProducto;
       precioUnitario = pPrecioUnitario;
       siguiente = NULL;
       anterior =NULL;
    }

   nodoDobleCircularInventario(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario, nodoDobleCircularInventario * signodoDobleCircularInventario)
    {
       codSuper = pCodSuper;
       codProducto = pCodProducto;
       nombre = pNombre;
       cantidadProducto = pCantidadProducto;
       precioUnitario = pPrecioUnitario;
       siguiente = signodoDobleCircularInventario;
    }

 public:
    string codSuper;
    string codProducto;
    string nombre;
    int cantidadProducto;
    int precioUnitario;
    nodoDobleCircularInventario *siguiente;
    nodoDobleCircularInventario *anterior;


   friend class listaDCInventario;
};
typedef nodoDobleCircularInventario *pnodoDobleCircularInventario;

class listaDCInventario {
   public:
    listaDCInventario() { primero = actual = NULL; }

    void InsertarInicioListaDobleCircularInventario(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario);
    void InsertarFinalListaDobleCircularInventario(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario,pnodoDoble auxListaSuper);
    /*void InsertarPosListaDobleCircular(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario, int pos);
    void EliminarInicioListaDobleCircular();
    void EliminarFinalListaDobleCircular();
    void EliminarPosListaDobleCircular(int pos);*/
    bool ListaVaciaListaDobleCircularInventario() { return primero == NULL; }
    void ImprimirListaDobleCircularInventario();
    //void BorrarListaDobleCircular(int v);
    void MostrarListaDobleCircularInventario();
    void SiguienteListaDobleCircularInventario();
    void PrimeroListaDobleCircularInventario();
    void UltimoListaDobleCircularInventario();
    /*void BorrarFinalListaDobleCircular();
    void BorrarInicioListaDobleCircular();
    void borrarPosicionListaDobleCircular(int pos);*/
    int largoListaListaDobleCircularInventario();
    void crearListaDeInventarios(pnodoDoble auxListaSuper);
    void consultarPrecioDeProducto(string pCodProducto);
    void consultarSobreUnProducto(string pCodSuper);
    //void agregarAlCarrito(string pCodSuper);

   public:
    pnodoDobleCircularInventario primero;
    pnodoDobleCircularInventario actual;
};


int listaDCInventario::largoListaListaDobleCircularInventario()
{
    int cont=0;

    pnodoDobleCircularInventario aux = primero->siguiente;
    if(ListaVaciaListaDobleCircularInventario())
    {
        return cont;
    }
    else
    {
        while(aux!=primero)
        {
          aux=aux->siguiente;
          cont++;
        }
    return cont;
    }

}

void listaDCInventario::InsertarInicioListaDobleCircularInventario(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario)
{

   if (ListaVaciaListaDobleCircularInventario())
   {
     primero = new nodoDobleCircularInventario(pCodSuper, pCodProducto, pNombre, pCantidadProducto, pPrecioUnitario);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
     pnodoDobleCircularInventario nuevo=new nodoDobleCircularInventario (pCodSuper, pCodProducto, pNombre, pCantidadProducto, pPrecioUnitario);
     nuevo->siguiente=primero;
     nuevo->anterior= primero->anterior;
     primero->anterior->siguiente=nuevo;
     nuevo->siguiente->anterior=nuevo;
     primero= nuevo;
   }
}

void listaDCInventario::InsertarFinalListaDobleCircularInventario(string pCodSuper, string pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario, pnodoDoble auxListaSuper)
{
   if (ListaVaciaListaDobleCircularInventario())
     {
     primero = new nodoDobleCircularInventario(pCodSuper, pCodProducto, pNombre, pCantidadProducto, pPrecioUnitario);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
     pnodoDoble auxListaSuperAux = auxListaSuper;
     while(auxListaSuperAux->siguiente != NULL){
        if(auxListaSuperAux->codSuper == pCodSuper){
            break;
        }
        else if(auxListaSuperAux->siguiente->siguiente == NULL){return;}
        auxListaSuperAux = auxListaSuperAux->siguiente;}
     pnodoDobleCircularInventario aux = primero;
     while ( aux->siguiente != primero){
          if(aux->codProducto == pCodProducto){
            cout<<"El codigo del producto ya existe"<<endl;
            return;
          }
          aux= aux->siguiente;}
     pnodoDobleCircularInventario nuevo = new nodoDobleCircularInventario(pCodSuper, pCodProducto, pNombre, pCantidadProducto, pPrecioUnitario);
     nuevo->anterior = primero->anterior;
     nuevo->siguiente=primero->anterior->siguiente;
     primero->anterior->siguiente=nuevo;
     primero->anterior=nuevo;
    }
}

void listaDCInventario::MostrarListaDobleCircularInventario()
{
   pnodoDobleCircularInventario aux=primero;
   while(aux->siguiente!=primero)
     {
      cout <<aux->codSuper<<";"<<aux->codProducto<<";"<<aux->nombre<<";"<<aux->cantidadProducto<<";"<<aux->precioUnitario<<" -> ";
      aux = aux->siguiente;
     }
     cout<<aux->codSuper<<";"<<aux->codProducto<<";"<<aux->nombre<<";"<<aux->cantidadProducto<<";"<<aux->precioUnitario<<" ->";
     cout<<endl;
}

void listaDCInventario::crearListaDeInventarios(pnodoDoble auxListaSuper)
{
    ifstream archivo;
	string texto;

	string msg = "";
	string codProducto = "";
	string codSuper = "";
	string nombre = "";
	int cantProducto = 0;

	archivo.open("Inventario.txt",ios::in);

	if(archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}

	while(!archivo.eof()){
        msg = "";
        codProducto = "";
        codSuper = "";
        nombre = "";
        cantProducto = 0;
		getline(archivo,texto);
		//cout<<texto<<endl;
		for(int i=0;i<=texto.size();i++){
          if(texto[i] != ';')
		    msg += texto[i];
          else if(codSuper == ""){
            codSuper = msg;
            //cout<<codCiudad<<endl;
            msg = "";
          }
          else if(codProducto == ""){
            codProducto = msg;
            msg = "";
          }
          else if(nombre == ""){
            nombre = msg;
            msg = "";
          }
          else if(cantProducto == 0){
            cantProducto = atoi(msg.c_str());
            msg = "";
          }
		}
		InsertarFinalListaDobleCircularInventario(codSuper,codProducto,nombre,cantProducto,atoi(msg.c_str()),auxListaSuper);
		//cout<<msg<<endl;
	}
	archivo.close();
}

void listaDCInventario::consultarPrecioDeProducto(string pCodProducto){
    pnodoDobleCircularInventario aux = primero;
     while ( aux->siguiente != primero){
          if(aux->codProducto == pCodProducto){
            cout<<"El precio de "<<aux->nombre<<" es de "<<aux->precioUnitario<<endl;
            return;
          }
          aux= aux->siguiente;
    }
    if(aux->codProducto == pCodProducto){
        cout<<"El precio de "<<aux->nombre<<" es de "<<aux->precioUnitario<<endl;
        return;
    }
    cout<<"El producto que indico no existe"<<endl;
}

void listaDCInventario::consultarSobreUnProducto(string pCodSuper){
    pnodoDobleCircularInventario aux = primero;
     while ( aux->siguiente != primero){
          if(aux->codSuper == pCodSuper){
            cout<<"Codigo de Super: "<<aux->codSuper<<endl;
            cout<<"Codigo del Producto: "<<aux->codProducto<<endl;
            cout<<"Nombre: "<<aux->nombre<<endl;
            cout<<"Cantidad: "<<aux->cantidadProducto<<endl;
            cout<<"Precio por unidad "<<aux->precioUnitario<<endl;
            cout<<endl;
          }
          aux= aux->siguiente;
    }
    if(aux->codSuper == pCodSuper){
        cout<<"Codigo de Super: "<<aux->codSuper<<endl;
        cout<<"Codigo del Producto: "<<aux->codProducto<<endl;
        cout<<"Nombre: "<<aux->nombre<<endl;
        cout<<"Cantidad: "<<aux->cantidadProducto<<endl;
        cout<<"Precio por unidad: "<<aux->precioUnitario<<endl;
        cout<<endl;
        return;
    }
    cout<<"El producto que indico no existe"<<endl;
}
#endif // LISTADOBLECIRCULARINVENTARIO_H_INCLUDED
