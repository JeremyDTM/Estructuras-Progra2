#ifndef listadoblecircular_H_INCLUDED
#define listadoblecircular_H_INCLUDED

#include "ListaDobleCircularUsuarios.h"
#include "listaSimple.h"
#include <iostream>


using namespace std;

class nodoDobleCircular {
   public:
    nodoDobleCircular(int v)
    {
       valor = v;
       siguiente = NULL;
       anterior =NULL;
    }

   nodoDobleCircular(int v, nodoDobleCircular * signodoDobleCircular)
    {
       valor = v;
       siguiente = signodoDobleCircular;
    }

 public:
    int valor;
    nodoDobleCircular *siguiente;
    nodoDobleCircular *anterior;
    nodoDobleCircularUsuarios *Usuario = NULL;


   friend class listaDC;
};
typedef nodoDobleCircular *pnodoDobleCircular;

class listaDC {
   public:
    listaDC() { primero = actual = NULL; }

    void InsertarInicioListaDobleCircular(int v);
    void InsertarFinalListaDobleCircular(int v);
    void InsertarPosListaDobleCircular(int v, int pos);
    void EliminarInicioListaDobleCircular();
    void EliminarFinalListaDobleCircular();
    void EliminarPosListaDobleCircular(int pos);
    bool ListaVaciaListaDobleCircular() { return primero == NULL; }
    void ImprimirListaDobleCircular();
    void BorrarListaDobleCircular(int v);
    void MostrarListaDobleCircular();
    void SiguienteListaDobleCircular();
    void PrimeroListaDobleCircular();
    void UltimoListaDobleCircular();
    void BorrarFinalListaDobleCircular();
    void BorrarInicioListaDobleCircular();
    void borrarPosicionListaDobleCircular(int pos);
    int largoListaListaDobleCircular();
    void crearListaTiposDeUsuarios(pnodoSimple auxListaCiudades);
    void leerUsuarios(pnodoSimple auxListaCiudades);
    bool verificarCiudad(string pCodCiudad,pnodoSimple auxListaCiudades);
    bool verificarUsuarios(string pCedula);
    void insertarUsuario(string pCodCiudad, string pCedula, string pNombre, string pTelefono, int pTipo);
    pnodoDobleCircularUsuarios buscarUsuario(string pCedula, int pTipo);

   public:
    pnodoDobleCircular primero;
    pnodoDobleCircular actual;
};


int listaDC::largoListaListaDobleCircular()
{
    int cont=0;

    pnodoDobleCircular aux = primero->siguiente;
    if(ListaVaciaListaDobleCircular())
    {
        return cont;
    }
    else
    {
        while(aux!=primero)
        {
          aux=aux->siguiente;
          cont++;
        }
    return cont;
    }

}

void listaDC::InsertarInicioListaDobleCircular(int v)
{

   if (ListaVaciaListaDobleCircular())
   {
     primero = new nodoDobleCircular(v);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
     pnodoDobleCircular nuevo=new nodoDobleCircular (v);
     nuevo->siguiente=primero;
     nuevo->anterior= primero->anterior;
     primero->anterior->siguiente=nuevo;
     nuevo->siguiente->anterior=nuevo;
     primero= nuevo;
   }
}

void listaDC::InsertarFinalListaDobleCircular(int v)
{
   if (ListaVaciaListaDobleCircular())
     {
     primero = new nodoDobleCircular(v);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
     pnodoDobleCircular nuevo = new nodoDobleCircular(v);
     nuevo->anterior = primero->anterior;
     nuevo->siguiente=primero->anterior->siguiente;
     primero->anterior->siguiente=nuevo;
     primero->anterior=nuevo;
    }
}


void listaDC::InsertarPosListaDobleCircular(int v,int pos)
{
   if (ListaVaciaListaDobleCircular())
   {
     primero = new nodoDobleCircular(v);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
      if(pos <=1)
        InsertarInicioListaDobleCircular(v);
       else
       {
        if (pos==largoListaListaDobleCircular())
          InsertarFinalListaDobleCircular(v);
        else
        {
             pnodoDobleCircular aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= primero))
             {
                   i++;
                   aux=aux->siguiente;
             }
             pnodoDobleCircular nuevo= new nodoDobleCircular(v);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             aux->siguiente->anterior=aux;
             nuevo->siguiente->anterior=nuevo;
        }
       }
   }
}

void listaDC::BorrarFinalListaDobleCircular()
{
    if (ListaVaciaListaDobleCircular())
      cout << "No hay elementos en la lista:" << endl;
    else
    {
      if (primero->siguiente == primero)
      {
        pnodoDobleCircular temp= primero;
        primero= NULL;
        delete temp;
      }
      else
      {
         pnodoDobleCircular aux = primero;
         while (aux->siguiente->siguiente != primero)
              aux = aux->siguiente;
         pnodoDobleCircular temp = aux->siguiente;
         aux->siguiente= primero;
         primero->anterior=aux;
         delete temp;
      }
    }
}

void listaDC::BorrarInicioListaDobleCircular()
{
    if (ListaVaciaListaDobleCircular())
      cout << "No hay elementos en la lista:" << endl;
    else
    {
     if (primero->siguiente == primero)
     {
        pnodoDobleCircular temp= primero;
        primero= NULL;
        delete temp;
     }
     else
     {
        pnodoDobleCircular aux = primero->anterior;
        pnodoDobleCircular temp= primero;
        aux->siguiente=primero->siguiente;
        primero=primero->siguiente;
        primero->anterior=aux;
        delete temp;
      }
    }
}

void listaDC:: borrarPosicionListaDobleCircular(int pos)
{
  if(ListaVaciaListaDobleCircular())
    cout << "Lista vacia" <<endl;
  else
  {
   if((pos>largoListaListaDobleCircular())||(pos<0)){
        cout << "Error en posicion" << endl;}
   else
   {
      if(pos==1)
        BorrarInicioListaDobleCircular();
      else
      {
       int cont=2;
       pnodoDobleCircular aux=  primero;
       while(cont<pos)
       {
         aux=aux->siguiente;
         cont++;
       }
       pnodoDobleCircular temp = aux->siguiente;
       aux->siguiente=aux->siguiente->siguiente;
       delete temp;
     }
    }
  }
}

void listaDC::MostrarListaDobleCircular()
{
   pnodoDobleCircular aux=primero;
   while(aux->siguiente!=primero)
     {
      cout << aux->valor <<";"<<aux->Usuario<<"-> ";
      aux = aux->siguiente;
     }
     cout<<aux->valor<<";"<<aux->Usuario<<"->";
     cout<<endl;
}

void listaDC::crearListaTiposDeUsuarios(pnodoSimple auxListaCiudades)
{
    pnodoDobleCircular auxLista1;
    InsertarFinalListaDobleCircular(0);
    InsertarFinalListaDobleCircular(1);
    InsertarFinalListaDobleCircular(2);
    InsertarFinalListaDobleCircular(3);
    leerUsuarios(auxListaCiudades);
}

void listaDC::leerUsuarios(pnodoSimple auxListaCiudades){
    ifstream archivo;
	string texto;

	string msg = "";
	string codCiudad = "";
	string cedula = "";
	string nombre = "";
	string telefono = "";

	archivo.open("Usuarios.txt",ios::in);

	if(archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}

	while(!archivo.eof()){
        msg = "";
        codCiudad = "";
        cedula = "";
        nombre = "";
        telefono = "";
		getline(archivo,texto);
		//cout<<texto<<endl;
		for(int i=0;i<=texto.size();i++){
          if(texto[i] != ';')
		    msg += texto[i];
          else if(codCiudad == ""){
            codCiudad = msg;
            //cout<<codCiudad<<endl;
            msg = "";
          }
          else if(cedula == ""){
            cedula = msg;
            msg = "";
          }
          else if(nombre == ""){
            nombre = msg;
            msg = "";
          }
          else if(telefono == ""){
            telefono = msg;
            msg = "";
          }
		}
		if(verificarCiudad(codCiudad,auxListaCiudades)){
            cout<<"a"<<endl;
            if(verificarUsuarios(cedula)){
                cout<<"b"<<endl;
                insertarUsuario(codCiudad, cedula, nombre, telefono, atoi(msg.c_str()));
            }
		}
		//cout<<msg<<endl;
	}
	archivo.close();
}

bool listaDC::verificarCiudad(string pCodCiudad, pnodoSimple auxListaCiudades){
    pnodoSimple auxListaCiudadesAux;
    auxListaCiudadesAux = auxListaCiudades;
      while(auxListaCiudadesAux!= NULL){
        if(auxListaCiudadesAux->codCiudad == pCodCiudad){return true;}
        auxListaCiudadesAux = auxListaCiudadesAux->siguiente;
      }
    return false;
}

bool listaDC::verificarUsuarios(string pCedula)
{
    pnodoDobleCircular auxTipos = primero;
    pnodoDobleCircularUsuarios auxUsuario,auxUsuarioAux;
    while(auxTipos->siguiente != primero){
        auxUsuario = auxTipos->Usuario;
        auxUsuarioAux = auxUsuario;
        if(auxUsuario == NULL){
            auxTipos = auxTipos -> siguiente;
        }
        else{
            while(auxUsuarioAux->siguiente != auxUsuario){
                if(auxUsuarioAux->cedula != pCedula){
                    auxUsuarioAux = auxUsuarioAux -> siguiente;
                }
                else{return false;}
            }
            if(auxUsuarioAux->cedula != pCedula){
                auxTipos = auxTipos -> siguiente;;
                }
            else{return false;}
            }
        }
    auxUsuario = auxTipos->Usuario;
    auxUsuarioAux = auxUsuario;
    if(auxUsuario == NULL){return true;}
    else{
    while(auxUsuarioAux->siguiente != auxUsuario){
        if(auxUsuarioAux->cedula != pCedula){
            auxUsuarioAux = auxUsuarioAux -> siguiente;
        }
        else{return false;}
    }
    if(auxUsuarioAux->cedula != pCedula){
        return true;
    }
    else{return false;}
    }
}

void listaDC::insertarUsuario(string pCodCiudad, string pCedula, string pNombre, string pTelefono, int pTipo)
{
    pnodoDobleCircular auxTipos = primero;
    pnodoDobleCircularUsuarios auxUsuario,auxUsuarioAux;
    pnodoDobleCircularUsuarios nuevo = new nodoDobleCircularUsuarios(pCodCiudad,pCedula,pNombre,pTelefono,pTipo);
    while(auxTipos->siguiente != primero){
        if(auxTipos->valor == pTipo){
            auxUsuario = auxTipos->Usuario;
            auxUsuarioAux = auxTipos->Usuario;
            if(auxUsuarioAux == NULL){
                auxUsuarioAux = nuevo;
                auxUsuarioAux->siguiente = auxUsuarioAux;
                auxUsuarioAux->anterior = auxUsuarioAux;
                auxTipos->Usuario = auxUsuarioAux;
                return;
            }
            else{
                nuevo->anterior = auxUsuario->anterior;
                nuevo->siguiente = auxUsuario->anterior->siguiente;
                auxUsuario->anterior->siguiente = nuevo;
                auxUsuario->anterior=nuevo;
                return;
            }
        }
        auxTipos = auxTipos->siguiente;
    }
            auxUsuario = auxTipos->Usuario;
            auxUsuarioAux = auxTipos->Usuario;
            if(auxUsuarioAux == NULL){
                auxUsuarioAux = nuevo;
                auxUsuarioAux->siguiente = auxUsuarioAux;
                auxUsuarioAux->anterior = auxUsuarioAux;
                auxTipos->Usuario = auxUsuarioAux;
                return;
            }
            else{
                nuevo->anterior = auxUsuario->anterior;
                nuevo->siguiente = auxUsuario->anterior->siguiente;
                auxUsuario->anterior->siguiente = nuevo;
                auxUsuario->anterior=nuevo;
                return;
            }
}


pnodoDobleCircularUsuarios listaDC::buscarUsuario(string pCedula, int pTipo){
    pnodoDobleCircular auxTipos = primero;
    pnodoDobleCircularUsuarios auxUsuario,auxUsuarioAux;
    while(auxTipos->siguiente != primero){
        if(auxTipos->valor == pTipo){
            auxUsuario = auxTipos->Usuario;
            auxUsuarioAux = auxTipos->Usuario;
            if(auxUsuarioAux == NULL){
                return NULL;
            }
            else{
                while(auxUsuarioAux->siguiente != auxUsuario){
                    if(auxUsuarioAux->cedula == pCedula){
                        return auxUsuarioAux;
                    }
                    auxUsuarioAux = auxUsuarioAux -> siguiente;
                }
                if(auxUsuarioAux->cedula == pCedula){
                   return auxUsuarioAux;
                }
                return NULL;
            }
        }
        auxTipos= auxTipos->siguiente;
    }
    auxUsuario = auxTipos->Usuario;
    auxUsuarioAux = auxTipos->Usuario;
        if(auxUsuarioAux == NULL){
            return NULL;
        }
        else{
            while(auxUsuarioAux->siguiente != auxUsuario){
                if(auxUsuarioAux->cedula == pCedula){
                    return auxUsuarioAux;
                }
                auxUsuarioAux = auxUsuarioAux -> siguiente;
            }
            if(auxUsuarioAux->cedula == pCedula){
                return auxUsuarioAux;
            }
            return NULL;
        }
}

#endif // listadoblecircular_H_INCLUDED
