
#include <iostream>
using namespace std;

class nodo {
   public:
    nodo(int v)
    {
       valor = v;
       siguiente = NULL;
       anterior =NULL;
    }

   nodo(int v, nodo * signodo)
    {
       valor = v;
       siguiente = signodo;
    }

 private:
    int valor;
    nodo *siguiente;
    nodo *anterior;
    nodo *actual;


   friend class listaDC;
};
typedef nodo *pnodo;

class listaDC {
   public:
    listaDC() { primero = actual = NULL; }
    ~listaDC();

    void InsertarInicio3(int v);
    void InsertarFinal3(int v);
    void InsertarPos3(int v, int pos);
    void EliminarInicio3();
    void EliminarFinal3();
    void EliminarPos3(int pos);
    bool ListaVacia3() { return primero == NULL; }
    void Imprimir3();
    void Borrar3(int v);
    void Mostrar3();
    void Siguiente3();
    void Primero3();
    void Ultimo3();
    void BorrarFinal3();
    void BorrarInicio3();
    void borrarPosicion3(int pos);
    int largoLista3();

   private:
    pnodo primero;
    pnodo actual;
};

listaDC::~listaDC()
{
   pnodo aux;

   while(primero) {
      aux = primero;
      primero = primero->siguiente;
      primero->anterior=aux->anterior;
      aux->anterior->siguiente=primero;
      delete aux;
   }
   actual = NULL;
}

int listaDC::largoLista3()
{
    int cont=0;

    pnodo aux = primero;
    if(ListaVacia3())
    {
        return cont;
    }
    else
    {
        while(aux!=primero)
        {
          aux=aux->siguiente;
          cont++;
        }
    return cont;
    }

}

void listaDC::InsertarInicio3(int v)
{

   if (ListaVacia3())
   {
     primero = new nodo(v);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
     pnodo nuevo=new nodo (v);
     nuevo->siguiente=primero;
     nuevo->anterior= primero->anterior;
     primero->anterior->siguiente=nuevo;
     nuevo->siguiente->anterior=nuevo;
     primero= nuevo;
   }
}

void listaDC::InsertarFinal3(int v)
{
   if (ListaVacia3())
     {
     primero = new nodo(v);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
     pnodo nuevo = new nodo(v);
     nuevo->anterior = primero->anterior;
     nuevo->siguiente=primero->anterior->siguiente;
     primero->anterior->siguiente=nuevo;
     primero->anterior=nuevo;
    }
}


void listaDC::InsertarPos3(int v,int pos)
{
   if (ListaVacia3())
   {
     primero = new nodo(v);
     primero->anterior=primero;
     primero->siguiente=primero;
   }
   else
   {
      if(pos <=1)
        InsertarInicio3(v);
       else
       {
        if (pos==largoLista3())
          InsertarFinal3(v);
        else
        {
             pnodo aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= primero))
             {
                   i++;
                   aux=aux->siguiente;
             }
             pnodo nuevo= new nodo(v);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             aux->siguiente->anterior=aux;
             nuevo->siguiente->anterior=nuevo;
        }
       }
   }
}

void listaDC::BorrarFinal3()
{
    if (ListaVacia3())
      cout << "No hay elementos en la lista:" << endl;
    else
    {
      if (primero->siguiente == primero)
      {
        pnodo temp= primero;
        primero= NULL;
        delete temp;
      }
      else
      {
         pnodo aux = primero;
         while (aux->siguiente->siguiente != primero)
              aux = aux->siguiente;
         pnodo temp = aux->siguiente;
         aux->siguiente= primero;
         primero->anterior=aux;
         delete temp;
      }
    }
}

void listaDC::BorrarInicio3()
{
    if (ListaVacia3())
      cout << "No hay elementos en la lista:" << endl;
    else
    {
     if (primero->siguiente == primero)
     {
        pnodo temp= primero;
        primero= NULL;
        delete temp;
     }
     else
     {
        pnodo aux = primero->anterior;
        pnodo temp= primero;
        aux->siguiente=primero->siguiente;
        primero=primero->siguiente;
        primero->anterior=aux;
        delete temp;
      }
    }
}

void listaDC:: borrarPosicion3(int pos)
{

  if(ListaVacia3())
    cout << "Lista vacia" <<endl;
  else
  {
   if((pos>largoLista3())||(pos<0))
        cout << "Error en posicion" << endl;
   else
   {
      if(pos==1)
        BorrarInicio3();
      else
      {
       int cont=2;
       pnodo aux=  primero;
       while(cont<pos)
       {
         aux=aux->siguiente;
         cont++;
       }
       pnodo temp = aux->siguiente;
       aux->siguiente=aux->siguiente->siguiente;
       delete temp;
     }
    }
  }
}

void listaDC::Mostrar3()
{
   pnodo aux=primero;
   while(aux->siguiente!=primero)
     {

      cout << aux->valor << "-> ";
      aux = aux->siguiente;
     }
     cout<<aux->valor<<"->";
     cout<<endl;
}


/*int main()
{
   listaDC Lista;


   Lista.InsertarInicio(20);
   Lista.InsertarInicio(2);
   Lista.InsertarFinal(10);
   Lista.InsertarFinal(11);
   Lista.Mostrar();
   Lista.InsertarPos(5, 3);
   Lista.Mostrar();
   Lista.InsertarPos(6, 14);
   Lista.Mostrar();
   Lista.BorrarFinal();
   Lista.Mostrar();
   Lista.BorrarInicio();
   Lista.Mostrar();
   Lista.borrarPosicion(2);
   Lista.Mostrar();
   cin.get();
   return 0;
}*/
