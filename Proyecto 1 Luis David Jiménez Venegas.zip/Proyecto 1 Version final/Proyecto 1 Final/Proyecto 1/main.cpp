#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include "listaSimple.h"
#include "listadoble.h"
#include "listadoblecircular.h"
#include "ListaDobleCircularInventario.h"
#include "ListaDobleCircularUsuarios.h"
using namespace std;

lista ListaCiudades;
listaD ListaSuper;
pnodoSimple auxListaCiudades = NULL;
pnodoDoble auxListaSuper= NULL;
pnodoDobleCircularInventario auxListaInventarios= NULL;
pnodoDobleCircular auxListaUsuarios = NULL;
pnodoDobleCircularUsuarios auxUsuarioEnUso = NULL;
listaDCInventario ListaDeInventarios;
listaDC ListaTiposDeUsuarios;


void ClienteYAdministrador(string pCedula, int pTipo);
void Vendedor(string pCedula, int pTipo);
void Cliente(string pCedula, int pTipo);
void Administrador(string pCedula, int pTipo);
void noEsCliente();
void consultarPrecio();
void consultarProducto();
void agregarAlCarro();
void facturacion();
pnodoDobleCircularInventario agregarAlCarrito(string pCodSuper);
void insertarProducto();
void eliminarProducto();
void ModificarProducto();
void consultarDescuentoDeUnCliente();



void proyecto1(){
    ListaCiudades.crearListaCiudades();
    ListaCiudades.MostrarListaSimple();

    auxListaCiudades = ListaCiudades.primero;

    ListaSuper.crearListaSupermercados(auxListaCiudades);
    ListaSuper.MostrarListaDoble();

    auxListaSuper = ListaSuper.primero;

    ListaDeInventarios.crearListaDeInventarios(auxListaSuper);
    ListaDeInventarios.MostrarListaDobleCircularInventario();

    auxListaInventarios = ListaDeInventarios.primero;

    ListaTiposDeUsuarios.crearListaTiposDeUsuarios(auxListaCiudades);
    ListaTiposDeUsuarios.MostrarListaDobleCircular();

    auxListaUsuarios = ListaTiposDeUsuarios.primero;

    system("cls");

    string tipo;
    string cedula;
    bool salir = false;

    cout<<"Bienvenido a el sistema de Supermercados"<<endl;

    while(!salir){
        cout<<"Por favor escriba su numero de cedula: "<<endl;
        getline(cin,cedula);
        cout<<"Por favor escriba el tipo de Usuario: "<<endl;
        getline(cin,tipo);
        if(tipo == "0"){
            Cliente(cedula,atoi(tipo.c_str()));
        }
        else if(tipo == "1"){
            Administrador(cedula, atoi(tipo.c_str()));
        }
        else if(tipo == "2"){
            Vendedor(cedula, atoi(tipo.c_str()));
        }
        else if(tipo == "3"){
            ClienteYAdministrador(cedula, atoi(tipo.c_str()));
        }
        else{
            cout<<"El tipo de usuario que ingreso no es valido"<<endl;
        }
    }
}

void Cliente(string pCedula, int pTipo){
    auxUsuarioEnUso = ListaTiposDeUsuarios.buscarUsuario(pCedula, pTipo);
    if(auxUsuarioEnUso == NULL){
        cout<<"El Usuario ingresado no se encuentra registrado."<<endl;
        cout<<"Se va a ingresar como usuario no registrado"<<endl;
        noEsCliente();
    }
    else{
        bool salir = false;
        while(!salir){
            cout<<"1- Consultar precio."<<endl;
            cout<<"2- Consultar descuento. "<<endl;
            cout<<"3- Consultar producto. "<<endl;
            cout<<"4- Agregar al carrito. "<<endl;
            cout<<"5- Facturar Compra. "<<endl;
            cout<<"6- Salir. "<<endl;
            string opcion;
            getline(cin,opcion);
            if(opcion == "1"){
                consultarPrecio();
            }
            else if(opcion == "2"){
                cout<<"Al ser un usuario Cliente se le aplica un descuento de 5% al total de su compra"<<endl;
            }
            else if(opcion == "3"){
                consultarProducto();
            }
            else if(opcion == "4"){
                agregarAlCarro();
            }
            else if(opcion == "5"){
                cout<<"Este metodo no se llego a facturar"<<endl;
            }
            else if(opcion == "6"){
                return;
            }
            else{cout<<"La opcion escogida no es valida"<<endl;}
        }
    }
}

void Administrador(string pCedula, int pTipo){
    auxUsuarioEnUso = ListaTiposDeUsuarios.buscarUsuario(pCedula, pTipo);
    if(auxUsuarioEnUso == NULL){
        cout<<"El Usuario ingresado no se encuentra registrado."<<endl;
        cout<<"Va a ingresar como usuario no registrado"<<endl;
        noEsCliente();
    }
    else{
        bool salir = false;
        while(!salir){
            cout<<"1- Insertar producto."<<endl;
            cout<<"2- Eliminar producto. "<<endl;
            cout<<"3- Modificar producto. "<<endl;
            cout<<"4- Consultar precio. "<<endl;
            cout<<"5- Consultar descuentos. "<<endl;
            cout<<"6- Consultar productos de un super. "<<endl;
            cout<<"7- Registrar Clientes. "<<endl;
            cout<<"8- Salir. "<<endl;
            string opcion;
            getline(cin,opcion);
            if(opcion == "1"){
                insertarProducto();
            }
            else if(opcion == "2"){
                eliminarProducto();
            }
            else if(opcion == "3"){
                ModificarProducto();
            }
            else if(opcion == "4"){
                consultarPrecio();
            }
            else if(opcion == "5"){
                cout<<"Si es un cliente se le aplica un 5% de descuento."<<endl;
                cout<<"Si es un cliente - funcionario se le aplica un 10% de descuento"<<endl;
            }
            else if(opcion == "6"){
                consultarProducto();
            }
            else if(opcion == "7"){
                string codCiudad;
                string cedula;
                string nombre;
                string telefono;
                string tipo;
                cout<<"Por favor escriba el codigo de la ciudad"<<endl;
                getline(cin,codCiudad);
                cout<<"Por favor escriba la cedula"<<endl;
                getline(cin,cedula);
                cout<<"Por favor escriba el nombre"<<endl;
                getline(cin,nombre);
                cout<<"Por favor escriba el telefono del usuario"<<endl;
                getline(cin,telefono);
                if(ListaTiposDeUsuarios.verificarCiudad(codCiudad,auxListaCiudades)){
                    if(ListaTiposDeUsuarios.verificarUsuarios(cedula));
                        ListaTiposDeUsuarios.insertarUsuario(codCiudad, cedula, nombre, telefono, 0);
                        cout<<"Se registro al cliente con exito"<<endl;
                    }
                    else{cout<<"La cedula del usuario ya existe"<<endl;}
                }
                else if(opcion == "8"){
                salir = true;
                }
                else{cout<<"La opcion escogida no es valida"<<endl;}
            }
    }
}

void Vendedor(string pCedula, int pTipo){
    auxUsuarioEnUso = ListaTiposDeUsuarios.buscarUsuario(pCedula, pTipo);
    if(auxUsuarioEnUso == NULL){
        cout<<"El Usuario ingresado no se encuentra registrado."<<endl;
        cout<<"Se Va a ingresar como usuario no registrado"<<endl;
        noEsCliente();
    }
    else{
        bool salir = false;
        while(!salir){
            cout<<"1- Consultar precio."<<endl;
            cout<<"2- Consultar descuento de un cliente. "<<endl;
            cout<<"3- Consultar productos de un super. "<<endl;
            cout<<"4- Salir. "<<endl;
            string opcion;
            getline(cin,opcion);
            if(opcion == "1"){
                consultarPrecio();
            }
            else if(opcion == "2"){
                consultarDescuentoDeUnCliente();
            }
            else if(opcion == "3"){
                consultarProducto();
            }
            else if(opcion == "4"){
                salir = true;
            }
            else{cout<<"La opcion escogida no es valida"<<endl;}
        }
    }
}

void ClienteYAdministrador(string pCedula, int pTipo){
    auxUsuarioEnUso = ListaTiposDeUsuarios.buscarUsuario(pCedula, pTipo);
    if(auxUsuarioEnUso == NULL){
        cout<<"El Usuario ingresado no se encuentra registrado."<<endl;
        cout<<"Se Va a ingresar como usuario no registrado"<<endl;
        noEsCliente();
    }
    else{
        bool salir = false;
        while(!salir){
            cout<<"1- Consultar precio."<<endl;
            cout<<"2- Consultar descuento. "<<endl;
            cout<<"3- Consultar producto. "<<endl;
            cout<<"4- Agregar al carrito. "<<endl;
            cout<<"5- Facturar Compra. "<<endl;
            cout<<"6- Salir"<<endl;
            string opcion;
            getline(cin,opcion);
            if(opcion == "1"){
                consultarPrecio();
            }
            else if(opcion == "2"){
                cout<<"Al ser cliente-funcionario se le aplica un 10% de descuento a cada una de sus compras"<<endl;
            }
            else if(opcion == "3"){
                consultarProducto();
            }
            else if(opcion == "4"){
                agregarAlCarro();
            }
            else if(opcion == "5"){
                cout<<"Este metodo no se logro implementar"<<endl;
            }
            else if(opcion == "6"){
                salir = true;
            }
            else{cout<<"La opcion escogida no es valida"<<endl;}
        }
    }
}

void noEsCliente(){
    bool salir = false;
        while(!salir){
            cout<<"1- Consultar precio."<<endl;
            cout<<"2- Consultar productos. "<<endl;
            cout<<"3- salir."<<endl;
            string opcion;
            getline(cin,opcion);
            if(opcion == "1"){
                consultarPrecio();
            }
            else if(opcion == "2"){
                consultarProducto();
            }
            else if(opcion == "3"){
                salir = true;
            }
    }
}

void consultarPrecio(){
    //ListaDeInventarios.MostrarListaDobleCircularInventario();
    string codigoProducto;
    cout<<"Por favor escriba el codigo del producto"<<endl;
    getline(cin,codigoProducto);
    ListaDeInventarios.consultarPrecioDeProducto(codigoProducto);
    return;
}

void consultarProducto(){
    //ListaDeInventarios.MostrarListaDobleCircularInventario();
    string codigoSuper;
    cout<<"Por favor escriba el codigo del Super"<<endl;
    getline(cin,codigoSuper);
    ListaDeInventarios.consultarSobreUnProducto(codigoSuper);
    return;
}

void agregarAlCarro(){
    pnodoDoble auxListaSuperAux3;
    auxListaSuperAux3 = auxListaSuper;
    ListaDeInventarios.MostrarListaDobleCircularInventario();
    string codigoSuper;
    cout<<"Por favor escriba el codigo del Super"<<endl;
    getline(cin,codigoSuper);
    while(auxListaSuperAux3->siguiente != NULL){
        if(auxListaSuperAux3->codSuper == codigoSuper){
            if(auxUsuarioEnUso->carrito == NULL){
            auxUsuarioEnUso->carrito = agregarAlCarrito(codigoSuper);
            //cout<<auxUsuarioEnUso->carrito->nombre<<endl;
            }
            else{
                pnodoDobleCircularInventario auxProdutoAAgregar;
                auxProdutoAAgregar = auxUsuarioEnUso->carrito;
                while(auxProdutoAAgregar->siguiente != NULL){
                    auxProdutoAAgregar = auxProdutoAAgregar ->siguiente;
                }
                auxProdutoAAgregar->siguiente = agregarAlCarrito(codigoSuper);
            }
            return;
        }
        else{
        auxListaSuperAux3= auxListaSuperAux3->siguiente;
        }
    }
    cout<<"El super no existe"<<endl;
}

pnodoDobleCircularInventario agregarAlCarrito(string pCodSuper){
    pnodoDobleCircularInventario aux = auxListaInventarios;
    string codigoProducto;
    cout<<"Por favor escriba el codigo del producto"<<endl;
    getline(cin,codigoProducto);
    while (aux->siguiente != auxListaInventarios){
          if(aux->codSuper == pCodSuper){
              if(aux->codProducto == codigoProducto){
                  bool salir = false;
                  while(!salir){
                      cout<<"Indique la cantidad de producto que va a comprar"<<endl;
                      string cantidadStr;
                      int cantidadInt;
                      getline(cin,cantidadStr);
                      cantidadInt = atoi(cantidadStr.c_str());
                      if(cantidadInt <= 0){cout<<"La cantidad debe ser un numero positivo"<<endl;}
                      else if(aux->cantidadProducto < cantidadInt)
                        cout<<"La cantidad de producto indicada es mayor a la disponible"<<endl;
                      else{
                        aux->cantidadProducto = aux->cantidadProducto - cantidadInt;
                        cout<<"Se ha agregado el producto correctamente al carrito"<<endl;
                        return new nodoDobleCircularInventario(aux->codSuper,aux->codProducto,aux->nombre,cantidadInt,aux->precioUnitario);
                      }
                  }
              }
              else{aux=aux->siguiente;}
          }
          aux=aux->siguiente;
    }
    if(aux->codSuper == pCodSuper){
        if(aux->codProducto == codigoProducto){
            if(aux->codProducto == codigoProducto){
                  bool salir = false;
                  while(!salir){
                      cout<<"Indique la cantidad de producto que va a comprar"<<endl;
                      string cantidadStr;
                      int cantidadInt;
                      getline(cin,cantidadStr);
                      cantidadInt = atoi(cantidadStr.c_str());
                      if(cantidadInt <= 0){cout<<"La cantidad debe ser un numero positivo"<<endl;}
                      else if(aux->cantidadProducto < cantidadInt)
                        cout<<"La cantidad de producto indicada es mayor a la disponible"<<endl;
                      else{
                        aux->cantidadProducto = aux->cantidadProducto - cantidadInt;
                        cout<<"Se ha agregado el producto correctamente al carrito"<<endl;
                        return new nodoDobleCircularInventario(aux->codSuper,aux->codProducto,aux->nombre,cantidadInt,aux->precioUnitario);
                      }
                  }
            }
        else{cout<<"El producto no existe"<<endl;}
        return NULL;
    }
    else{cout<<"El producto no existe"<<endl;}
    }
}

void insertarProducto(){
    cout<<"Para insertar un producto a la lista tiene que especificar ciertos datos"<<endl;
    bool salir = false;
    while(!salir){
        string codigoSuper;
        string codigoProducto;
        string nombre;
        string cantidadProducto;
        string precioUnitario;
        cout<<"Indique el codigo del super"<<endl;
        getline(cin,codigoSuper);
        cout<<"Indique el codigo del producto"<<endl;
        getline(cin,codigoProducto);
        cout<<"Indique el nombre"<<endl;
        getline(cin,nombre);
        cout<<"Indique la cantidad de producto"<<endl;
        getline(cin,cantidadProducto);
        cout<<"Indique el precio del producto"<<endl;
        getline(cin,precioUnitario);
        ListaDeInventarios.InsertarFinalListaDobleCircularInventario(codigoSuper,codigoProducto,nombre,atoi(cantidadProducto.c_str()),atoi(precioUnitario.c_str()),auxListaSuper);
        ListaDeInventarios.MostrarListaDobleCircularInventario();
        cout<<"Desea salir (y/n)"<<endl;
        string opcion;
        getline(cin,opcion);
        if(opcion == "y"){
            salir = true;
        }
        }
}

void eliminarProducto(){
    bool salir = false;
    string codigoProducto;
    pnodoDobleCircularInventario auxListaInventarioAux;
    while(!salir){
        auxListaInventarioAux = auxListaInventarios;
        cout<<"Por favor escriba el codigo del producto"<<endl;
        getline(cin,codigoProducto);
        while(auxListaInventarioAux->siguiente != auxListaInventarios){
            if(auxListaInventarioAux->codProducto == codigoProducto){
                pnodoDobleCircularInventario porEliminar;
                auxListaInventarioAux;
                auxListaInventarioAux->anterior->siguiente = auxListaInventarioAux->siguiente;
                auxListaInventarioAux->siguiente->anterior = auxListaInventarioAux->anterior;
                ListaDeInventarios.MostrarListaDobleCircularInventario();
            }
        }
    }
}

void ModificarProducto(){
    bool salir = false;
    string codigoProducto;
    pnodoDobleCircularInventario auxListaInventarioAux;
    while(!salir){
        auxListaInventarioAux = auxListaInventarios;
        cout<<"Por favor escriba el codigo del producto por modificar"<<endl;
        getline(cin,codigoProducto);
        while(auxListaInventarioAux->siguiente != auxListaInventarios){
            if(auxListaInventarioAux->codProducto == codigoProducto){
                string opcion;
                cout<<"Que desea modificar"<<endl;
                cout<<"1-Nombre"<<endl;
                cout<<"2-cantidad"<<endl;
                cout<<"3-Precio"<<endl;
                cout<<"4-salir"<<endl;
                getline(cin,opcion);
                if(opcion == "1"){
                    string pNombre;
                    cout<<"Escriba el nuevo nombre del producto"<<endl;
                    getline(cin,pNombre);
                    auxListaInventarioAux->nombre = pNombre;
                }
                else if(opcion == "2"){
                    string pCantidad;
                    cout<<"Escriba la nueva cantidad de productos"<<endl;
                    getline(cin,pCantidad);
                    auxListaInventarioAux->cantidadProducto = atoi(pCantidad.c_str());
                }
                else if(opcion == "3"){
                    string pPrecio;
                    cout<<"Escriba la nueva cantidad de productos"<<endl;
                    getline(cin,pPrecio);
                    auxListaInventarioAux->precioUnitario = atoi(pPrecio.c_str());
                }
                else if(opcion == "4"){
                    salir = true;
                }
            break;
            }
        }
    }
    return;
}

void consultarDescuentoDeUnCliente(){
    cout<<"Si es cliente, su descuento es de 5%"<<endl;
    cout<<"Si es cliente - usuario, su descuento es de 10%"<<endl;
}

int main()
{
    proyecto1();

    cin.get();
    return 0;
}

