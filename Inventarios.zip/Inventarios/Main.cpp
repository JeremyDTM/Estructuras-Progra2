#include <stdlib.h>
#include <iostream>

#include "ArbolAAInventarios.h"
#include "nodoAAInventarios.h"
#include "ArbolAAInventarios.cpp"

using namespace std;



/* Este comentario lo dejo para saber el estado actual del codigo, la idea es irlo actualizando si le hacen cambios
	
	Primero ya se puede crear el arbol con los archivos, sin embargo se necesita el codigo de super para descartar los
	super repetidos. Ademas falta descartar los que tienen el codigo de producto repetido. En cada nodo del arbol de super, se crea un arbol de inventarios.
	Si tienen el codigo del arbol con el giro y el reparto al 100 hay que pasarle este codigo. Ya que este no lo hace, sin embargo ahi tiene los metodos hechos.
	Solo falta implementarlo, si alguno lo ha hecho me avisa y se lo paso, aunque tambien ma�ana voy a trabajar en eso para tener el arbol AA funcionando.
	
	
	Posiblemente haya que hacer cambios al codigo, yo voy a estar trabajando estos dias en este codigo, si tienen alguna idea me dicen, o si prefieren le
	pueden hacer cambios, como gusten. Ademas he estado trabajando lo de sockets, he visto varias librerias y lo de hacerlo en qt. Ma�ana 15/10/2018 hago pruebas y les
	digo resultados sobre las pruebas que voy haciendo.
	
	*/

int main(){
	
	ArbolAAInventarios aux1;
	
	aux1.crearListaDeInventarios();
	
	/*
    ArbolAA aux1;
    aux1.InsertaNodo(15);
    aux1.InsertaNodo(10);
    aux1.InsertaNodo(8);
    aux1.InsertaNodo(6);
    aux1.InsertaNodo(12);
    
    InordenR(aux1.raiz);
    return 0;
    */
    InordenR(aux1.raiz);
}
