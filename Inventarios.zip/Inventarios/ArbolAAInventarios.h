#ifndef _ARBOLAAInventarios_H
#define	_ARBOLAAInventarios_H
#include "nodoAAInventarios.h"

using namespace std;

class ArbolAAInventarios{
public:
    pnodoAAInventarios raiz;

    ArbolAAInventarios():raiz(NULL){}

    void InsertaNodoInventarios(int pCodSuper, int pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario);
    void crearListaDeInventarios(); // Falta lista super, para que pueda verificarse que el super exista y insertar la lista donde debe ir
    
    
    /*void InsertaNodo2(int num);
    void InsertaNodo3(int num);
    int largo(pnodoAA nodoRaiz);*/
    
    /*void PreordenI();
    void InordenI();
    void PostordenI();*/
};
#endif	/* _BINARIO_H */
