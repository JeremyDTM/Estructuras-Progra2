#ifndef _NODOAAInventarios_H
#define	_NODOAAInventarios_H

#include <iostream>
using namespace std;


class nodoAAInventarios{
   public:
    nodoAAInventarios(int pCodSuper, int pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario)
    {
       codSuper = pCodSuper;
       codProducto = pCodProducto;
       nombre = pNombre;
       cantidadProducto = pCantidadProducto;
       precioUnitario = pPrecioUnitario;
       nivel = 1;
       Hizq = NULL;
       Hder = NULL;
    }
    void InsertarNodoInventarios(int pCodSuper, int pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario);
    nodoAAInventarios *Torsion();
    nodoAAInventarios *division();

   public:
    int codSuper;
	int codProducto;
	string nombre;
	int cantidadProducto;
	int precioUnitario;
    int nivel;
    nodoAAInventarios *Hizq;
    nodoAAInventarios *Hder;
    
        
   friend class ArbolAA;
};

typedef nodoAAInventarios *pnodoAAInventarios;

void InordenR(nodoAAInventarios *R);
pnodoAAInventarios torsion(nodoAAInventarios *T);
pnodoAAInventarios division(nodoAAInventarios *T);

#endif // _NODOAAInventarios_H
