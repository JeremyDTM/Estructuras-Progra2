#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>
#include <sstream>
#include <cstring>
#include <math.h>
#include <stdio.h>
using namespace std;

class NodoRN {
   public:

    NodoRN(int num, string ciudad, string name, NodoRN *pad=NULL, NodoRN *der = NULL, NodoRN *izq = NULL, NodoRN *sig=NULL, NodoRN *ant=NULL):
        padre(pad), Hizq(izq), Hder(der), valor(num), nombre(name), codCiudad(ciudad), siguiente(sig), anterior(ant), color(0) {}

	//Insertar aca el puntero al arbol AA
	string nombre;
	string codCiudad;
    int valor;
    int color;
    NodoRN *Hizq, *Hder, *siguiente, *anterior, *padre;

    friend class Pila;
    friend class Binario;

    void InsertaBinario(int num);
};

typedef NodoRN *pnodo;
typedef NodoRN *pNodoRN;

void PreordenR(NodoRN* R);
void InordenR(NodoRN* R);
void PostordenR(NodoRN* R);



class Pila {
   public:
    Pila() : plista(NULL) {}

    void Push(pnodo);
    void Mostrar();
    bool Vacia() { return plista == NULL; }
    pnodo Pop();
    int Size();
    
    pnodo plista;
};

void Pila::Push(pnodo v)
{
   if(Vacia()) {
      plista = v;
   }else{
    NodoRN *aux=plista;
    while(aux->siguiente){
        aux=aux->siguiente;
    }
    aux->siguiente=v;
    v->anterior=aux;
    
   }
}

pnodo Pila::Pop()
{
    NodoRN *borrar;
    NodoRN *salida;
    if(Vacia()){
        cout<<"Pila Vacia"<<endl;
    }else{
    borrar=plista;
    while(borrar->siguiente){
        borrar=borrar->siguiente;
    }
    if(Size()>1){
        salida=borrar;
        borrar->anterior->siguiente=NULL;
        borrar=NULL;
        delete borrar;
    }else{
        salida =plista;        
        plista = NULL;
    }
    }    
    return salida;
}

int Pila::Size(){
    while(plista && plista->anterior) plista = plista->anterior;
    int cont=0;
    NodoRN *aux;
    aux=plista;
    while(aux){
        cont++;
        aux=aux->siguiente;
    }
    return cont;
}

void Pila::Mostrar(){
    if(Vacia()){
        cout<<"Vacia";
    }
    NodoRN *aux = plista;
    while(aux){
        cout<< aux->valor<<" - ";
        aux=aux->siguiente;
    }
}

class RojoNegro{
public:
    pNodoRN raiz;
	pNodoRN actual;
    RojoNegro():raiz(NULL){}

    void InsertaNodo(int num);
    void PreordenI();
    void InordenI();
    void PostordenI();

    bool Hh;
    
    void Insertar(string x, int v, string y);
    void Arreglar(NodoRN* ra);
    void RotacionIzquierda(NodoRN *n);
    void RotacionDerecha(NodoRN *n);
    NodoRN* Hermano(NodoRN* nodo);


};

void PreordenR(NodoRN *R){
    if(R==NULL){
        return;
    }else{
    	if(R->color==1){
    		//cout<<R->codCiudad<<"  "<<R->nombre<<" ";
    		cout<<R->valor<<"("<<"Negro"<<")"<<" - ";
		}else{
			//cout<<R->codCiudad<<"  "<<R->nombre;
			cout<<R->valor<<"("<<"Rojo"<<")"<<" - ";
		}
        
        PreordenR(R->Hizq);
        PreordenR(R->Hder);
    }
}

void InordenR(NodoRN *R){

    if(R==NULL){
        return;
    }else{
        InordenR(R->Hizq);
        cout<<R->valor<<"("<<R->color<<")"<<" - ";
        InordenR(R->Hder);
    }
}

void PostordenR(NodoRN *R){

    if(R==NULL){
        return;
    }else{
        PostordenR(R->Hizq);
        PostordenR(R->Hder);
        cout<<R->valor<<"("<<R->color<<")"<<" - ";
    }
}

NodoRN* RojoNegro::Hermano(NodoRN* nodo)
{
	if(nodo==nodo->padre->Hizq){
		
		return nodo->padre->Hder;
	}else{ 
		return nodo->padre->Hizq;
	}
}

void RojoNegro::Insertar(string ciudad, int v, string nombre){
	//cout<<endl<<ciudad<<"  "<<v<<"  "<<nombre<<endl;
	NodoRN* ra=new NodoRN(v,ciudad,nombre);
	NodoRN* y=NULL;
	NodoRN* x=this->raiz;
	bool band=false;
	while(x!=NULL){
		y=x;
		if(y->valor==ra->valor){
			band=true;
		}
		if(ra->valor<x->valor){
			x=x->Hizq;
		}else{
			x=x->Hder;
		}
	}
	ra->padre=y;
	if(y==NULL){
		this->raiz=ra;
	}else{
		if(band==false){
			if(ra->valor<y->valor){
				y->Hizq=ra;
			}else{
				y->Hder=ra;
			}
		}
	}
	ra->Hizq=NULL;
	ra->Hder=NULL;
	ra->color=0;
	if(ra->padre!=NULL and ra->padre->padre!=NULL){
		Arreglar(ra);
	}
	this->raiz->color=1;
}

void RojoNegro::Arreglar(NodoRN* ra){
	NodoRN* y;
	while(ra!=this->raiz and ra->padre!=NULL and ra->padre->padre!=NULL and ra->padre->color==0){
		if(ra->padre==ra->padre->padre->Hder){
			//cout<<"HEEEEEEEEEE";
			y=ra->padre->padre->Hder;
			if(y!=NULL){
				if(y->color==0){
					ra->padre->color=1;
					y->color=1;
					ra->padre->padre->color=0;
					ra=ra->padre->padre;
				}else{
					if(ra==ra->padre->Hder){
						ra=ra->padre;
						RotacionIzquierda(ra);
					}
					ra->padre->color=1;
					ra->padre->padre->color=0;
					RotacionDerecha(ra->padre->padre);
					
				}
			}else{
				ra->color=1;
				ra->padre->color=0;
				RotacionDerecha(ra->padre);
			}
		}else{
			y=ra->padre->padre->Hizq;
			if(y!=NULL){
				if(y->color==0){
					ra->padre->color=1;
					y->color=1;
					ra->padre->padre->color=0;
					ra=ra->padre->padre;
				}else{
					if(ra==ra->padre->Hizq){
						ra=ra->padre;
						RotacionDerecha(ra);
					}
					ra->padre->color=1;
					ra->padre->padre->color=0;
					RotacionIzquierda(ra->padre->padre);
				}
			}else{
				ra->color=1;
				ra->padre->color=0;
				RotacionIzquierda(ra->padre);
			}
		}
	}
}

void RojoNegro::RotacionIzquierda(NodoRN* n){
     NodoRN* aux;
     aux=n;
     n=n->Hder;
     aux->Hder=n->Hizq;
     n->Hizq=aux;
     if(aux->padre->Hizq==aux){
     	aux->padre->Hizq=n;
	 }else{
	 	aux->padre->Hder=n;
	 }
	 n->padre=aux->padre;
	 aux->padre=n;
	 if(aux->Hder!=NULL){
	 	aux->Hder->padre=aux;
	 }
	 if(this->raiz==aux){
	 	this->raiz=n;
	 }
}

void RojoNegro::RotacionDerecha(NodoRN* n){
     NodoRN* aux;
     aux=n;
     n=n->Hizq;
     aux->Hizq=n->Hder;
     n->Hder=aux;
     if(aux->padre->Hizq==aux){
     	aux->padre->Hizq=n;
	 }else{
	 	aux->padre->Hder=n;
	 }
	 n->padre=aux->padre;
	 aux->padre=n;
	 if(aux->Hizq!=NULL){
	 	aux->Hizq->padre=aux;
	 }
	 if(this->raiz==aux){
	 	this->raiz=n;
	 }
}




cargarArch(ifstream& arch){	
	RojoNegro B;
	char char1[128];
	int cont=0;
	int cont2=0;
	int conta=0;
	while(!arch.eof()){
		arch.getline(char1,sizeof(char1));
		cont=0;
		char char2[128]={0};
		char char3[128]={0};
		char char4[128]={0};
		while(char1[cont]!='\0'){
				while(char1[cont]!=';' and char1[cont]!='\0'){
					char2[cont2]=char1[cont];
					cont++;
					cont2++;
				}
				cont2=0;
				cont++;
				while(char1[cont]!=';' and char1[cont]!='\0'){
					char3[cont2]=char1[cont];
					cont++;
					cont2++;
				}
				cont2=0;
				cont++;
				while(char1[cont]!=';' and char1[cont]!='\0'){
					char4[cont2]=char1[cont];
					cont++;
					cont2++;
				}
				cont2=0;
				cont++;
				//cout<<endl<<char2<<" | "<<char3<<" | "<<char4<<endl;
				B.Insertar(char2,atoi(char3),char4);
			}
		
		while(conta<128){
			char1[conta]=0;
			conta++;
		}
		conta=0;	
	}
	PreordenR(B.raiz);
	arch.close();
}

int main(){
	ifstream arch("supermercado.txt");
	cargarArch(arch);
}
