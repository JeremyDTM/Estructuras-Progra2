#include "pch.h"
#include <iostream>

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>

using namespace std;

int main()
{
	cout<<"\t\t-------TCP SERVER-------------"<<endl;
	cout<<endl;
	WSADATA WinSockData;
	int iWsaStartup;
	int iWsaCleanup;
	
	SOCKET TCPClientSocket;
	int iCloseSocket;
	
	struct sockaddr_in TCPServerAdd;
	
	int iConnect;
	
	int iRecv;
	char RecvBuffer[512];
	int iRecvBuffer = strlen(RecvBuffer)+1;
	
	int iSend;
	char SenderBuffer[512] = "Hello from Client!";
	int iSenderBuffer = strlen(SenderBuffer)+1;
	
	iWsaStartup = WSAStartup(MAKEWORD(2,2),&WinSockData);
	if(iWsaStartup!=0){
		cout<<"WSAStartUp Failed"<<endl;
	}
	cout<<"WSAStartUp Success"<<endl;
	
	TCPClientSocket = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(TCPClientSocket == INVALID_SOCKET){
		cout<<"TCP Server Socket creation failed"<<WSAGetLastError()<<endl;
	}
	cout<<"TCP Server Socket creation success"<<endl;
	
	TCPServerAdd.sin_family = AF_INET;
	TCPServerAdd.sin_addr.s_addr = inet_addr("127.0.0.1");
	TCPServerAdd.sin_port = htons(8000);
	
	iConnect = connect(TCPClientSocket,(SOCKADDR*)&TCPServerAdd,sizeof(TCPServerAdd));
	if(iConnect == SOCKET_ERROR){
		cout<<"Connection failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Connection success"<<endl;
	
	iRecv = recv(TCPClientSocket,RecvBuffer,iRecvBuffer,0);
	if(iRecv == SOCKET_ERROR){
		cout<<"Receive data failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Data received->"<<RecvBuffer<<endl;
	
	iSend = send(TCPClientSocket,SenderBuffer,iSenderBuffer,0);
	if(iSend == SOCKET_ERROR){
		cout<<"Sending failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Data sending success"<<endl;
	
	iCloseSocket = closesocket(TCPClientSocket);
	if(iCloseSocket == SOCKET_ERROR){
		cout<<"Closing socket failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Closing socket success"<<endl;
	
	iWsaCleanup = WSACleanup();
	if(iWsaCleanup == SOCKET_ERROR){
		cout<<"CleanUp func failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"CleanUp func success"<<endl;
	
	system("PAUSE");
	return 0;
}
