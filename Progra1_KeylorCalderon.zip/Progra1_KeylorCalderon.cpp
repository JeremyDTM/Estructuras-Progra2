#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>
#include <sstream>
#include <cstring>
#include <math.h>
#include <stdio.h>
using namespace std;

class nodociudad {
	
	
   public:
    nodociudad(string cod, string nom)
    {
       codigo = cod;
       nombre=nom;
       siguiente = NULL;
    }

	nodociudad(string cod, string nom, nodociudad * signodo)
    {
       codigo = cod;
       nombre=nom;
       siguiente = signodo;
    }

   private:
    string codigo;
    string nombre;
    nodociudad *siguiente;
    
        
   friend class lista;
};
typedef nodociudad *pnodociudad;

class nodomercado {
   public:
    nodomercado(string cod, string cods, string nom)
    {
       codigo = cod;
       codigosuper=cods;
	   nombre=nom;
       siguiente = NULL;
       visita=0;
    }

	nodomercado(string cod, string cods, string nom, nodomercado * signodo)
    {
       codigo = cod;
       visita=0;
       codigosuper=cods;
	   nombre=nom;
       siguiente = signodo;
    }
    
    void visitas(int v);

   private:
   	int visita;
    string codigo;
    string codigosuper;
    string nombre;
    nodomercado *siguiente;
    nodomercado *anterior;
    
        
   friend class listaD;
};
typedef nodomercado *pnodomercado;

void nodomercado::visitas(int v){
	visita+=v;
}

class nodoinv {
   public:
    nodoinv(string cods, string codpro, string nom, string cpro, string prec)
    {
       codigosuper=cods;
       codigoproducto=codpro;
	   nombre=nom;
	   cantproducto=cpro;
       precio=prec;
       siguiente = NULL;
       cantComprado=0;
    }

	nodoinv(string cods, string codpro, string nom, string cpro, string prec, nodoinv * signodo)
    {
       codigosuper=cods;
       codigoproducto=codpro;
	   nombre=nom;
	   cantproducto=cpro;
       precio=prec;
       siguiente = signodo;
       cantComprado=0;
    }
    
    void nodoinvC(string cpro);
    void nodoinvP(string cpre);
    void nodoinvCC(int CC);

   private:
    string codigosuper;
    string codigoproducto;
    string nombre;
    string cantproducto;
    string precio;
    int cantComprado;
    nodoinv *siguiente;
    nodoinv *anterior;
    
        
   friend class listaDC;
};
typedef nodoinv *pnodoinv;

void nodoinv::nodoinvC(string cpro){
	cantproducto=cpro;
}

void nodoinv::nodoinvP(string cpre){
	precio=cpre;
}

void nodoinv::nodoinvCC(int CC){
	cantComprado+=CC;
}

class nodousu {
   public:
    nodousu(string codciudad, string cel, string nom, string tel)
    {
       codigociudad=codciudad;
       cedula=cel;
	   nombre=nom;
	   telefono=tel;
	   compras=0;
       siguiente = NULL;
    }
    
    nodousu(string tip)
    {
       tipo=tip;
       compras=0;
       siguiente = NULL;
    }

	nodousu(string codciudad, string cel, string nom, string tel, nodousu * signodo)
    {
       codigociudad=codciudad;
       compras=0;
       cedula=cel;
	   nombre=nom;
	   telefono=tel;
       siguiente = signodo;
    }
    
    void nodousuc(int cc);

   private:
   	int compras;
   	string tipo;
    string codigociudad;
    string cedula;
    string nombre;
    string telefono;
    nodousu *siguiente;
    nodousu *anterior;
    
        
   friend class listaDCU;
};
typedef nodousu *pnodousu;

void nodousu::nodousuc(int cc){
	compras+=cc;
}

class lista {
   public:
    lista() { primero = actual = NULL; }
    ~lista();
    
    void InsertarInicio(string v, string n);
    void InsertarFinal(string v, string n);
    void InsertarPos (string v, string n, int pos);
    void EliminarInicio();
    void EliminarFinal();
    void EliminarPos(int pos);
    bool ListaVacia() { return primero == NULL; } 
    void Imprimir();
    void Borrar(int v);
    void Mostrar();
    void Siguiente();
    pnodociudad  Primero();
    string codigo();
    string nombre();
    void Primero2();
    string Ultimo();
    void BorrarFinal();
    void BorrarInicio();
    void borrarPosicion(int pos);
    int largoLista();
    
   private:
    pnodociudad  primero;
    pnodociudad  actual;
};

lista::~lista()
{
   pnodociudad  aux;
   
   while(primero) {
      aux = primero;
      primero = primero->siguiente;
      delete aux;
   }
   actual = NULL;
}

int lista::largoLista(){
    int cont=0;

    pnodociudad  aux;
    aux = primero;
    if(ListaVacia()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }
    
}

void lista::InsertarInicio(string v, string n)
{
   if (ListaVacia())
     primero = new nodociudad (v,n);
   else
     primero=new nodociudad  (v,n,primero);
}
 
void lista::InsertarFinal(string v, string n)
{
   if (ListaVacia())
     primero = new nodociudad(v,n);
   else
     { pnodociudad aux = primero;
        while ( aux->siguiente != NULL)
          aux= aux->siguiente;
        aux->siguiente=new nodociudad(v,n);
      }    
}

void lista::InsertarPos(string v, string n,int pos)
{
   if (ListaVacia())
     primero = new nodociudad(v,n);
   else{
        if(pos <=1){
          pnodociudad nuevo = new nodociudad(v,n);
          nuevo->siguiente= primero;
          primero= nuevo;     
        }      
        else{
             pnodociudad aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= NULL)){
                   i++;
                   aux=aux->siguiente;
             }
             pnodociudad nuevo= new nodociudad(v,n);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             
        }
        }
}
      
void lista::BorrarFinal()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodociudad aux = primero;
                while (aux->siguiente->siguiente != NULL) {
                    aux = aux->siguiente;

                }
                
              pnodociudad temp = aux->siguiente;
              aux->siguiente= NULL;

                
                delete temp;
            }
        }
}

void lista::BorrarInicio()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
        		pnodociudad aux = primero;
                primero= NULL;
                delete aux;
            } else {

                pnodociudad aux = primero;
                primero=primero->siguiente;                
                delete aux;
            }
        }
}

void lista:: borrarPosicion(int pos){
     if(ListaVacia()){
              cout << "Lista vacia" <<endl;
    }else{
         if((pos>largoLista())||(pos<0)){
        cout << "Error en posicion" << endl;
        }else{
        if(pos==1){
        primero=primero->siguiente;
        }else{
          int cont=2;
            pnodociudad aux=  primero;
            while(cont<pos){
             aux=aux->siguiente;
             cont++;
            }
            aux->siguiente=aux->siguiente->siguiente;
            }
        }
     }

}

void lista::Mostrar()
{
   nodociudad *aux;
   
   aux = primero;
   while(aux) {
      cout << aux->codigo<<"->";
      cout << aux->nombre<<"->";
      aux = aux->siguiente;
   }
   //delete aux;
   cout << endl;
}

void lista::Siguiente()
{
   if(actual) actual = actual->siguiente;
}

pnodociudad lista::Primero()
{
   return primero;
}

string lista::codigo()
{
   return actual->codigo;
}

string lista::nombre()
{
   return actual->nombre;
}

void lista::Primero2()
{
   actual = primero;
}

string lista::Ultimo()
{
	 actual = primero;  
   if(!ListaVacia()) {
      while(actual->siguiente) Siguiente();
  }
   return actual->codigo;
}

class listaD {
   public:
    listaD() { primero = actual = NULL; }
    ~listaD();
    
    void InsertarInicio(string v, string c,string n);
    void InsertarFinal(string v, string c,string n);
    void InsertarPos (string v, string c,string n, int pos);
    void EliminarInicio();
    void EliminarFinal();
    void EliminarPos(int pos);
    bool ListaVacia() { return primero == NULL; } 
    void Imprimir();
    void Borrar(int v);
    void Mostrar();
    void Siguiente();
    void Primero();
    void Ultimo();
    void BorrarFinal();
    void BorrarInicio();
    void borrarPosicion(int pos);
    int largoLista();
    string codigo();
    string codigosuper();
    int visitas2();
    void visitas(int v);
    string nombre();
    
   private:
    pnodomercado primero;
    pnodomercado actual;
};

listaD::~listaD()
{
   pnodomercado aux;
   
   while(primero) {
      aux = primero;
      primero = primero->siguiente;
      delete aux;
   }
   actual = NULL;
}

int listaD::largoLista(){
    int cont=0;

    pnodomercado aux;
    aux = primero;
    if(ListaVacia()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }
    
}

void listaD::InsertarInicio(string v, string c,string n)
{
   if (ListaVacia())
     primero = new nodomercado(v,c,n);
   else
   {
     primero=new nodomercado (v,c,n,primero);
     primero->siguiente->anterior=primero;
   }
}
 
void listaD::InsertarFinal(string v, string c,string n)
{
   if (ListaVacia()){
     primero = new nodomercado(v,c,n);
	 }
   else
     { pnodomercado aux = primero;
        while ( aux->siguiente != NULL)
          aux= aux->siguiente;
        aux->siguiente=new nodomercado(v,c,n);
        aux->siguiente->anterior=aux;       
      }    
}

string listaD::codigo()
{
   return actual->codigo;
}

void listaD::visitas(int v){
	actual->visitas(v);
}

int listaD::visitas2(){
	return actual->visita;
}

string listaD::codigosuper()
{
   return actual->codigosuper;
}

string listaD::nombre()
{
   return actual->nombre;
}

void listaD::InsertarPos(string v, string c,string n,int pos)
{
   if (ListaVacia())
     primero = new nodomercado(v,c,n);
   else{
        if(pos <=1)
          InsertarInicio(v,c,n);    
        else
        {
             pnodomercado aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= NULL)){
                   i++;
                   aux=aux->siguiente;
             }
             pnodomercado nuevo= new nodomercado(v,c,n);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             aux->siguiente->anterior=aux;
             nuevo->siguiente->anterior=nuevo;                           
        }
        }
}
      
void listaD::BorrarFinal()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodomercado aux = primero;
                while (aux->siguiente->siguiente != NULL) 
                {
                    aux = aux->siguiente;
                }
                
              pnodomercado temp = aux->siguiente;
              aux->siguiente= NULL;

                
                delete temp;
            }
        }
}

void listaD::BorrarInicio()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodomercado aux = primero;
                primero=primero->siguiente;                
                delete aux;
            }
        }
}

void listaD:: borrarPosicion(int pos)
{
     if(ListaVacia())
     {
              cout << "Lista vacia" <<endl;
     }
     else
     {
        if((pos>largoLista())||(pos<0))
        {
        cout << "Error en posicion" << endl;
        }
        else
        {
        if(pos==1)
           BorrarInicio();
        else
        {
          if (pos == largoLista())   
             BorrarFinal();
          else
          {   
            int cont=2;
            pnodomercado aux=  primero;
            while(cont<pos)
            {
             aux=aux->siguiente;
             cont++;
            }
            pnodomercado temp=aux->siguiente;
            aux->siguiente=aux->siguiente->siguiente;
            aux->siguiente->anterior=aux;
            delete temp;
          }//else
        }//else
      }//else
    }//else
}
 
void listaD::Mostrar()
{
   nodomercado *aux;
   
   aux = primero;
   while(aux) {
      cout << aux->codigo << "-> ";
      cout << aux->codigosuper << "-> ";
      cout << aux->nombre << "-> ";
      aux = aux->siguiente;
   }
   cout << endl;
}

void listaD::Siguiente()
{
   if(actual) actual = actual->siguiente;
}

void listaD::Primero()
{
   actual = primero;
}

void listaD::Ultimo()
{
   actual = primero;  
   if(!ListaVacia()) 
      while(actual->siguiente) Siguiente();
}

class listaDC {
   public:
    listaDC() { primero = actual = NULL; }
    ~listaDC();
    
    void InsertarInicio(string v, string c, string n, string m, string a);
    void InsertarFinal(string v, string c,string n, string m, string a);
    void InsertarPos (string v, string c,string n, string m, string a, int pos);
    void EliminarInicio();
    void EliminarFinal();
    void EliminarPos(int pos);
    bool ListaVacia() { return primero == NULL; } 
    void Imprimir();
    int CCA();
    void variarCC(int CC);
    bool variarCantV(int p);
    void variarCant(int p);
    void variarCant2(int p);
    void variarPre(int p);
    void Borrar(int v);
    void Mostrar();
    void Siguiente();
    void Anterior();
    void Primero();
    void Ultimo();
    void BorrarFinal();
    void BorrarInicio();
    void borrarPosicion(int pos);
    int largoLista();
    int CC();
    string codigoproducto();
    string codigosuper();
    string nombre();
    string cproducto();
    string precio();
    
   private:
    pnodoinv primero;
    pnodoinv actual;
};

listaDC::~listaDC()
{
   pnodoinv aux;
   
   while(primero) {
      aux = primero;
      primero = primero->siguiente;
      delete aux;
   }
   actual = NULL;
}

int listaDC::largoLista(){
    int cont=0;

    pnodoinv aux;
    aux = primero;
    if(ListaVacia()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }
    
}

void listaDC::InsertarInicio(string v, string c,string n, string m, string a)
{
   if (ListaVacia())
     primero = new nodoinv(v,c,n,m,a);
   else
   {
     primero=new nodoinv (v,c,n,m,a,primero);
     primero->siguiente->anterior=primero;
   }
}
 
void listaDC::InsertarFinal(string v, string c,string n, string m, string a)
{
   if (ListaVacia()){
     primero = new nodoinv(v,c,n,m,a);
	 }
   else
     { pnodoinv aux = primero;
        while ( aux->siguiente != NULL)
          aux= aux->siguiente;
        aux->siguiente=new nodoinv(v,c,n,m,a);
        aux->siguiente->anterior=aux;       
      }    
}

string listaDC::codigosuper()
{
   return actual->codigosuper;
}

string listaDC::codigoproducto()
{
   return actual->codigoproducto;
}

string listaDC::nombre()
{
   return actual->nombre;
}

string listaDC::cproducto()
{
   return actual->cantproducto;
}

int listaDC::CC()
{
   return actual->cantComprado;
}

int listaDC::CCA()
{
   return actual->anterior->cantComprado;
}

void listaDC::variarCant(int p){
	string as=actual->cantproducto;
	int y1=atoi(as.c_str());
	y1=y1-p;
	stringstream ss;
	ss<<y1;
	string str=ss.str();
	actual->nodoinvC(str);	
}

void listaDC::variarCant2(int p){
	stringstream ss;
	ss<<p;
	string str=ss.str();
	actual->nodoinvC(str);	
}

void listaDC::variarPre(int p){
	stringstream ss;
	ss<<p;
	string str=ss.str();
	actual->nodoinvP(str);	
}

void listaDC::variarCC(int CC){
	actual->nodoinvCC(CC);	
}

bool listaDC::variarCantV(int p){
	string as=actual->cantproducto;
	int y1=atoi(as.c_str());
	y1=y1-p;
	if(y1<0){
		return false;
	}else{
		return true;
	}
	
}

string listaDC::precio()
{
   return actual->precio;
}

void listaDC::InsertarPos(string v, string c,string n, string m, string a, int pos)
{
   if (ListaVacia())
     primero = new nodoinv(v,c,n,m,a);
   else{
        if(pos <=1)
          InsertarInicio(v,c,n,m,a);    
        else
        {
             pnodoinv aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= NULL)){
                   i++;
                   aux=aux->siguiente;
             }
             pnodoinv nuevo= new nodoinv(v,c,n,m,a);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             aux->siguiente->anterior=aux;
             nuevo->siguiente->anterior=nuevo;                           
        }
        }
}
      
void listaDC::BorrarFinal()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodoinv aux = primero;
                while (aux->siguiente->siguiente != NULL) 
                {
                    aux = aux->siguiente;
                }
                
              pnodoinv temp = aux->siguiente;
              aux->siguiente= NULL;

                
                delete temp;
            }
        }
}

void listaDC::BorrarInicio()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodoinv aux = primero;
                primero=primero->siguiente;                
                delete aux;
            }
        }
}


void listaDC:: borrarPosicion(int pos)
{
     if(ListaVacia())
     {
              cout << "Lista vacia" <<endl;
     }
     else
     {
        if((pos>largoLista())||(pos<0))
        {
        cout << "Error en posicion" << endl;
        }
        else
        {
        if(pos==1)
           BorrarInicio();
        else
        {
          if (pos == largoLista())   
             BorrarFinal();
          else
          {   
            int cont=2;
            pnodoinv aux=  primero;
            while(cont<pos)
            {
             aux=aux->siguiente;
             cont++;
            }
            pnodoinv temp=aux->siguiente;
            aux->siguiente=aux->siguiente->siguiente;
            aux->siguiente->anterior=aux;
            delete temp;
          }//else
        }//else
      }//else
    }//else
}
 

void listaDC::Mostrar()
{
   nodoinv *aux;
   
   aux = primero;
   while(aux) {
      cout << aux->codigosuper << "-> ";
      cout << aux->codigoproducto << "-> ";
      cout << aux->nombre << "-> ";
      cout << aux->cantproducto << "-> ";
      cout << aux->precio<< "-> ";
      aux = aux->siguiente;
   }
   cout << endl;
}

void listaDC::Siguiente()
{
   if(actual) actual = actual->siguiente;
}

void listaDC::Anterior()
{
   if(actual) actual = actual->anterior;
}


void listaDC::Primero()
{
   actual = primero;
}

void listaDC::Ultimo()
{
   actual = primero;  
   if(!ListaVacia()) 
      while(actual->siguiente) Siguiente();
}

class listaDCU {
   public:
    listaDCU() { primero = actual = NULL; }
    ~listaDCU();
    
    void InsertarInicio(string v, string c, string n, string m);
    void InsertarFinal(string v, string c,string n, string m);
    void InsertarPos (string v, string c,string n, string m, int pos);
    void EliminarInicio();
    void EliminarFinal();
    void EliminarPos(int pos);
    bool ListaVacia() { return primero == NULL; } 
    void Imprimir();
    void Borrar(int v);
    void Mostrar();
    void Siguiente();
    void Primero();
    void Ultimo();
    void BorrarFinal();
    void BorrarInicio();
    void borrarPosicion(int pos);
    int largoLista();
    void compras2(int cc);
    int compras();
    string codigociudad();
    string cedula();
    string nombre();
    string telefono();
    string cproducto();
    string precio();
    void InsertarType(string v);
    
   private:
    pnodousu primero;
    pnodousu actual;
};

listaDCU::~listaDCU()
{
   pnodousu aux;
   
   while(primero) {
      aux = primero;
      primero = primero->siguiente;
      delete aux;
   }
   actual = NULL;
}

int listaDCU::largoLista(){
    int cont=0;

    pnodousu aux;
    aux = primero;
    if(ListaVacia()){
        return cont;
    }else{
        while(aux!=NULL){
        aux=aux->siguiente;
        cont++;
    }
    return cont;
    }
    
}

void listaDCU::InsertarType(string v)
{
     primero = new nodousu(v);
}

void listaDCU::InsertarInicio(string v, string c,string n, string m)
{
   if (ListaVacia())
     primero = new nodousu(v,c,n,m);
   else
   {
     primero=new nodousu (v,c,n,m,primero);
     primero->siguiente->anterior=primero;
   }
}
 
void listaDCU::InsertarFinal(string v, string c,string n, string m)
{
   if (ListaVacia()){
     primero = new nodousu(v,c,n,m);
	 }
   else
     { pnodousu aux = primero;
        while ( aux->siguiente != NULL)
          aux= aux->siguiente;
        aux->siguiente=new nodousu(v,c,n,m);
        aux->siguiente->anterior=aux;       
      }    
}

void listaDCU::compras2(int cc){
	actual->nodousuc(cc);
}

int listaDCU::compras()
{
   return actual->compras;
}

string listaDCU::codigociudad()
{
   return actual->codigociudad;
}

string listaDCU::cedula()
{
   return actual->cedula;
}

string listaDCU::nombre()
{
   return actual->nombre;
}

string listaDCU::telefono()
{
   return actual->telefono;
}

void listaDCU::InsertarPos(string v, string c,string n, string m, int pos)
{
   if (ListaVacia())
     primero = new nodousu(v,c,n,m);
   else{
        if(pos <=1)
          InsertarInicio(v,c,n,m);    
        else
        {
             pnodousu aux= primero;
             int i =2;
             while((i != pos )&&(aux->siguiente!= NULL)){
                   i++;
                   aux=aux->siguiente;
             }
             pnodousu nuevo= new nodousu(v,c,n,m);
             nuevo->siguiente=aux->siguiente;
             aux->siguiente=nuevo;
             aux->siguiente->anterior=aux;
             nuevo->siguiente->anterior=nuevo;                           
        }
        }
}
      
void listaDCU::BorrarFinal()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodousu aux = primero;
                while (aux->siguiente->siguiente != NULL) 
                {
                    aux = aux->siguiente;
                }
                
              pnodousu temp = aux->siguiente;
              aux->siguiente= NULL;

                
                delete temp;
            }
        }
}

void listaDCU::BorrarInicio()
{
    if (ListaVacia()){
     cout << "No hay elementos en la lista:" << endl;
    
   }else{
        if (primero->siguiente == NULL) {
                primero= NULL;
            } else {

                pnodousu aux = primero;
                primero=primero->siguiente;                
                delete aux;
            }
        }
}

void listaDCU:: borrarPosicion(int pos)
{
     if(ListaVacia())
     {
              cout << "Lista vacia" <<endl;
     }
     else
     {
        if((pos>largoLista())||(pos<0))
        {
        cout << "Error en posicion" << endl;
        }
        else
        {
        if(pos==1)
           BorrarInicio();
        else
        {
          if (pos == largoLista())   
             BorrarFinal();
          else
          {   
            int cont=2;
            pnodousu aux=  primero;
            while(cont<pos)
            {
             aux=aux->siguiente;
             cont++;
            }
            pnodousu temp=aux->siguiente;
            aux->siguiente=aux->siguiente->siguiente;
            aux->siguiente->anterior=aux;
            delete temp;
          }//else
        }//else
      }//else
    }//else
}
 
void listaDCU::Mostrar()
{
   nodousu *aux;
   
   aux = primero;
   while(aux) {
   	  if(aux==primero){
   	  	cout<<aux->tipo<<"->";
		 }else{
      cout << aux->codigociudad << "-> ";
      cout << aux->cedula << "-> ";
      cout << aux->nombre << "-> ";
      cout << aux->telefono << "-> ";
  	  }
  	  aux = aux->siguiente;
   }
   cout << endl;
}

void listaDCU::Siguiente()
{
   if(actual) actual = actual->siguiente;
}

void listaDCU::Primero()
{
   actual = primero;
}

void listaDCU::Ultimo()
{
   actual = primero;  
   if(!ListaVacia()) 
      while(actual->siguiente) Siguiente();
}

void split(char char1[128],lista& Lista,int var, int inicio, int tipo){
	int cont=0;
	int cont2=0;
	int contvar=-inicio+1;
	bool band=true;
	char aux[1]={';'};
	char char2[128]={0};
	char char3[128]={0};
	//cout<<char2<<endl;
	while(char1[cont]!='\0'){
		if(band==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char2[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			cont2=0;
			//cout<<char2<<endl;
			
			cont2=0;
			cont++;
			contvar++;
			band=false;		
		}else{
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char3[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=false;	
		}	
	}
	bool b=true;
	Lista.Primero2();
	for(int i=0;i<Lista.largoLista();i=i+1){
		//cout<<Lista.codigo()<<"  "<<char2<<"  "<<b<<endl;
		if(Lista.codigo()==char2){
			b=false;
		}
		Lista.Siguiente();
	}
	if(b==true){
	Lista.InsertarFinal(char2,char3);
    }
	//return char1;
}

void split(char char1[128],listaD& Lista,int var, int inicio, int tipo,lista& com){
	int cont=0;
	int cont2=0;
	int contvar=-inicio+1;
	int band=0;
	bool here=true;
	char aux[1]={';'};
	char char2[128]={0};
	char char3[128]={0};
	char char4[128]={0};
	//cout<<char2<<endl;
	while(char1[cont]!='\0'){
		here=true;
		if(band==0 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char2[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			cont2=0;
			//cout<<char2<<endl;
			
			cont2=0;
			cont++;
			contvar++;
			band=1;	
			here=false;
				
		}if(band==1 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char3[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=2;	
			
		}if(band==2 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char4[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=2;	
		}	
	}
	bool b=true;
	bool c=false;
	Lista.Primero();
	for(int i=0;i<Lista.largoLista();i=i+1){
		//cout<<Lista.codigo()<<"  "<<char2<<"  "<<b<<endl;
		if(Lista.codigosuper()==char3){
			b=false;
		}
		Lista.Siguiente();
	}
	com.Primero2();
	for(int i=0;i<com.largoLista();i=i+1){
		//cout<<Lista.codigo()<<"  "<<char2<<"  "<<b<<endl;
		if(com.codigo()==char2){
			c=true;
		}
		com.Siguiente();
	}
	
	if(b==true and c==true){
		Lista.InsertarFinal(char2,char3,char4);
    }
	//return char1;
}

void split(char char1[128],listaDC& Lista,int var, int inicio, int tipo,listaD& com){
	int cont=0;
	int cont2=0;
	int contvar=-inicio+1;
	int band=0;
	bool here=true;
	char aux[1]={';'};
	char char2[128]={0};
	char char3[128]={0};
	char char4[128]={0};
	char char5[128]={0};
	char char6[128]={0};
	//cout<<char2<<endl;
	while(char1[cont]!='\0'){
		here=true;
		if(band==0 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char2[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			cont2=0;
			//cout<<char2<<endl;
			
			cont2=0;
			cont++;
			contvar++;
			band=1;	
			here=false;
				
		}if(band==1 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char3[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=2;	
			
		}if(band==2 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char4[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=3;	
			
		}if(band==3 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char5[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
				//cout<<char5<<endl;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=4;	
			//cout<<char5;
		}if(band==4 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char6[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=5;	
		}
	}
	bool b=true;
	bool c=false;
	Lista.Primero();
	for(int i=0;i<Lista.largoLista();i=i+1){
		//cout<<Lista.codigo()<<"  "<<char2<<"  "<<b<<endl;
		if(Lista.codigoproducto()==char3){
			b=false;
		}
		Lista.Siguiente();
	}
	com.Primero();
	for(int i=0;i<com.largoLista();i=i+1){
		//cout<<Lista.codigo()<<"  "<<char2<<"  "<<b<<endl;
		if(com.codigosuper()==char2){
			c=true;
		}
		com.Siguiente();
	}
	if(b==true and c==true){
		//cout<<"AAAA"<<char2<<"  "<<char3<<"  "<<char4<<"  "<<char5<<"  "<<char6<<endl;
		Lista.InsertarFinal(char2,char3,char4,char5,char6);
    }
	//return char1;
}

void split(char char1[128],listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,int var, int inicio, int tipo,lista& com){
	int cont=0;
	int cont2=0;
	int contvar=-inicio+1;
	int band=0;
	bool here=true;
	char aux[1]={';'};
	char char2[128]={0};
	char char3[128]={0};
	char char4[128]={0};
	char char5[128]={0};
	char char6[128]={0};
	while(char1[cont]!='\0'){
		here=true;
		if(band==0 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char2[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			cont2=0;
			//cout<<char2<<endl;
			
			cont2=0;
			cont++;
			contvar++;
			band=1;	
			here=false;
				
		}if(band==1 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char3[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=2;	
			
		}if(band==2 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char4[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=3;	
			
		}if(band==3 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char5[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
				//cout<<char5<<endl;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=4;	
			//cout<<char5;
		}if(band==4 and here==true){
			while(char1[cont]!=';' and char1[cont]!='\0'){
				char6[cont2]=char1[cont];
				//cout<<char1<<"  "<<char1[cont]<<" ";
				cont++;
				cont2++;
			}
			//cout<<char3<<endl;
			cont2=0;
			cont++;
			contvar++;
			band=5;	
		}
	}
	if(char6[0]=='0'){
		bool b=true;
		bool c=false;
		Lista0.Primero();
		for(int i=0;i<Lista0.largoLista();i=i+1){
			if(Lista0.cedula()==char3){
				b=false;
			}
			Lista0.Siguiente();
		}
	Lista1.Primero();
		for(int i=0;i<Lista1.largoLista();i=i+1){
			if(Lista1.cedula()==char3){
				b=false;
			}
			Lista1.Siguiente();
		}
	Lista2.Primero();
		for(int i=0;i<Lista2.largoLista();i=i+1){
			if(Lista2.cedula()==char3){
				b=false;
			}
			Lista2.Siguiente();
		}
	Lista3.Primero();
		for(int i=0;i<Lista3.largoLista();i=i+1){
			if(Lista3.cedula()==char3){
				b=false;
			}
			Lista3.Siguiente();
		}
		com.Primero2();
		for(int i=0;i<com.largoLista();i=i+1){
			if(com.codigo()==char2){
				c=true;
			}
			com.Siguiente();
		}
		if(b==true and c==true){
			Lista0.InsertarFinal(char2,char3,char4,char5);
	    }
	}
	if(char6[0]=='1'){
		bool b=true;
		bool c=false;
		Lista0.Primero();
		for(int i=0;i<Lista0.largoLista();i=i+1){
			if(Lista0.cedula()==char3){
				b=false;
			}
			Lista0.Siguiente();
		}
	Lista1.Primero();
		for(int i=0;i<Lista1.largoLista();i=i+1){
			if(Lista1.cedula()==char3){
				b=false;
			}
			Lista1.Siguiente();
		}
	Lista2.Primero();
		for(int i=0;i<Lista2.largoLista();i=i+1){
			if(Lista2.cedula()==char3){
				b=false;
			}
			Lista2.Siguiente();
		}
	Lista3.Primero();
		for(int i=0;i<Lista3.largoLista();i=i+1){
			if(Lista3.cedula()==char3){
				b=false;
			}
			Lista3.Siguiente();
		}
		com.Primero2();
		for(int i=0;i<com.largoLista();i=i+1){
			if(com.codigo()==char2){
				c=true;
			}
			com.Siguiente();
		}
		if(b==true and c==true){
			Lista1.InsertarFinal(char2,char3,char4,char5);
	    }
	}
	if(char6[0]=='2'){
		bool b=true;
		bool c=false;
		Lista0.Primero();
		for(int i=0;i<Lista0.largoLista();i=i+1){
			if(Lista0.cedula()==char3){
				b=false;
			}
			Lista0.Siguiente();
		}
	Lista1.Primero();
		for(int i=0;i<Lista1.largoLista();i=i+1){
			if(Lista1.cedula()==char3){
				b=false;
			}
			Lista1.Siguiente();
		}
	Lista2.Primero();
		for(int i=0;i<Lista2.largoLista();i=i+1){
			if(Lista2.cedula()==char3){
				b=false;
			}
			Lista2.Siguiente();
		}
	Lista3.Primero();
		for(int i=0;i<Lista3.largoLista();i=i+1){
			if(Lista3.cedula()==char3){
				b=false;
			}
			Lista3.Siguiente();
		}
		com.Primero2();
		for(int i=0;i<com.largoLista();i=i+1){
			if(com.codigo()==char2){
				c=true;
			}
			com.Siguiente();
		}
		if(b==true and c==true){
			Lista2.InsertarFinal(char2,char3,char4,char5);
	    }
	}
	if(char6[0]=='3'){
		bool b=true;
		bool c=false;
		Lista0.Primero();
		for(int i=0;i<Lista0.largoLista();i=i+1){
			if(Lista0.cedula()==char3){
				b=false;
			}
			Lista0.Siguiente();
		}
	Lista1.Primero();
		for(int i=0;i<Lista1.largoLista();i=i+1){
			if(Lista1.cedula()==char3){
				b=false;
			}
			Lista1.Siguiente();
		}
	Lista2.Primero();
		for(int i=0;i<Lista2.largoLista();i=i+1){
			if(Lista2.cedula()==char3){
				b=false;
			}
			Lista2.Siguiente();
		}
	Lista3.Primero();
		for(int i=0;i<Lista3.largoLista();i=i+1){
			if(Lista3.cedula()==char3){
				b=false;
			}
			Lista3.Siguiente();
		}
		com.Primero2();
		for(int i=0;i<com.largoLista();i=i+1){
			if(com.codigo()==char2){
				c=true;
			}
			com.Siguiente();
		}
		//cout<<b<<" AQUIIIIIIIIIIIII "<<c<<endl;
		if(b==true and c==true){
			//cout<<"AAAA"<<char2<<"  "<<char3<<"  "<<char4<<"  "<<char5<<"  "<<char6<<endl;
			Lista3.InsertarFinal(char2,char3,char4,char5);
	    }
	}
	//return char1;
}

cargarArch(lista& Lista,int var1,int var2,ifstream& arch,int tipo){	
	char linea[128];
	//char char10[128];
	long cont=0L;
	int conta=0;
	while(!arch.eof()){
		arch.getline(linea,sizeof(linea));
		split(linea,Lista,var1,var2,tipo);
		//cout<<"LINEAAAAA   "<<linea<<endl;
		while(conta<128){
			linea[conta]=0;
			conta++;
		}
		conta=0;
		//cout<<linea<<endl;
		//cout<<"Insertado"<<endl;
		//ListaSimpleCiudades.InsertarFinal(linea);		
	}
	arch.close();
	//Lista.Mostrar();
}

cargarArch(listaD& Lista,int var1,int var2,ifstream& arch,int tipo,lista& com){	
	char linea[128];
	//char char10[128];
	long cont=0L;
	int conta=0;
	while(!arch.eof()){
		arch.getline(linea,sizeof(linea));
		split(linea,Lista,var1,var2,tipo,com);
		//cout<<"LINEAAAAA   "<<linea<<endl;
		while(conta<128){
			linea[conta]=0;
			conta++;
		}
		conta=0;
		//cout<<linea<<endl;
		//cout<<"Insertado"<<endl;
		//ListaSimpleCiudades.InsertarFinal(linea);		
	}
	arch.close();
	//Lista.Mostrar();
}

cargarArch(listaDC& Lista,int var1,int var2,ifstream& arch,int tipo,listaD& com){	
	char linea[128];
	//char char10[128];
	long cont=0L;
	int conta=0;
	while(!arch.eof()){
		arch.getline(linea,sizeof(linea));
		split(linea,Lista,var1,var2,tipo,com);
		//cout<<"LINEAAAAA   "<<linea<<endl;
		while(conta<128){
			linea[conta]=0;
			conta++;
		}
		conta=0;
		//cout<<linea<<endl;
		//cout<<"Insertado"<<endl;
		//ListaSimpleCiudades.InsertarFinal(linea);		
	}
	arch.close();
	//Lista.Mostrar();
}

cargarArch(listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,int var1,int var2,ifstream& arch,int tipo,lista& com){	
	char linea[128];
	//char char10[128];
	long cont=0L;
	int conta=0;
	while(!arch.eof()){
		arch.getline(linea,sizeof(linea));
		split(linea,Lista0,Lista1,Lista2,Lista3,var1,var2,tipo,com);
		//cout<<"LINEAAAAA   "<<linea<<endl;
		while(conta<128){
			linea[conta]=0;
			conta++;
		}
		conta=0;
		//cout<<linea<<endl;
		//cout<<"Insertado"<<endl;
		//ListaSimpleCiudades.InsertarFinal(linea);		
	}
	arch.close();
	//Lista0.Mostrar();
	//Lista1.Mostrar();
	//Lista2.Mostrar();
	//Lista3.Mostrar();
}

void menuclientes(lista& ListaSimpleCiudades,listaD& ListaDobleSuper,listaDC& ListaDobleCircularInventario,listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,string cedu,bool isCliente,listaDCU& listaSolicitud){
	bool salir=false;
	string opc;
	listaDC Carrito;
	string cns="0";
	int cn=1;
	while(not salir){
		if(isCliente==true){
			cout<<"1. Consultar Precio"<<endl<<"2. Consultar Descuento"<<endl<<"3. Consultar Productos"<<endl<<"4. Comprar ( Carrito)"<<endl<<"5. Facturacion"<<endl<<"6. Salir"<<endl<<"Digite su opcion: ";
			getline(cin,opc);
			if(opc=="1"){
				cout<<"Digite el codigo del producto a consultar: ";
				string pro;
				getline(cin,pro);
				cout<<endl;
				ListaDobleCircularInventario.Primero();
				bool veri=false;
				for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
					//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
					if(ListaDobleCircularInventario.codigoproducto()==pro){
						veri=true;
						cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl;
					}
					ListaDobleCircularInventario.Siguiente();
				}
				if(veri==false){
					cout<<"El producto no existe"<<endl;
				}
			}
			else if(opc=="2"){
				cout<<"El descuento es de 5%: ";
				cout<<endl;
			}
			else if(opc=="3"){
				cout<<"Digite el codigo del supermercado a consultar: ";
				string pro;
				getline(cin,pro);
				cout<<endl;
				ListaDobleCircularInventario.Primero();
				bool veri=false;
				for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
					//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
					if(ListaDobleCircularInventario.codigosuper()==pro){
						veri=true;
						cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
					}
					ListaDobleCircularInventario.Siguiente();
				}
				if(veri==false){
					cout<<"El producto no existe"<<endl;
				}
			}
			else if(opc=="4"){
				cout<<"Digite el codigo del supermercado: ";
				string super;
				getline(cin,super);
				cout<<endl;
				ListaDobleSuper.Primero();
				//ListaDobleCircularInventario.Primero();
				bool veri=false;
				for(int i=0;i<ListaDobleSuper.largoLista();i++){
					//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
					if(ListaDobleSuper.codigosuper()==super){
						veri=true;
					}
					ListaDobleSuper.Siguiente();
				}
				if(veri==false){
					cout<<"El supermercado no existe"<<endl;
				}else{
					cout<<"Digite el codigo del producto: ";
					string pro;
					getline(cin,pro);
					cout<<endl;
					cout<<"Digite la cantidad que desea: ";
					string cant;
					getline(cin,cant);
					cout<<endl;
					ListaDobleCircularInventario.Primero();
					veri=false;
					for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
						//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
						if(ListaDobleCircularInventario.codigoproducto()==pro and ListaDobleCircularInventario.codigosuper()==super){
							veri=true;
							int y1=atoi(cant.c_str());
							if(ListaDobleCircularInventario.variarCantV(y1)==true){
								ListaDobleCircularInventario.variarCC(y1);
								
								ListaDobleSuper.Primero();
								for(int u=0;u<ListaDobleSuper.largoLista();u++){
									if(ListaDobleSuper.codigosuper()==super){
										ListaDobleSuper.visitas(1);
									}
									ListaDobleSuper.Siguiente();
								}
								
								Lista0.Primero();
								for(int o=0;o<Lista0.largoLista();o++){
									if(Lista0.cedula()==cedu){
										Lista0.compras2(1);
									}
									Lista0.Siguiente();
								}
								
								ListaDobleCircularInventario.variarCant(y1);
								Carrito.InsertarFinal(ListaDobleCircularInventario.codigosuper(),ListaDobleCircularInventario.codigoproducto(),ListaDobleCircularInventario.nombre(),cant,ListaDobleCircularInventario.precio());
								//Carrito.Mostrar();
								//ListaDobleCircularInventario.Mostrar();
							}else{
								cout<<"No hay suficientes unidades de este producto"<<endl;
							}
						}
						ListaDobleCircularInventario.Siguiente();
					}
					if(veri==false){
						cout<<"El producto no existe"<<endl;
					}
				}
			}
			else if(opc=="5"){
				int ae=atoi(cns.c_str());
				stringstream ss;
				ae=ae+cn;
				ss<<ae;
				cns=ss.str();
				ofstream report(("Factura"+cns+".txt").c_str());
				report<<"Consecutivo Factura: "<<cns<<endl<<endl;
				Lista0.Primero();
				for(int i=0;i<Lista0.largoLista();i++){
					if(Lista0.cedula()==cedu){
						report<<"Cedula: "<<cedu<<endl;
						report<<"Nombre: "<<Lista0.nombre()<<endl;
						report<<"Telefono: "<<Lista0.telefono()<<endl;
						if(Carrito.ListaVacia()==false){
							Carrito.Primero();
							double suma=0;
							double mult=0;
							double fin=0;
							report<<"Codigo del supermercado: "<<Carrito.codigosuper()<<endl;
							while(Carrito.ListaVacia()==false){
								Carrito.Primero();
								report<<"Producto: "<<Carrito.nombre()<<endl;
								report<<"Precio unitario: "<<Carrito.precio()<<endl;
								report<<"Cantidad del articulo: "<<Carrito.cproducto()<<endl;
								suma=atoi(Carrito.precio().c_str());
								mult=atoi(Carrito.cproducto().c_str());
								report<<"Total del producto: "<<suma*mult<<endl<<endl;
								fin+=suma*mult;
								Carrito.BorrarInicio();
							}
							report<<"TOTAL: "<<fin<<endl;
							report<<"Descuento: "<<fin*0.05<<endl;
							report<<"Total con descuento: "<<fin-(fin*0.05)<<endl<<endl;
						}else{
							cout<<"El carrito esta vacio"<<endl;
						}
					}
					Lista0.Siguiente();
				}
				report.close();
				//cn+=1;
			}
			else if(opc=="6"){
				salir=true;
			}
			else{
				cout<<"Error digite una opcion valida"<<endl;
			}
		}else{
			cout<<"1. Consultar Precio"<<endl<<"2. Consultar Descuento"<<endl<<"3. Consultar Productos"<<endl<<"4. Comprar ( Carrito)"<<endl<<"5. Facturacion"<<endl<<"6. REGISTRARSE"<<endl<<"7. Salir"<<endl<<"Digite su opcion: ";
			getline(cin,opc);
			if(opc=="1"){
				cout<<"Digite el codigo del producto a consultar: ";
				string pro;
				getline(cin,pro);
				cout<<endl;
				ListaDobleCircularInventario.Primero();
				bool veri=false;
				for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
					//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
					if(ListaDobleCircularInventario.codigoproducto()==pro){
						veri=true;
						cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl;
					}
					ListaDobleCircularInventario.Siguiente();
				}
				if(veri==false){
					cout<<"El producto no existe"<<endl;
				}
			}else if(opc=="2"){
				cout<<endl<<"DEBE ESTAR REGISTRADO PARA USAR ESTE SERVICIO"<<endl;
			}else if(opc=="3"){
				cout<<"Digite el codigo del supermercado a consultar: ";
				string pro;
				getline(cin,pro);
				cout<<endl;
				ListaDobleCircularInventario.Primero();
				bool veri=false;
				for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
					//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
					if(ListaDobleCircularInventario.codigosuper()==pro){
						veri=true;
						cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
					}
					ListaDobleCircularInventario.Siguiente();
				}
				if(veri==false){
					cout<<"El producto no existe"<<endl;
				}
			}else if(opc=="4"){
				cout<<endl<<"DEBE ESTAR REGISTRADO PARA USAR ESTE SERVICIO"<<endl;
			}else if(opc=="5"){
				cout<<endl<<"DEBE ESTAR REGISTRADO PARA USAR ESTE SERVICIO"<<endl;
			}else if(opc=="6"){
				//cout<<"Cedula :"<<cedu<<endl;
				cout<<"Digite su nombre: ";
				string nm;
				getline(cin,nm);
				cout<<"Digite el codigo de su ciudad: ";
				string cm;
				getline(cin,cm);
				cout<<"Digite su numero de telefono: ";
				string tm;
				getline(cin,tm);
				char nm1[128];
				char cm1[128];
				char tm1[128];
				strcpy(nm1,nm.c_str());
				strcpy(cm1,cm.c_str());
				strcpy(tm1,tm.c_str());
				//char cedu1[128];
				//cout<<cm<<cedu<<nm<<tm<<endl;
				listaSolicitud.InsertarFinal(cm,cedu,nm1,tm);
				//listaSolicitud.Mostrar();
				cout<<endl<<"Usted se encuentra en la lista de espera"<<endl;
			}else if(opc=="7"){
				salir=true;
			}else{
				cout<<"Error digite una opcion valida"<<endl;
			}
		}
	}
}

void menuvendedores(lista& ListaSimpleCiudades,listaD& ListaDobleSuper,listaDC& ListaDobleCircularInventario,listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,string cedu){
	bool salir=false;
	string opc;
	listaDC Carrito;
	string cns="0";
	int cn=1;
	while(not salir){
		cout<<"1. Consultar Precio de un producto"<<endl<<"2. Consultar Descuento de un cliente"<<endl<<"3. Consultar Productos de un super"<<endl<<"4. Salir"<<endl<<"Digite su opcion: ";
		getline(cin,opc);
		if(opc=="1"){
			cout<<"Digite el codigo del producto a consultar: ";
			string pro;
			getline(cin,pro);
			cout<<endl;
			ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleCircularInventario.codigoproducto()==pro){
					veri=true;
					cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<"El producto no existe"<<endl;
			}
		}
		else if(opc=="2"){
			cout<<"El descuento es de 5%: ";
			cout<<endl;
		}
		else if(opc=="3"){
			cout<<"Digite el codigo del supermercado a consultar: ";
			string pro;
			getline(cin,pro);
			cout<<endl;
			ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleCircularInventario.codigosuper()==pro){
					veri=true;
					cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<"El producto no existe"<<endl;
			}
		}else if(opc=="4"){
			salir=true;
		}else{
			cout<<"Error digite una opcion valida"<<endl;
		}
	}
}

void menufuncionario(lista& ListaSimpleCiudades,listaD& ListaDobleSuper,listaDC& ListaDobleCircularInventario,listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,string cedu){
	bool salir=false;
	string opc;
	listaDC Carritof;
	string cns="0";
	int cn=1;
	int extra=1;
	bool descuentoactivo=false;
	while(not salir){
		cout<<"1. Consultar Precio"<<endl<<"2. Consultar Descuento"<<endl<<"3. Consultar Productos"<<endl<<"4. Comprar ( Carrito)"<<endl<<"5. Facturacion"<<endl<<"6. Descuento extra"<<endl<<"7. Salir"<<endl<<"Digite su opcion: ";
		getline(cin,opc);
		if(opc=="1"){
			cout<<"Digite el codigo del producto a consultar: ";
			string pro;
			getline(cin,pro);
			cout<<endl;
			ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleCircularInventario.codigoproducto()==pro){
					veri=true;
					cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<"El producto no existe"<<endl;
			}
		}
		else if(opc=="2"){
			if(descuentoactivo==false){
				cout<<endl<<"El descuento es de 5%"<<endl;
			}else{
				cout<<endl<<"El descuento es de 10%"<<endl;
			}
			cout<<endl;
		}
		else if(opc=="3"){
			cout<<"Digite el codigo del supermercado a consultar: ";
			string pro;
			getline(cin,pro);
			cout<<endl;
			ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleCircularInventario.codigosuper()==pro){
					veri=true;
					cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<"El producto no existe"<<endl;
			}
		}
		else if(opc=="4"){
			cout<<"Digite el codigo del supermercado: ";
			string super;
			getline(cin,super);
			cout<<endl;
			ListaDobleSuper.Primero();
			//ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleSuper.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleSuper.codigosuper()==super){
					veri=true;
				}
				ListaDobleSuper.Siguiente();
			}
			if(veri==false){
				cout<<"El supermercado no existe"<<endl;
			}else{
				cout<<"Digite el codigo del producto: ";
				string pro;
				getline(cin,pro);
				cout<<endl;
				cout<<"Digite la cantidad que desea: ";
				string cant;
				getline(cin,cant);
				cout<<endl;
				ListaDobleCircularInventario.Primero();
				veri=false;
				for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
					//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
					if(ListaDobleCircularInventario.codigoproducto()==pro and ListaDobleCircularInventario.codigosuper()==super){
						veri=true;
						int y1=atoi(cant.c_str());
						if(ListaDobleCircularInventario.variarCantV(y1)==true){
							ListaDobleCircularInventario.variarCC(y1);
							
							ListaDobleSuper.Primero();
								for(int o=0;o<ListaDobleSuper.largoLista();o++){
									if(ListaDobleSuper.codigosuper()==super){
										ListaDobleSuper.visitas(1);
									}
									ListaDobleSuper.Siguiente();
								}
							
							ListaDobleCircularInventario.variarCant(y1);
							Carritof.InsertarFinal(ListaDobleCircularInventario.codigosuper(),ListaDobleCircularInventario.codigoproducto(),ListaDobleCircularInventario.nombre(),cant,ListaDobleCircularInventario.precio());
							//Carrito.Mostrar();
							//ListaDobleCircularInventario.Mostrar();
						}else{
							cout<<"No hay suficientes unidades de este producto"<<endl;
						}
					}
					ListaDobleCircularInventario.Siguiente();
				}
				if(veri==false){
					cout<<"El producto no existe"<<endl;
				}
			}
		}
		else if(opc=="5"){
			int ae=atoi(cns.c_str());
			stringstream ss;
			ae=ae+cn;
			ss<<ae;
			cns=ss.str();
			ofstream report(("FacturaFuncionario"+cns+".txt").c_str());
			report<<"Consecutivo Factura: "<<cns<<endl<<endl;
			Lista3.Primero();
			for(int i=0;i<Lista3.largoLista();i++){
				if(Lista3.cedula()==cedu){
					report<<"Cedula: "<<cedu<<endl;
					report<<"Nombre: "<<Lista3.nombre()<<endl;
					report<<"Telefono: "<<Lista3.telefono()<<endl;
					if(Carritof.ListaVacia()==false){
						Carritof.Primero();
						double suma=0;
						double mult=0;
						double fin=0;
						report<<"Codigo del supermercado: "<<Carritof.codigosuper()<<endl;
						while(Carritof.ListaVacia()==false){
							Carritof.Primero();
							report<<"Producto: "<<Carritof.nombre()<<endl;
							report<<"Precio unitario: "<<Carritof.precio()<<endl;
							report<<"Cantidad del articulo: "<<Carritof.cproducto()<<endl;
							suma=atoi(Carritof.precio().c_str());
							mult=atoi(Carritof.cproducto().c_str());
							report<<"Total del producto: "<<suma*mult<<endl<<endl;
							fin+=suma*mult;
							Carritof.BorrarInicio();
						}
						report<<"TOTAL: "<<fin<<endl;
						report<<"Descuento: "<<fin*(0.05*extra)<<endl;
						report<<"Total con descuento: "<<fin-(fin*(0.05*extra))<<endl<<endl;
					}else{
						cout<<"El carrito esta vacio"<<endl;
					}
				}
				Lista3.Siguiente();
			}
			report.close();
			//cn+=1;
		}
		else if(opc=="6"){
			bool otrosalir=false;
			if(descuentoactivo==false){
				string opc2;
				cout<<endl<<"Desea usar su 5% de descuento extra?"<<endl<<"Digite 1 si desea usarlo"<<endl<<"Digite 2 si no desea hacerlo"<<endl;
				while(not otrosalir){
					cout<<"Digite su opcion: ";
					getline(cin,opc2);
					cout<<endl;
					if(opc2=="1"){
						extra=2;
						descuentoactivo=true;
						cout<<endl<<"Su decuento extra esta activo"<<endl;
						otrosalir=true;
					}else if(opc2=="2"){
						otrosalir=true;
					}else{
						cout<<endl<<"Error, digite una opcion valida"<<endl;
					}
				}
			}else{
				cout<<endl<<"Ya tiene el descuento activo"<<endl;
			}
		}
		else if(opc=="7"){
			salir=true;
		}
		else{
			cout<<"Error digite una opcion valida"<<endl;
		}
	}
}

void menuadmin(lista& ListaSimpleCiudades,listaD& ListaDobleSuper,listaDC& ListaDobleCircularInventario,listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,string cedu,listaDCU& listaSolicitud){
	bool salir=false;
	bool isModi=false;
	bool isEli=false;
	string opc;
	listaDC Temporal;
	Temporal.InsertarInicio("000","000","000","000","000");
	//Temporal.Mostrar();
	listaDC TemporalEli;
	TemporalEli.InsertarInicio("000","000","000","000","000");
	string cns="0";
	int cn=1;
	int extra=1;
	bool descuentoactivo=false;
	while(not salir){
		cout<<"1. Insertar Producto"<<endl<<"2. Eliminar Producto"<<endl<<"3. Modificar Producto"<<endl<<"4. Consultar Precio"<<endl<<"5. Consultar Descuentos"<<endl<<"6. Consultar Productos de un Super"<<endl<<"7. Registrar Clientes"<<endl<<"8. Reportes"<<endl<<"9. Salir"<<endl<<"Digite su opcion: ";
		getline(cin,opc);
		if(opc=="1"){
			//ListaDobleCircularInventario.Mostrar();
			string super;
			cout<<"Digite el codigo del supermecado: ";
			getline(cin,super);
			cout<<"Digite el codigo del producto: ";
			string cpro;
			getline(cin,cpro);
			cout<<"Digite el nombre del producto: ";
			string nomb;
			getline(cin,nomb);
			cout<<"Digite la cantidad de producto: ";
			string cant;
			getline(cin,cant);
			cout<<"Digite el precio del producto: ";
			string prec;
			getline(cin,prec);
			char super1[128];
			char cpro1[128];
			char nomb1[128];
			char cant1[128];
			char prec1[128];
			bool veri=false;
			strcpy(super1,super.c_str());
			strcpy(cpro1,cpro.c_str());
			strcpy(nomb1,nomb.c_str());
			strcpy(cant1,cant.c_str());
			strcpy(prec1,prec.c_str());
			ListaDobleCircularInventario.Primero();
			ListaDobleSuper.Primero();
			for(int i=0;i<ListaDobleSuper.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleSuper.codigosuper()==super1){
					veri=true;
					//cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
				}
				ListaDobleSuper.Siguiente();
			}if(veri==true){
				veri=false;
				for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){;
					if(ListaDobleCircularInventario.codigoproducto()==cpro1){
						veri=true;
						//cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
					}
					ListaDobleCircularInventario.Siguiente();
				}if(veri==true){
					cout<<endl<<"El producto ya existe"<<endl;
				}else{
					ListaDobleCircularInventario.InsertarFinal(super1,cpro1,nomb1,cant1,prec1);
					cout<<endl<<"El producto se ha insertado correctamente"<<endl;
					//ListaDobleCircularInventario.Mostrar();
				}
			}else{
				cout<<endl<<"El supermercado no existe"<<endl;
			}	
		}
		else if(opc=="2"){
			//ListaDobleCircularInventario.Mostrar();
			cout<<endl<<"Digite el codigo del producto a eliminar: ";
			string eli;
			getline(cin,eli);
			char eli1[128];
			bool veri=false;
			strcpy(eli1,eli.c_str());
			ListaDobleCircularInventario.Primero();
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				if(ListaDobleCircularInventario.codigoproducto()==eli1){
					veri=true;
					isEli=true;
					TemporalEli.BorrarFinal();
					TemporalEli.InsertarFinal(ListaDobleCircularInventario.codigosuper(),ListaDobleCircularInventario.codigoproducto(),ListaDobleCircularInventario.nombre(),ListaDobleCircularInventario.cproducto(),ListaDobleCircularInventario.precio());
					ListaDobleCircularInventario.borrarPosicion(i+1);
					i=0;
					ListaDobleCircularInventario.Primero();
					cout<<endl<<"El producto ha sido borrado con exito"<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<endl<<"No se ha podido borrar ese producto, intente de nuevo"<<endl;
			}
			//ListaDobleCircularInventario.Mostrar();
		}
		else if(opc=="3"){
			ListaDobleCircularInventario.Mostrar();
			cout<<endl<<"Digite el codigo del producto a modificar: ";
			string eli;
			getline(cin,eli);
			char eli1[128];
			bool veri=false;
			strcpy(eli1,eli.c_str());
			ListaDobleCircularInventario.Primero();
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				if(ListaDobleCircularInventario.codigoproducto()==eli1){
					veri=true;
					bool verc=false;
					while(not verc){
						cout<<endl<<"Que desea modificar?"<<endl<<"1. Cantidad de producto"<<endl<<"2. Precio Unitario"<<endl;
						string opc3;
						getline(cin,opc3);
						if(opc3=="1"){
							verc=true;
							cout<<endl<<"Digite la nueva cantidad: ";
							string mod;
							getline(cin,mod);
							int mod1=atoi(mod.c_str());
							ListaDobleCircularInventario.variarCant2(mod1);
							Temporal.BorrarFinal();
							Temporal.InsertarFinal(ListaDobleCircularInventario.codigosuper(),ListaDobleCircularInventario.codigoproducto(),ListaDobleCircularInventario.nombre(),ListaDobleCircularInventario.cproducto(),ListaDobleCircularInventario.precio());
							isModi=true;
						}else if(opc3=="2"){
							verc=true;
							cout<<endl<<"Digite el nuevo precio: ";
							string modd;
							getline(cin,modd);
							int modd1=atoi(modd.c_str());
							ListaDobleCircularInventario.variarPre(modd1);
							Temporal.BorrarFinal();
							Temporal.InsertarFinal(ListaDobleCircularInventario.codigosuper(),ListaDobleCircularInventario.codigoproducto(),ListaDobleCircularInventario.nombre(),ListaDobleCircularInventario.cproducto(),ListaDobleCircularInventario.precio());
							isModi=true;
							//Temporal.InsertarInicio()
						}else{
							cout<<endl<<"ERROR, digite una accion valida"<<endl;
						}
					}
					cout<<endl<<"El producto ha sido modificado con exito"<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<endl<<"No se ha podido encontrar ese producto, intente de nuevo"<<endl;
			}
			ListaDobleCircularInventario.Mostrar();
		}
		else if(opc=="4"){
			cout<<"Digite el codigo del producto a consultar: ";
			string pro;
			getline(cin,pro);
			cout<<endl;
			ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleCircularInventario.codigoproducto()==pro){
					veri=true;
					cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<"El producto no existe"<<endl;
			}
		}
		else if(opc=="5"){
			if(descuentoactivo==false){
				cout<<endl<<"El descuento es de 5%"<<endl;
			}else{
				cout<<endl<<"El descuento es de 10%"<<endl;
			}
			cout<<endl;
		}
		else if(opc=="6"){
			cout<<"Digite el codigo del supermercado a consultar: ";
			string pro;
			getline(cin,pro);
			cout<<endl;
			ListaDobleCircularInventario.Primero();
			bool veri=false;
			for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
				//cout<<"SSS"<<ListaDobleCircularInventario.codigoproducto()<<endl;
				if(ListaDobleCircularInventario.codigosuper()==pro){
					veri=true;
					cout<<"Nombre: "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<endl;
				}
				ListaDobleCircularInventario.Siguiente();
			}
			if(veri==false){
				cout<<"El producto no existe"<<endl;
			}
		}
		else if(opc=="7"){
			if(listaSolicitud.largoLista()-1==0){
				cout<<endl<<"No hay nadie en la lista de espera"<<endl;
			}else{
			cout<<"Hay un total de "<<listaSolicitud.largoLista()-1<<" en espera"<<endl;
			listaSolicitud.Mostrar();
			listaSolicitud.Primero();
			listaSolicitud.Siguiente();
			for(int i=0;i<listaSolicitud.largoLista()-1;i++){
				cout<<endl<<listaSolicitud.nombre();
				listaSolicitud.Siguiente();
			}
			listaSolicitud.Primero();
			bool free=false;
			while(not free){
				cout<<endl<<"Desea modificar registrarlos?"<<endl<<"1. Si"<<endl<<"2. No"<<endl;
				string opc4;
				getline(cin,opc4);
				if(opc4=="1"){
					free=true;
					listaSolicitud.Primero();
					listaSolicitud.Siguiente();
					for(int i=0;i<listaSolicitud.largoLista()-1;i++){
						Lista0.InsertarFinal(listaSolicitud.codigociudad(),listaSolicitud.cedula(),listaSolicitud.nombre(),listaSolicitud.telefono());
						listaSolicitud.Siguiente();
					}while(listaSolicitud.largoLista()!=1){
						listaSolicitud.BorrarFinal();
					}
					listaSolicitud.Mostrar();
					Lista0.Mostrar();
				}else if(opc4=="2"){
					free=true;
				}else{
					cout<<endl<<"ERROR opcion no valida"<<endl;
				}
			}
			}
		}
		else if(opc=="8"){
			string opc5;
			bool libre=false;
			while(not libre){
				cout<<endl<<"1. Ultimos  dos productos ingresados al inventario"<<endl<<"2. Ultimo Producto Modificado"<<endl<<"3. Ultimo Producto Eliminado"<<endl;
				cout<<"4. Producto mas vendido"<<endl<<"5. Producto menos vendido por super"<<endl<<"6. Cliente que mas compro"<<endl<<"7. Cliente que menos compro";
				cout<<endl<<"8. Cantidad de compras por cliente"<<endl<<"9. Super mas visitado"<<endl<<"10. Super menos visitado"<<endl<<"11. Administrador que mas trabajo";
				cout<<endl<<"12. Administrador que no trabajo"<<endl<<"13. Salir"<<endl<<"Digite la opcion: ";
				getline(cin,opc5);	
				if(opc5=="1"){
					ListaDobleCircularInventario.Ultimo();
					ofstream report("Reporte Ultimos 2 Productos.txt");
					//report<<"Consecutivo Factura: "<<cns<<endl<<endl;
					report<<"1. "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<"Codigo: "<<ListaDobleCircularInventario.codigoproducto()<<endl<<endl;
					ListaDobleCircularInventario.Anterior();
					report<<"2. "<<ListaDobleCircularInventario.nombre()<<endl<<"Precio: "<<ListaDobleCircularInventario.precio()<<endl<<"Codigo: "<<ListaDobleCircularInventario.codigoproducto()<<endl<<endl;
					report.close();
					cout<<endl<<"Reporte generado correctamente"<<endl;
				}else if(opc5=="2"){
					Temporal.Primero();
					if(isModi!=false){
						ofstream report2("Reporte Ultimo Producto Modificado.txt");
						report2<<"Ultimo producto modificado: "<<endl<<"Codigo del supermercado: "<<Temporal.codigosuper()<<endl<<"Codigo del producto: "<<Temporal.codigoproducto()<<endl<<"Nombre: "<<Temporal.nombre()<<endl<<"Cantidad de unidades: "<<Temporal.cproducto()<<endl<<"Precio: "<<Temporal.precio();	
						report2.close();
						cout<<endl<<"Reporte generado correctamente"<<endl;
					}else{
						cout<<endl<<"No se ha modificado ningun producto aun"<<endl;
					}
					
				}else if(opc5=="3"){
					TemporalEli.Primero();
					if(isEli!=false){
						ofstream report3("Reporte Ultimo Producto Eliminado.txt");
						report3<<"Ultimo producto eliminado: "<<endl<<"Codigo del supermercado: "<<TemporalEli.codigosuper()<<endl<<"Codigo del producto: "<<TemporalEli.codigoproducto()<<endl<<"Nombre: "<<TemporalEli.nombre()<<endl<<"Cantidad de unidades: "<<TemporalEli.cproducto()<<endl<<"Precio: "<<TemporalEli.precio();	
						report3.close();
						cout<<endl<<"Reporte generado correctamente"<<endl;
					}else{
						cout<<endl<<"No se ha eliminado ningun producto aun"<<endl;
					}
				}else if(opc5=="4"){
					ListaDobleCircularInventario.Primero();
					cout<<endl<<ListaDobleCircularInventario.CC()<<endl;
					//ListaDobleCircularInventario.Siguiente();
					ofstream report4("Reporte Producto Mas Vendido.txt");
					int a=0;
					for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
						cout<<endl<<a<<"   "<<ListaDobleCircularInventario.CC()<<endl;
						if(a<ListaDobleCircularInventario.CC()){
							a=ListaDobleCircularInventario.CC();
						}
						ListaDobleCircularInventario.Siguiente();
					}
					ListaDobleCircularInventario.Primero();
					for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
						if(a==ListaDobleCircularInventario.CC()){
							if(a==1){
								report4<<ListaDobleCircularInventario.nombre()<<" con "<<a<<" unidad vendida "<<endl;
							}else{
								report4<<ListaDobleCircularInventario.nombre()<<" con "<<a<<" unidades vendidas "<<endl;
							}
						}
						ListaDobleCircularInventario.Siguiente();
					}
					report4.close();
					
				}else if(opc5=="5"){
					ListaDobleCircularInventario.Primero();
					cout<<endl<<ListaDobleCircularInventario.CC()<<endl;
					//ListaDobleCircularInventario.Siguiente();
					ofstream report5("Reporte Productos Menos Vendidos.txt");
					int a=10000;
					for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
						//cout<<endl<<a<<"   "<<ListaDobleCircularInventario.CC()<<endl;
						if(a>ListaDobleCircularInventario.CC()){
							a=ListaDobleCircularInventario.CC();
						}
						ListaDobleCircularInventario.Siguiente();
					}
					ListaDobleCircularInventario.Primero();
					for(int i=0;i<ListaDobleCircularInventario.largoLista();i++){
						if(a==ListaDobleCircularInventario.CC()){
							if(a==1){
								report5<<ListaDobleCircularInventario.nombre()<<" con "<<a<<" unidad vendida "<<endl;
							}else{
								report5<<ListaDobleCircularInventario.nombre()<<" con "<<a<<" unidades vendidas "<<endl;
							}
						}
						ListaDobleCircularInventario.Siguiente();
					}
					report5.close();
					
				}else if(opc5=="6"){
					Lista0.Primero();
					Lista0.Siguiente();
					//ListaDobleCircularInventario.Siguiente();
					ofstream report6("Reporte Cliente que mas compro.txt");
					int a=0;
					for(int i=1;i<Lista0.largoLista();i++){
						//cout<<endl<<a<<"   "<<Lista0.compras()<<endl;
						if(a<Lista0.compras()){
							a=Lista0.compras();
						}
						Lista0.Siguiente();
					}
					Lista0.Primero();
					Lista0.Siguiente();
					for(int i=1;i<Lista0.largoLista();i++){
						if(a==Lista0.compras()){
							if(a==1){
								report6<<Lista0.nombre()<<endl<<"Cedula: "<<Lista0.cedula()<<endl<<"Con "<<a<<" compra "<<endl<<endl;
							}else{
								report6<<Lista0.nombre()<<endl<<"Cedula: "<<Lista0.cedula()<<endl<<"Con "<<a<<" compras "<<endl<<endl;
							}
						}
						Lista0.Siguiente();
					}
					report6.close();
					
				}else if(opc5=="7"){
					Lista0.Primero();
					Lista0.Siguiente();
					//ListaDobleCircularInventario.Siguiente();
					ofstream report7("Reporte Cliente que menos compro.txt");
					int a=10000;
					for(int i=1;i<Lista0.largoLista();i++){
						//cout<<endl<<a<<"   "<<Lista0.compras()<<endl;
						if(a>Lista0.compras()){
							a=Lista0.compras();
						}
						Lista0.Siguiente();
					}
					Lista0.Primero();
					Lista0.Siguiente();
					for(int i=1;i<Lista0.largoLista();i++){
						if(a==Lista0.compras()){
							if(a==1){
								report7<<Lista0.nombre()<<endl<<"Cedula: "<<Lista0.cedula()<<endl<<"Con "<<a<<" compra "<<endl<<endl;
							}else{
								report7<<Lista0.nombre()<<endl<<"Cedula: "<<Lista0.cedula()<<endl<<"Con "<<a<<" compras "<<endl<<endl;
							}
						}
						Lista0.Siguiente();
					}
					report7.close();
					
				}else if(opc5=="8"){
					Lista0.Primero();
					Lista0.Siguiente();
					//ListaDobleCircularInventario.Siguiente();
					ofstream report8("Reporte compras por Cliente.txt");
					for(int i=1;i<Lista0.largoLista();i++){
						if(Lista0.compras()==1){
							report8<<Lista0.nombre()<<endl<<"Cedula: "<<Lista0.cedula()<<endl<<"Tiene "<<Lista0.compras()<<" compra "<<endl<<endl;
						}else{
							report8<<Lista0.nombre()<<endl<<"Cedula: "<<Lista0.cedula()<<endl<<"Tiene "<<Lista0.compras()<<" compras "<<endl<<endl;
						}
						Lista0.Siguiente();
					}
					report8.close();
					
				}else if(opc5=="9"){
					ListaDobleSuper.Primero();
					//ListaDobleCircularInventario.Siguiente();
					ofstream report9("Reporte Super Mercado mas visitado.txt");
					int a=0;
					for(int i=0;i<ListaDobleSuper.largoLista();i++){
						//cout<<a<<"    "<<ListaDobleSuper.visitas2()<<endl<<endl;
						if(a<ListaDobleSuper.visitas2()){
							a=ListaDobleSuper.visitas2();
						}
						ListaDobleSuper.Siguiente();
					}
					ListaDobleSuper.Primero();
					for(int i=0;i<ListaDobleSuper.largoLista();i++){
						if(a==ListaDobleSuper.visitas2()){
							if(a==1){
								report9<<ListaDobleSuper.nombre()<<endl<<"Codigo: "<<ListaDobleSuper.codigosuper()<<endl<<"Con "<<a<<" visita "<<endl<<endl;
							}else{
								report9<<ListaDobleSuper.nombre()<<endl<<"Codigo: "<<ListaDobleSuper.codigosuper()<<endl<<"Con "<<a<<" visitas "<<endl<<endl;
							}
						}
						ListaDobleSuper.Siguiente();
					}
					report9.close();
					
				}else if(opc5=="10"){
					ListaDobleSuper.Primero();
					//ListaDobleCircularInventario.Siguiente();
					ofstream report10("Reporte Super Mercado menos visitado.txt");
					int a=10000;
					for(int i=0;i<ListaDobleSuper.largoLista();i++){
						//cout<<a<<"    "<<ListaDobleSuper.visitas2()<<endl<<endl;
						if(a>ListaDobleSuper.visitas2()){
							a=ListaDobleSuper.visitas2();
						}
						ListaDobleSuper.Siguiente();
					}
					ListaDobleSuper.Primero();
					for(int i=0;i<ListaDobleSuper.largoLista();i++){
						if(a==ListaDobleSuper.visitas2()){
							if(a==1){
								report10<<ListaDobleSuper.nombre()<<endl<<"Codigo: "<<ListaDobleSuper.codigosuper()<<endl<<"Con "<<a<<" visita "<<endl<<endl;
							}else{
								report10<<ListaDobleSuper.nombre()<<endl<<"Codigo: "<<ListaDobleSuper.codigosuper()<<endl<<"Con "<<a<<" visitas "<<endl<<endl;
							}
						}
						ListaDobleSuper.Siguiente();
					}
					report10.close();
					
				}else if(opc5=="11"){
					Lista1.Primero();
					Lista1.Siguiente();
					//ListaDobleCircularInventario.Siguiente();
					ofstream report11("Reporte Administrador que mas trabajo.txt");
					int a=0;
					for(int i=1;i<Lista1.largoLista();i++){
						//cout<<endl<<a<<"   "<<Lista0.compras()<<endl;
						if(a<Lista1.compras()){
							a=Lista1.compras();
						}
						Lista1.Siguiente();
					}
					Lista1.Primero();
					Lista1.Siguiente();
					for(int i=1;i<Lista1.largoLista();i++){
						if(a==Lista1.compras()){
							if(a==1){
								report11<<Lista1.nombre()<<endl<<"Cedula: "<<Lista1.cedula()<<endl<<"Con "<<a<<" sesion "<<endl<<endl;
							}else{
								report11<<Lista1.nombre()<<endl<<"Cedula: "<<Lista1.cedula()<<endl<<"Con "<<a<<" sesiones "<<endl<<endl;
							}
						}
						Lista1.Siguiente();
					}
					report11.close();
					
				}else if(opc5=="12"){
					Lista1.Primero();
					Lista1.Siguiente();
					bool FIN=false;
					//ListaDobleCircularInventario.Siguiente();
					ofstream report12("Reporte Administrador que no trabajo.txt");
					for(int i=1;i<Lista1.largoLista();i++){
						if(Lista1.compras()==0){
							report12<<Lista1.nombre()<<endl<<"Cedula: "<<Lista1.cedula()<<endl<<endl;
						}else{
							if(FIN==false){
								report12<<"Todos los administradores trabajaron";
							}
							FIN=true;
						}
						Lista1.Siguiente();
					}
					report12.close();
					
				}else if(opc5=="13"){
					libre=true;
				}else{
					
				}
			}
		}
		else if(opc=="9"){
			salir=true;
		}
		else{
			cout<<"Error digite una opcion valida"<<endl;
		}
	}
}

void menu(lista& ListaSimpleCiudades,listaD& ListaDobleSuper,listaDC& ListaDobleCircularInventario,listaDCU& Lista0,listaDCU& Lista1,listaDCU& Lista2,listaDCU& Lista3,listaDCU& listaSolicitud){
	bool Abierto=false;
	while(not Abierto){
		bool salir=false;
		bool salirc=false;
		bool isCliente=false;
		string cedu;
		string tipo;
		while(not salir or not salirc){
			salir=false;
			salirc=false;
			cout<<endl<<endl<<"Ingrese su cedula: ";
			getline(cin,cedu);
			cout<<endl;
			cout<<"0.Cliente"<<endl<<"1.Administrador"<<endl<<"2.Vendedor"<<endl<<"3.Cliente-Funcionario"<<endl<<endl<<"Ingrese el tipo de usuario: ";
			getline(cin,tipo);
			if(tipo=="0" or tipo=="1" or tipo=="2" or tipo=="3"){
				salir=true;
			}else{
				cout<<endl<<"Error, tipo de usuario no valido"<<endl<<endl;
			}
			if(tipo=="0"){
				Lista0.Primero();
				salirc=true;
				for(int i=0;i<Lista0.largoLista();i++){
					if(Lista0.cedula()==cedu){
						isCliente=true;
					}
					Lista0.Siguiente();
				}
			}
			else if(tipo=="1"){
				Lista1.Primero();
				for(int i=0;i<Lista1.largoLista();i++){
					if(Lista1.cedula()==cedu){
						Lista1.compras2(1);
						salirc=true;
					}
					Lista1.Siguiente();
				}
			}
			else if(tipo=="2"){
				Lista2.Primero();
				for(int i=0;i<Lista2.largoLista();i++){
					if(Lista2.cedula()==cedu){
						salirc=true;
					}
					Lista2.Siguiente();
				}
			}
			else if(tipo=="3"){
				Lista3.Primero();
				for(int i=0;i<Lista3.largoLista();i++){
					if(Lista3.cedula()==cedu){
						salirc=true;
					}
					Lista3.Siguiente();
				}
			}if(salirc==false){
				cout<<endl<<"Error, su cedula no es valida"<<endl;
			}
		}
		if(tipo=="0"){
			menuclientes(ListaSimpleCiudades,ListaDobleSuper,ListaDobleCircularInventario,Lista0,Lista1,Lista2,Lista3,cedu,isCliente,listaSolicitud);
		}
		if(tipo=="1"){
			menuadmin(ListaSimpleCiudades,ListaDobleSuper,ListaDobleCircularInventario,Lista0,Lista1,Lista2,Lista3,cedu,listaSolicitud);
		}
		if(tipo=="2"){
			menuvendedores(ListaSimpleCiudades,ListaDobleSuper,ListaDobleCircularInventario,Lista0,Lista1,Lista2,Lista3,cedu);
		}
		if(tipo=="3"){
			menufuncionario(ListaSimpleCiudades,ListaDobleSuper,ListaDobleCircularInventario,Lista0,Lista1,Lista2,Lista3,cedu);
		}
		//MOSTRAR LISTAS I GUESS
	}
}

int main(){
	ifstream arch("Ciudad.txt");
	lista ListaSimpleCiudades;
	cargarArch(ListaSimpleCiudades,2,1,arch,1);
	arch.close();
	
	ifstream arch2("supermercado.txt");
	listaD ListaDobleSuper;
	cargarArch(ListaDobleSuper,3,2,arch2,2,ListaSimpleCiudades);
	
	ifstream arch1("Inventario.txt");
	listaDC ListaDobleCircularInventario;
	cargarArch(ListaDobleCircularInventario,5,2,arch1,2,ListaDobleSuper);
	
	ifstream arch4("Usuarios.txt");
	//listaDCU ListaListasUsuario;
	listaDCU Lista0;
	listaDCU Lista1;
	listaDCU Lista2;
	listaDCU Lista3;
	listaDCU listaSolicitud;
	Lista0.InsertarType("0");
	Lista1.InsertarType("1");
	Lista2.InsertarType("2");
	Lista3.InsertarType("3");
	listaSolicitud.InsertarType("Espera");
	cargarArch(Lista0,Lista1,Lista2,Lista3,5,2,arch4,2,ListaSimpleCiudades);
	cout<<"Lista de ciudades: ";
	ListaSimpleCiudades.Mostrar();
	cout<<endl;
	cout<<"Lista de super: ";
	ListaDobleSuper.Mostrar();
	cout<<endl;
	cout<<"Lista de Inventario: ";
	ListaDobleCircularInventario.Mostrar();
	cout<<endl;
	cout<<"Lista de usuarios: "<<endl;
	listaDCU ListadeListasUsuarios;
	//ListadeListasUsuarios.InsertarInicio();
	Lista0.Mostrar();
	cout<<endl;
	Lista1.Mostrar();
	cout<<endl;
	Lista2.Mostrar();
	cout<<endl;
	Lista3.Mostrar();
	cout<<endl;
	menu(ListaSimpleCiudades,ListaDobleSuper,ListaDobleCircularInventario,Lista0,Lista1,Lista2,Lista3,listaSolicitud);
}
