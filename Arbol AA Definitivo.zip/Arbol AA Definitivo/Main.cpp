#include <stdlib.h>
#include <iostream>

#include "ArbolAA.h"
#include "nodoAA.h"
#include "ArbolAA.cpp"

using namespace std;

int main(){
    ArbolAA aux1;
    
    aux1.raiz = insertar(15,aux1.raiz);
    InordenR(aux1.raiz);
    cout<<endl;
    aux1.raiz = insertar(10,aux1.raiz);
    aux1.raiz = insertar(20,aux1.raiz);
    aux1.raiz = insertar(6,aux1.raiz);
    aux1.raiz = insertar(8,aux1.raiz);
    aux1.raiz = insertar(12,aux1.raiz);
    
    InordenR(aux1.raiz);
    cout<<endl<<"##########################"<<endl;
    cout<<"Esta es la raiz del arbol: "<<aux1.raiz->valor<<endl;
    return 0;
}
