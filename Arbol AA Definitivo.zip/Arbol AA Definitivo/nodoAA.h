#ifndef _NODOAA_H
#define	_NODOAA_H

#include <iostream>
using namespace std;


class nodoAA {
   public:
    nodoAA(int v)
    {
       valor = v;
       nivel = 1;
       Hizq = NULL;
       Hder = NULL;
    }
    void InsertarNodoAA(int num);
    nodoAA *Torsion();
    nodoAA *division();

   public:
    int valor;
    int nivel;
    nodoAA *Hizq;
    nodoAA *Hder;
    
        
   friend class ArbolAA;
};

typedef nodoAA *pnodoAA;

void InordenR(nodoAA* R);
pnodoAA torsion(nodoAA *T);
pnodoAA division(nodoAA *T);

#endif // _NODOAA_H
