#ifndef _ARBOLAA_H
#define	_ARBOLAA_H
#include "nodoAA.h"

using namespace std;

class ArbolAA{
public:
    pnodoAA raiz;

    ArbolAA():raiz(NULL){}

    void InsertaNodo(int num);
    void InsertaNodo2(int num);
    void InsertaNodo3(int num);
    int largo(pnodoAA nodoRaiz);
    
    /*void PreordenI();
    void InordenI();
    void PostordenI();*/
};
pnodoAA insertar(int num, nodoAA *arbolAA);
#endif	/* _BINARIO_H */
