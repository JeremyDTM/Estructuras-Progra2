#include "pagina.h"

Pagina::Pagina(){
}


int Pagina::getCuentas(){
    return cuentas;
}

void Pagina::setCuentas(int pCuentas){
    cuentas=pCuentas;
}

void Pagina::annadirClaves(int posicion,string valor){
    for(int m=0; m<=4;m++){
        string::size_type pos=valor.find(';');
        if(m==0){
            claves[posicion].codCiudad=valor.substr(0,pos);
        }else if(m==1){
            claves[posicion].valor=std::atoi(valor.substr(0,pos).c_str());
        }else if(m==2){
            claves[posicion].nombre=valor.substr(0,pos);
        }else if(m==3){
            claves[posicion].telefono=valor.substr(0,pos);
        }else{
            claves[posicion].tipo=std::atoi(valor.substr(0,pos).c_str());
        }
        valor=valor.substr(pos+1);
    }
}

void Pagina::annadirRamas(int posicion,Pagina *pagina){
    ramas[posicion]=pagina;
}
