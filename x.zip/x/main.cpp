#include <iostream>
#include "arbolb.h"
#include "pagina.h"
#include "arbolbin.h"
#include <fstream>
#include <string>
#include "rojinegro.h"
#include "listasimple.h"

using namespace std;



void menu(listaSimple& lista,arbolBin& arbolBin,ArbolAAInventarios*& arbolAA,RojiNegro*& arbolRN){
    arbolBin.leerCiudad();
    arbolRN->CargaSupermercados(arbolBin);
    arbolRN->crearListaDeInventarios();
    arbolRN->raiz->productos->InordenR(arbolRN->raiz->productos->raiz);
    lista.users(arbolBin);



}

int main(){
    ArbolB* arbolB=new ArbolB();
    AVL* arbolAVL=new AVL();
    ArbolAAInventarios* arbolAA=new ArbolAAInventarios();
    listaSimple listaUsuarios;
    RojiNegro* arbolRN= new RojiNegro();
    listaUsuarios.Insertar(0,arbolB);
    listaUsuarios.Insertar(1,arbolB);
    listaUsuarios.Insertar(2,arbolB);
    listaUsuarios.Insertar(3,arbolAVL);
    arbolBin arbBin;
    menu(listaUsuarios,arbBin,arbolAA, arbolRN);
    cout<<endl;
    cout<<"arbol binario: ";
    arbBin.Mostrar();
    cout<<endl;
    cout<<"arbol AA: ";
    arbolRN->raiz->productos->InordenR( arbolRN->raiz->productos->raiz);
    cout<<endl;
    cout<<"arbol rojinegro: ";
    arbolRN->InordenR(arbolRN->raiz);
    cout<<endl;
    listaUsuarios.Mostrar();


    return 0;
}
