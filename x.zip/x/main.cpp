#include <iostream>
#include "arbolb.h"
#include "pagina.h"
#include "arbolbin.h"
#include <fstream>
#include <string>
#include "rojinegro.h"
#include "listasimple.h"
#include <stdio.h>
#include <wchar.h>
#include <locale.h>
#include <stdlib.h>

using namespace std;

void menuCarrito(listaSimple& lista,RojiNegro*& arbolRN,int tipo,int cedula){
    cout<<endl;
    cout<<"                                                 Compras"<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"Opciones"<<endl;
    cout<<"1. Agregar producto al carrito"<<endl;
    cout<<"2. Aumentar cantidad del producto"<<endl;
    cout<<"3. Disminuir cantidad del produtco"<<endl;
    cout<<"4. Eliminar producto"<<endl;
    cout<<"Opcion: ";
    string opcion;
    cin>>opcion;
    if(opcion=="1"){
        arbolRN->AnnadirCarrito(lista,tipo,cedula);
        cout<<endl;
        menuCarrito(lista,arbolRN,tipo,cedula);
    }else if(opcion=="2"){
        cout<<endl;
        //arbolRN->AumentarCarrito(user);
        menuCarrito(lista,arbolRN,tipo,cedula);
    }else if(opcion=="3"){
        cout<<endl;
        //arbolRN->DisminuirCarrito(user);
        menuCarrito( lista,arbolRN,tipo,cedula);
    }else if(opcion=="4"){
        cout<<endl;
        //arbolRN->EliminarProducto(user);
        menuCarrito(lista,arbolRN,tipo,cedula);
    }else if(opcion=="6"){

    }else{
        cout<<"Usted ingreso un opcion invalida, intentelo de nuevo."<<endl;
        cout<<endl;
        menuCarrito(lista,arbolRN,tipo,cedula);
    }
}

void menuCliente(listaSimple& lista,arbolBin& arbolBin,RojiNegro*& arbolRN,int tipo, int cedula){
    cout<<endl;
    cout<<"                                                 Menu de Cliente"<<endl;
    lista.primero->abajo->InsertarValor("7;7");
    cout<<endl;
    cout<<endl;
    cout<<"Opciones"<<endl;
    cout<<"1. Consultar Precio"<<endl;
    cout<<"2. Consultar Descuento"<<endl;
    cout<<"3. Consultar Producto por Super"<<endl;
    cout<<"4. Salir"<<endl;
    cout<<"Opci\242n: ";
    string opcion;
    cin>> opcion;
    cout<<endl;
    if (opcion=="1"){
        arbolRN->ConsultarPrecio();
        cout<<endl;
        menuCliente(lista,arbolBin,arbolRN,tipo,cedula);
    }else if(opcion=="2"){
        lista.Descuento(tipo,cedula);
        cout<<endl;
        menuCliente(lista,arbolBin,arbolRN,tipo,cedula);
    }else if(opcion=="3"){
        arbolRN->ConsultarProducto();
        cout<<endl;
        menuCliente(lista,arbolBin,arbolRN,tipo,cedula);
    }else if(opcion=="4"){
        menuCarrito(lista,arbolRN,tipo,cedula);
        menuCliente(lista,arbolBin,arbolRN,tipo,cedula);
    }else if(opcion=="6"){

    }else{
        cout<<"Respuesta invalida"<<endl;
        cout<<endl;
        menuCliente(lista,arbolBin,arbolRN,tipo,cedula);
    }

}


void menu(listaSimple& lista,arbolBin& arbolBin,ArbolAAInventarios*& arbolAA,RojiNegro*& arbolRN){
    cout<<"                                                 Inicio de sesi\242n"<<endl;
    cout<<endl;
    cout<<endl;
    string cedula,tipo;
    cout<<"Ingrese su c\202dula: ";
    cin>>cedula;
    cout<<"Usuarios"<<endl;
    cout<<"0. Cliente"<<endl;
    cout<<"1.Administrador"<<endl;
    cout<<"Ingrese el tipo de usuario: ";
    cin>>tipo;
    bool esta=lista.BuscarUsuario(std::atoi(tipo.c_str()),std::atoi(cedula.c_str()));
    if(esta){
        if (tipo=="0"){
            menuCliente(lista,arbolBin,arbolRN,std::atoi(tipo.c_str()),std::atoi(cedula.c_str()));
            cout<<endl;
            menu(lista,arbolBin,arbolAA,arbolRN);
        }else if(tipo=="1"){
            //menuAdministrador();
            cout<<endl;
            menu(lista,arbolBin,arbolAA,arbolRN);
        }else if(tipo=="2"){
            //menuVendedor();
        }else if(tipo=="3"){
            //menuClienteFuncionario();
            cout<<endl;
            menu(lista,arbolBin,arbolAA,arbolRN);
        }
    }else{
        if(tipo=="0"){
            //menuNoCliente();
            cout<<"adios"<<endl;
            cout<<endl;
            menu(lista,arbolBin,arbolAA,arbolRN);
        }else{
            cout<<"El cliente ingresado no existe, por favor ingrese el tipo y cédula nuevamente"<<endl;
            cout<<endl;
            //menu(lista,arbolBin,arbolAA,arbolRN);
        }
    }
}

int main(){
    ArbolB* arbolB=new ArbolB();
    AVL* arbolAVL=new AVL();
    ArbolAAInventarios* arbolAA=new ArbolAAInventarios();
    listaSimple listaUsuarios;
    RojiNegro* arbolRN= new RojiNegro();
    listaUsuarios.Insertar(0,arbolB);
    listaUsuarios.Insertar(1,arbolB);
    listaUsuarios.Insertar(2,arbolB);
    listaUsuarios.Insertar(3,arbolAVL);
    arbolBin arbBin;
    arbBin.leerCiudad();
    arbolRN->CargaSupermercados(arbBin);
    arbolRN->crearListaDeInventarios();
    listaUsuarios.users(arbBin);
    listaUsuarios.Mostrar();
    menu(listaUsuarios,arbBin,arbolAA, arbolRN);
    listaUsuarios.Mostrar();
    return 0;
}
