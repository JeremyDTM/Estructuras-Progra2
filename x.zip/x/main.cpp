#include <iostream>
#include "arbolb.h"
#include "pagina.h"
#include "arbolbin.h"
#include <fstream>
#include <string>
#include "rojinegro.h"
#include "listasimple.h"
#include <stdio.h>
#include <wchar.h>
#include <locale.h>
#include <stdlib.h>

using namespace std;



void menu(listaSimple& lista,arbolBin& arbolBin,ArbolAAInventarios*& arbolAA,RojiNegro*& arbolRN){
    cout<<"                     Inicio de sesi\242n"<<endl;
    cout<<endl;
    cout<<endl;
    int cedula,tipo;
    cout<<"Ingrese su c\202dula: "<<endl;
    cin>>cedula;
    cout<<endl;
    cout<<"Usuarios"<<endl;
    cout<<"0. Cliente"<<endl;
    cout<<"1.Administrador"<<endl;
    cout<<"Ingrese el tipo de usuario: ";
    cin>>tipo;

}

int main(){
    ArbolB* arbolB=new ArbolB();
    AVL* arbolAVL=new AVL();
    ArbolAAInventarios* arbolAA=new ArbolAAInventarios();
    listaSimple listaUsuarios;
    RojiNegro* arbolRN= new RojiNegro();
    listaUsuarios.Insertar(0,arbolB);
    listaUsuarios.Insertar(1,arbolB);
    listaUsuarios.Insertar(2,arbolB);
    listaUsuarios.Insertar(3,arbolAVL);
    arbolBin arbBin;
    arbBin.leerCiudad();
    arbolRN->CargaSupermercados(arbBin);
    arbolRN->crearListaDeInventarios();
    listaUsuarios.users(arbBin);
    menu(listaUsuarios,arbBin,arbolAA, arbolRN);
    listaUsuarios.Mostrar();
    return 0;
}
