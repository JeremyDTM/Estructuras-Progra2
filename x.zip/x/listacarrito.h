#ifndef LISTACARRITO_H
#define LISTACARRITO_H
#include "nodoaa.h"


class listaCarrito{
    public:
        listaCarrito();
        void Insertar(nodoAAInventarios* producto);
        void Buscar(int codigo,bool& esta,nodoAAInventarios*& y);
        void Eliminar(int codigo);
    private:
        nodoAAInventarios* primero=nullptr;
    friend class RojiNegro;
};

#endif // LISTACARRITO_H
