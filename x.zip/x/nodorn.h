#ifndef NODORN_H
#define NODORN_H

#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>
#include <sstream>
#include <cstring>
#include <math.h>
#include <stdio.h>
#include "arbolaa.h"
using namespace std;

class NodoRN {
   public:

    NodoRN(int num, string ciudad, string name, NodoRN *pad=NULL, NodoRN *der = NULL, NodoRN *izq = NULL, NodoRN *sig=NULL, NodoRN *ant=NULL):
        padre(pad), Hizq(izq), Hder(der), valor(num), nombre(name), codCiudad(ciudad), siguiente(sig), anterior(ant), color(0) {}

    //Insertar aca el puntero al arbol AA
    string nombre;
    string codCiudad;
    int valor;
    int color;
    NodoRN *Hizq, *Hder, *siguiente, *anterior, *padre;
    ArbolAAInventarios * productos=nullptr;
    void Buscar(int cod,bool& esta,NodoRN* & aux);
    friend class Pila;
    friend class Binario;

    void InsertaBinario(int num);
};

typedef NodoRN *pnodo;
typedef NodoRN *pNodoRN;


#endif // NODORN_H
