#ifndef _ARBOLAA_H
#define	_ARBOLAA_H
#include "nodoAA.h"

using namespace std;

class ArbolAAInventarios{
public:
    pnodoAAInventarios raiz;
    ArbolAAInventarios():raiz(NULL){}
    void crearListaDeInventarios();
    pnodoAAInventarios insertar(int pCodSuper, int pCodProducto, string pNombre, int pCantProducto, int pPrecioUnitario,nodoAAInventarios* &raiz);
    void InordenR(nodoAAInventarios *R);
    pnodoAAInventarios torsion(nodoAAInventarios *T);
    void Consulta(nodoAAInventarios* x);
    pnodoAAInventarios division(nodoAAInventarios *T);
};
#endif	/* _BINARIO_H */
