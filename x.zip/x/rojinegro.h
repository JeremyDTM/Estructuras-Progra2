#ifndef ROJINEGRO_H
#define ROJINEGRO_H
#include "nodorn.h"
#include "arbolbin.h"
#include "clave.h"
#include "listasimple.h"

class RojiNegro{
    public:
        pNodoRN raiz;
        pNodoRN actual;
        RojiNegro():raiz(NULL){}
        void ConsultarPrecio();
        void DisminuirCarrito(listaSimple& user,int tipo, int valor);
        void AumentarCarrito(listaSimple& user,int tipo, int valor);
        void InsertaNodo(int num);
        void PreordenI();
        void ModificarProducto(nodoAAInventarios*& modificado);
        void InordenI();
        void InsertarNuevoProducto(nodoAAInventarios* & ultimo,nodoAAInventarios* & penultimo);
        void PostordenI();
        void ConsultarProducto();
        void PreordenR(NodoRN* R);

        void InordenR(NodoRN* R);
        void PostordenR(NodoRN* R);
        void AnnadirCarrito(listaSimple& user,int tipo, int valor);
        bool Hh;
        void CargaSupermercados(arbolBin arbolBin);
        void Insertar(string x, int v, string y);
        void Arreglar(NodoRN* ra);
        void crearListaDeInventarios();
        void RotacionIzquierda(NodoRN *n);
        void RotacionDerecha(NodoRN *n);
        NodoRN* Hermano(NodoRN* nodo);


};

#endif // ROJINEGRO_H
