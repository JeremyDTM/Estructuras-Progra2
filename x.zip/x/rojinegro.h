#ifndef ROJINEGRO_H
#define ROJINEGRO_H
#include "nodorn.h"
#include "arbolbin.h"


class RojiNegro{
    public:
        pNodoRN raiz;
        pNodoRN actual;
        RojiNegro():raiz(NULL){}
        void ConsultarPrecio(int pCodProducto,int pCodSuper);
        void InsertaNodo(int num);
        void PreordenI();
        void InordenI();
        void PostordenI();
        void ConsultarProducto(int pCodSuper);
        void PreordenR(NodoRN* R);
        void InordenR(NodoRN* R);
        void PostordenR(NodoRN* R);
        bool Hh;
        void CargaSupermercados(arbolBin arbolBin);
        void Insertar(string x, int v, string y);
        void Arreglar(NodoRN* ra);
        void crearListaDeInventarios();
        void RotacionIzquierda(NodoRN *n);
        void RotacionDerecha(NodoRN *n);
        NodoRN* Hermano(NodoRN* nodo);


};

#endif // ROJINEGRO_H
