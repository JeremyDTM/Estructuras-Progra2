#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <locale.h>

#include "ArbolAA.h"
#include "nodoAA.h"

using namespace std;


pnodoAAInventarios ArbolAAInventarios::insertar(int pCodSuper, int pCodProducto, string pNombre, int pCantProducto, int pPrecioUnitario,nodoAAInventarios*& raiz){
    if(raiz == NULL){
        raiz = new nodoAAInventarios(pCodSuper,pCodProducto, pNombre, pCantProducto, pPrecioUnitario);
        return raiz;
    }
    else if(pCodProducto < raiz->codProducto){
        raiz->Hizq = insertar(pCodSuper,pCodProducto, pNombre, pCantProducto, pPrecioUnitario,raiz->Hizq);
    }
    else if(pCodProducto > raiz->codProducto){
        raiz->Hder = insertar(pCodSuper,pCodProducto, pNombre, pCantProducto, pPrecioUnitario,raiz->Hder);
    }
    raiz= torsion(raiz);
    raiz = division(raiz);
    return raiz;
}

void ArbolAAInventarios::InordenR(nodoAAInventarios *R){

    if(R==NULL){
        return;
    }else{
        InordenR(R->Hizq);
        cout<<R->codProducto<<" - ";
        InordenR(R->Hder);
    }
}

void ArbolAAInventarios::Consulta(nodoAAInventarios *R){

    if(R==NULL){
        return;
    }else{
        setlocale(LC_ALL, "");
        Consulta(R->Hizq);
        cout<<"nombre: "<<R->nombre<<" - "<<"c\363digo: "<<R->codProducto<<" - "<<"precio: "<<R->precioUnitario<<" - "<<"cantidad: "<<R->cantidadProducto<<" - "<<endl;
        Consulta(R->Hder);
    }
}

void nodoAAInventarios::Buscar(int cod,bool& esta,nodoAAInventarios* & aux){
    if(cod==codProducto){
        esta=true;
    }else if(cod<codProducto){
        if(Hizq!=nullptr){
            aux=aux->Hizq;
            aux->Buscar(cod,esta,aux);
        }
    }else{
        if(Hder!=nullptr){
            aux=aux->Hder;
            aux->Buscar(cod,esta,aux);
        }
    }
}

pnodoAAInventarios ArbolAAInventarios::torsion(nodoAAInventarios *T){
    if(T == NULL){
        return NULL;
    }
    else if(T->Hizq == NULL){
        return T;
    }
    else if(T->Hizq->nivel == T->nivel){
        pnodoAAInventarios L;
        L = T->Hizq;
        T->Hizq = L->Hder;
        L->Hder = T;
        return L;
    }
    else{
        return T;
    }
}

pnodoAAInventarios ArbolAAInventarios::division(nodoAAInventarios *T){
    if(T == NULL){
        return NULL;
    }
    else if(T->Hder == NULL){
        return T;
    }
    else if(T->Hder->Hder == NULL){
        return T;
    }
    else if(T->nivel == T->Hder->Hder->nivel){
        pnodoAAInventarios R;
        R = T->Hder;
        T->Hder = R->Hizq;
        R->Hizq = T;
        R->nivel = R->nivel + 1;
        return R;
    }
    else{
        return T;
    }
}


