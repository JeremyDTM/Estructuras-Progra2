#include "rojinegro.h"
#include "arbolbin.h"

void RojiNegro::PreordenR(NodoRN *R){
    if(R==NULL){
        return;
    }else{
        if(R->color==1){
            //cout<<R->codCiudad<<"  "<<R->nombre<<" ";
            cout<<R->valor<<"("<<"Negro"<<")"<<" - ";
        }else{
            //cout<<R->codCiudad<<"  "<<R->nombre;
            cout<<R->valor<<"("<<"Rojo"<<")"<<" - ";
        }

        PreordenR(R->Hizq);
        PreordenR(R->Hder);
    }
}

void RojiNegro::InordenR(NodoRN *R){

    if(R==NULL){
        return;
    }else{
        InordenR(R->Hizq);
        cout<<R->valor<<"("<<R->color<<")"<<" - ";
        InordenR(R->Hder);
    }
}

void RojiNegro::PostordenR(NodoRN *R){

    if(R==NULL){
        return;
    }else{
        PostordenR(R->Hizq);
        PostordenR(R->Hder);
        cout<<R->valor<<"("<<R->color<<")"<<" - ";
    }
}

NodoRN* RojiNegro::Hermano(NodoRN* nodo)
{
    if(nodo==nodo->padre->Hizq){

        return nodo->padre->Hder;
    }else{
        return nodo->padre->Hizq;
    }
}

void RojiNegro::Insertar(string ciudad, int v, string nombre){
    //cout<<endl<<ciudad<<"  "<<v<<"  "<<nombre<<endl;
    NodoRN* ra=new NodoRN(v,ciudad,nombre);
    NodoRN* y=NULL;
    NodoRN* x=this->raiz;
    bool band=false;
    while(x!=NULL){
        y=x;
        if(y->valor==ra->valor){
            band=true;
        }
        if(ra->valor<x->valor){
            x=x->Hizq;
        }else{
            x=x->Hder;
        }
    }
    ra->padre=y;
    if(y==NULL){
        this->raiz=ra;
    }else{
        if(band==false){
            if(ra->valor<y->valor){
                y->Hizq=ra;
            }else{
                y->Hder=ra;
            }
        }
    }
    ra->Hizq=NULL;
    ra->Hder=NULL;
    ra->color=0;
    if(ra->padre!=NULL and ra->padre->padre!=NULL){
        Arreglar(ra);
    }
    this->raiz->color=1;
}

void RojiNegro::Arreglar(NodoRN* ra){
    NodoRN* y;
    while(ra!=this->raiz and ra->padre!=NULL and ra->padre->padre!=NULL and ra->padre->color==0){
        if(ra->padre==ra->padre->padre->Hder){
            y=ra->padre->padre->Hder;
            if(y!=NULL){
                if(y->color==0){
                    ra->padre->color=1;
                    y->color=1;
                    ra->padre->padre->color=0;
                    ra=ra->padre->padre;
                }else{
                    if(ra==ra->padre->Hder){
                        ra=ra->padre;
                        RotacionIzquierda(ra);
                    }
                    ra->padre->color=1;
                    ra->padre->padre->color=0;
                    RotacionDerecha(ra->padre->padre);

                }
            }else{
                ra->color=1;
                ra->padre->color=0;
                RotacionDerecha(ra->padre);
            }
        }else{
            y=ra->padre->padre->Hizq;
            if(y!=NULL){
                if(y->color==0){
                    ra->padre->color=1;
                    y->color=1;
                    ra->padre->padre->color=0;
                    ra=ra->padre->padre;
                }else{
                    if(ra==ra->padre->Hizq){
                        ra=ra->padre;
                        RotacionDerecha(ra);
                    }
                    ra->padre->color=1;
                    ra->padre->padre->color=0;
                    RotacionIzquierda(ra->padre->padre);
                }
            }else{
                ra->color=1;
                ra->padre->color=0;
                RotacionIzquierda(ra->padre);
            }
        }
    }
}

void RojiNegro::RotacionIzquierda(NodoRN* n){
     NodoRN* aux;
     aux=n;
     n=n->Hder;
     aux->Hder=n->Hizq;
     n->Hizq=aux;
     if(aux->padre->Hizq==aux){
        aux->padre->Hizq=n;
     }else{
        aux->padre->Hder=n;
     }
     n->padre=aux->padre;
     aux->padre=n;
     if(aux->Hder!=NULL){
        aux->Hder->padre=aux;
     }
     if(this->raiz==aux){
        this->raiz=n;
     }
}

void RojiNegro::RotacionDerecha(NodoRN* n){
     NodoRN* aux;
     aux=n;
     n=n->Hizq;
     aux->Hizq=n->Hder;
     n->Hder=aux;
     if(aux->padre->Hizq==aux){
        aux->padre->Hizq=n;
     }else{
        aux->padre->Hder=n;
     }
     n->padre=aux->padre;
     aux->padre=n;
     if(aux->Hizq!=NULL){
        aux->Hizq->padre=aux;
     }
     if(this->raiz==aux){
        this->raiz=n;
     }
}

void RojiNegro::CargaSupermercados(arbolBin arbolBin){
    string ciudad,nombre;
    int num;
    string supermercado;
    ifstream file;
    file.open("supermercado.txt");
    while(getline(file,supermercado)){
        string::size_type pos = supermercado.find(';');
        string codCiudad=supermercado.substr(0,pos);
        int cod=std::atoi(codCiudad.c_str());
        bool esta=false;
        arbolBin.BuscarCiudad(cod,esta);
        if(esta){
            for(int i=0;i<=2;i++){
                string::size_type pos=supermercado.find(';');
                if(i==0){
                    ciudad=supermercado.substr(0,pos);
                }else if(i==1){
                    num=std::atoi(supermercado.substr(0,pos).c_str());
                }else{
                    nombre=supermercado.substr(0,pos);
                }
                supermercado=supermercado.substr(pos+1);
            }
            Insertar(ciudad,num,nombre);
        }
    }
}

void NodoRN::Buscar(int cod,bool& esta,NodoRN* & aux){
    if(cod==valor){
        esta=true;
    }else if(cod<valor){
        if(Hizq!=nullptr){
            Hizq->Buscar(cod,esta,aux);
        }
    }else{
        if(Hder!=nullptr){
            Hder->Buscar(cod,esta,aux);
        }
    }
}

void RojiNegro::crearListaDeInventarios(){
    ifstream archivo;
    string texto;
    string msg = "";
    int codProducto = 0;
    int codSuper = 0;
    string nombre = "";
    int cantProducto = 0;
    bool esta=false;
    archivo.open("Inventariodatos.txt",ios::in);

    if(archivo.fail()){
        cout<<"No se pudo abrir el archivo";
        exit(1);
    }

    while(getline(archivo,texto)){
        string::size_type pos=texto.find(';');
        codSuper=std::atoi(texto.substr(0,pos).c_str());
        NodoRN* nuevo=raiz;
        raiz->Buscar(codSuper,esta,nuevo);
        if(esta){
            for(int i=0;i<=2;i++){
                string::size_type pos=texto.find(';');
                if(i==0){
                    codSuper=std::atoi(texto.substr(0,pos).c_str());
                }else if(i==1){
                    codProducto=std::atoi(texto.substr(0,pos).c_str());
                }else{
                    nombre=texto.substr(0,pos);
                }
                texto=texto.substr(pos+1);
            }

        nuevo->productos = new ArbolAAInventarios();
        nuevo->productos->insertar(codSuper,codProducto,nombre,cantProducto,atoi(msg.c_str()),nuevo->productos->raiz);
        //cout<<msg<<endl;
        }
    }
    archivo.close();
}
