#include "rojinegro.h"
#include "arbolbin.h"
#include "nodousuario.h"
#include "clave.h"
#include "nodoaa.h"

void RojiNegro::PreordenR(NodoRN *R){
    if(R==NULL){
        return;
    }else{
        if(R->color==1){
            cout<<R->valor<<"("<<"Negro"<<")"<<" - ";
        }else{
            cout<<R->valor<<"("<<"Rojo"<<")"<<" - ";
        }
        PreordenR(R->Hizq);
        PreordenR(R->Hder);
    }
}

void RojiNegro::AnnadirCarrito(listaSimple& user,int tipo, int valor){
    cout<<endl;
    cout<<"                                     Insertar producto a compras"<<endl;
    cout<<endl;
    cout<<endl;
    string codS,codP;
    cout<<"Ingrese el codigo del supermercado: ";
    cin>>codS;
    cout<<"Ingrese el codigo del producto: ";
    cin>>codP;
    bool esta=false,esta2=false,esta3=false,esta4=false;
    NodoRN* nuevo=raiz;
    nuevo->Buscar(atoi(codS.c_str()),esta,raiz,nuevo);
    nodoAAInventarios* y;
    clave x;
    user.primero->abajo->raiz->RetornarUser(valor,tipo,esta4,x);
    x.carrito.Buscar(atoi(codP.c_str()),esta3,y);
    if (esta3==false){
        if(esta){
            nodoAAInventarios* producto=nuevo->productos->raiz;
            nuevo->productos->RetornarV(nuevo->productos->raiz,atoi(codP.c_str()),esta2,producto);
            if(esta2){
                bool listo=true;
                while(listo){
                    string cant;
                    cout<<"Ingrese la cantidad que desea del producto: ";
                    cin>>cant;
                    if(producto->cantidadProducto>=atoi(cant.c_str())){
                        nodoAAInventarios* nuevoP= new nodoAAInventarios(producto->codSuper,producto->codProducto,producto->nombre,atoi(cant.c_str()),producto->precioUnitario);
                        producto->cantidadProducto-=atoi(cant.c_str());
                        listo=false;
                        x.carrito.Insertar(nuevoP);
                        user.primero->abajo->raiz->CambiarCarrito(valor,tipo,x.carrito);
                    }else{
                        bool correct=true;
                        while(correct){
                            string opcionX;
                            cout<<"La cantidad que solicito es mayor a la existente"<<endl;
                            cout<<"Opciones"<<endl;
                            cout<<"1. Desea la cantidad maxima del producto ("+to_string(producto->cantidadProducto)+")"<<endl;
                            cout<<"2. Desea una cantidad menor del producto"<<endl;
                            cout<<"3. No desea agregar el producto al carrito"<<endl;
                            cout<<"Opcion";
                            cin>>opcionX;
                            if(opcionX=="1"){
                                nodoAAInventarios* nuevoP= new nodoAAInventarios(producto->codSuper,producto->codProducto,producto->nombre,producto->cantidadProducto,producto->precioUnitario);
                                producto->cantidadProducto=0;
                                listo=false;
                                x.carrito.Insertar(nuevoP);
                                correct=false;
                                user.primero->abajo->raiz->CambiarCarrito(valor, tipo,x.carrito);
                            }else if(opcionX=="2"){
                                correct=false;
                               cout<<endl;
                            }else if(opcionX=="3"){
                                correct=false;
                                listo=false;
                            }else{
                                cout<<"Ingreso una opcion incorrecta, intentello de nuevo"<<endl;
                                cout<<endl;
                            }
                        }
                    }
                }
            }else{
                cout<<"El producto no esta registrado"<<endl;
            }
        }else{
            cout<<"El supermercado no esta registrado"<<endl;
        }
    }else{
        cout<<"El producto ya se encuentra en el carrito, si desea modificarlo o eliminarlo seleccione la opcion 2 o 3 en el menu"<<endl;
    }
    cout<<endl;
    string opcion;
    bool correcta=true;
    while (correcta){
        cout<<"Desea agregar otro producto al carrito(S/N)"<<endl;
        cin>>opcion;
        if (opcion=="S"){
            AnnadirCarrito(user,tipo,valor);
            correcta=false;

        }else if  (opcion=="N"){
            correcta=false;
        }
        else{
            cout<<"respuesta invalida, intentelo de nuevo"<<endl;
        }
    }
}


void RojiNegro::AumentarCarrito(listaSimple& user,int tipo, int valor){
    cout<<endl;
    cout<<"                                     Aumentar cantidad de producto a compras"<<endl;
    cout<<endl;
    cout<<endl;
    string codS,codP;
    cout<<"Ingrese el codigo del supermercado: ";
    cin>>codS;
    cout<<"Ingrese el codigo del producto: ";
    cin>>codP;
    bool esta=false,esta2=false,esta3=false,esta4=false;
    NodoRN* nuevo=raiz;
    nuevo->Buscar(atoi(codS.c_str()),esta,raiz,nuevo);
    nodoAAInventarios* y;
    clave x;
    user.primero->abajo->raiz->RetornarUser(valor,tipo,esta4,x);
    x.carrito.Buscar(atoi(codP.c_str()),esta3,y);
    if (esta3){
        if(esta){
            nodoAAInventarios* producto=nuevo->productos->raiz;
            nuevo->productos->RetornarV(nuevo->productos->raiz,atoi(codP.c_str()),esta2,producto);
            if(esta2){
                bool listo=true;
                while(listo){
                    string cant;
                    cout<<"Ingrese la cantidad que desea del producto: ";
                    cin>>cant;
                    if(producto->cantidadProducto>=atoi(cant.c_str())){
                        producto->cantidadProducto-=atoi(cant.c_str());
                        listo=false;
                        y->cantidadProducto+=atoi(cant.c_str());
                        user.primero->abajo->raiz->CambiarCarrito(valor,tipo,x.carrito);
                    }else{
                        bool correct=true;
                        while(correct){
                            string opcionX;
                            cout<<"La cantidad que solicito es mayor a la existente"<<endl;
                            cout<<"Opciones"<<endl;
                            cout<<"1. Desea la cantidad maxima del producto ("+to_string(producto->cantidadProducto)+")"<<endl;
                            cout<<"2. Desea una cantidad menor del producto"<<endl;
                            cout<<"3. No desea agregar el producto al carrito"<<endl;
                            cout<<"Opcion";
                            cin>>opcionX;
                            if(opcionX=="1"){
                                producto->cantidadProducto=0;
                                listo=false;
                                y->cantidadProducto+=atoi(cant.c_str());
                                user.primero->abajo->raiz->CambiarCarrito(valor,tipo,x.carrito);
                                listo=false;
                                correct=false;
                            }else if(opcionX=="2"){
                                correct=false;
                               cout<<endl;
                            }else if(opcionX=="3"){
                                correct=false;
                                listo=false;
                            }else{
                                cout<<"Ingreso una opcion incorrecta, intentello de nuevo"<<endl;
                                cout<<endl;
                            }
                        }
                    }
                }
            }else{
                cout<<"El producto no esta registrado"<<endl;
            }
        }else{
            cout<<"El supermercado no esta registrado"<<endl;
        }
    }else{
        cout<<"El producto no se encuentra en el carrito"<<endl;
    }
    cout<<endl;
    string opcion;
    bool correcta=true;
    while (correcta){
        cout<<"Desea agregar otro producto al carrito(S/N)"<<endl;
        cin>>opcion;
        if (opcion=="S"){
            AumentarCarrito(user,tipo,valor);
            correcta=false;

        }else if  (opcion=="N"){
            correcta=false;
        }
        else{
            cout<<"respuesta invalida, intentelo de nuevo"<<endl;
        }
    }
}

void RojiNegro::DisminuirCarrito(listaSimple& user,int tipo, int valor){
    cout<<endl;
    cout<<"                                     Disminuir cantidad de producto a compras"<<endl;
    cout<<endl;
    cout<<endl;
    string codS,codP;
    cout<<"Ingrese el codigo del supermercado: ";
    cin>>codS;
    cout<<"Ingrese el codigo del producto: ";
    cin>>codP;
    bool esta=false,esta2=false,esta3=false,esta4=false;
    NodoRN* nuevo=raiz;
    nuevo->Buscar(atoi(codS.c_str()),esta,raiz,nuevo);
    nodoAAInventarios* y;
    clave x;
    user.primero->abajo->raiz->RetornarUser(valor,tipo,esta4,x);
    x.carrito.Buscar(atoi(codP.c_str()),esta3,y);
    if (esta3){
        if(esta){
            nodoAAInventarios* producto=nuevo->productos->raiz;
            nuevo->productos->RetornarV(nuevo->productos->raiz,atoi(codP.c_str()),esta2,producto);
            if(esta2){
                bool listo=true;
                while(listo){
                    string cant;
                    cout<<"Ingrese la cantidad que desea quitar del producto: ";
                    cin>>cant;
                    if(y->cantidadProducto>atoi(cant.c_str())){
                        producto->cantidadProducto+=atoi(cant.c_str());
                        listo=false;
                        y->cantidadProducto-=atoi(cant.c_str());
                        user.primero->abajo->raiz->CambiarCarrito(valor,tipo,x.carrito);
                    }else if(y->cantidadProducto==atoi(cant.c_str())){
                        x.carrito.Eliminar(atoi(codP.c_str()));
                        producto->cantidadProducto+=atoi(cant.c_str());
                        listo=false;
                    }else{
                        bool correct=true;
                        while(correct){
                            string opcionX;
                            cout<<"La cantidad que solicito es mayor a la existente"<<endl;
                            cout<<"Opciones"<<endl;
                            cout<<"1. Desea quitar la cantidad maxima del producto ("+to_string(producto->cantidadProducto)+")"<<endl;
                            cout<<"2. Desea quitar una cantidad menor del producto"<<endl;
                            cout<<"3. No desea quitar el producto al carrito"<<endl;
                            cout<<"Opcion";
                            cin>>opcionX;
                            if(opcionX=="1"){
                                producto->cantidadProducto+=y->cantidadProducto;
                                x.carrito.Eliminar(atoi(codP.c_str()));
                                listo=false;
                                correct=false;
                                user.primero->abajo->raiz->CambiarCarrito(valor, tipo,x.carrito);
                            }else if(opcionX=="2"){
                                correct=false;
                               cout<<endl;
                            }else if(opcionX=="3"){
                                correct=false;
                                listo=false;
                            }else{
                                cout<<"Ingreso una opcion incorrecta, intentello de nuevo"<<endl;
                                cout<<endl;
                            }
                        }
                    }
                }
            }else{
                cout<<"El producto no esta registrado"<<endl;
            }
        }else{
            cout<<"El supermercado no esta registrado"<<endl;
        }
    }else{
        cout<<"El producto no se encuentra en el carrito"<<endl;
    }
    cout<<endl;
    string opcion;
    bool correcta=true;
    while (correcta){
        cout<<"Desea quitar cantidad de otro producto del carrito(S/N)"<<endl;
        cin>>opcion;
        if (opcion=="S"){
            DisminuirCarrito(user,tipo,valor);
            correcta=false;

        }else if  (opcion=="N"){
            correcta=false;
        }
        else{
            cout<<"respuesta invalida, intentelo de nuevo"<<endl;
        }
    }
}


void RojiNegro::InordenR(NodoRN *R){

    if(R==NULL){
        return;
    }else{
        InordenR(R->Hizq);
        cout<<R->valor<<"("<<R->color<<")"<<" - ";
        InordenR(R->Hder);
    }
}

void RojiNegro::PostordenR(NodoRN *R){

    if(R==NULL){
        return;
    }else{
        PostordenR(R->Hizq);
        PostordenR(R->Hder);
        cout<<R->valor<<"("<<R->color<<")"<<" - ";
    }
}

NodoRN* RojiNegro::Hermano(NodoRN* nodo)
{
    if(nodo==nodo->padre->Hizq){

        return nodo->padre->Hder;
    }else{
        return nodo->padre->Hizq;
    }
}

void RojiNegro::Insertar(string ciudad, int v, string nombre){
    NodoRN* ra=new NodoRN(v,ciudad,nombre);
    NodoRN* y=NULL;
    NodoRN* x=this->raiz;
    bool band=false;
    while(x!=NULL){
        y=x;
        if(y->valor==ra->valor){
            band=true;
        }
        if(ra->valor<x->valor){
            x=x->Hizq;
        }else{
            x=x->Hder;
        }
    }
    ra->padre=y;
    if(y==NULL){
        this->raiz=ra;
    }else{
        if(band==false){
            if(ra->valor<y->valor){
                y->Hizq=ra;
            }else{
                y->Hder=ra;
            }
        }
    }
    ra->Hizq=NULL;
    ra->Hder=NULL;
    ra->color=0;
    if(ra->padre!=NULL and ra->padre->padre!=NULL){
        Arreglar(ra);
    }
    this->raiz->color=1;
}

void RojiNegro::Arreglar(NodoRN* ra){
    NodoRN* y;
    while(ra!=this->raiz and ra->padre!=NULL and ra->padre->padre!=NULL and ra->padre->color==0){
        if(ra->padre==ra->padre->padre->Hder){
            y=ra->padre->padre->Hder;
            if(y!=NULL){
                if(y->color==0){
                    ra->padre->color=1;
                    y->color=1;
                    ra->padre->padre->color=0;
                    ra=ra->padre->padre;
                }else{
                    if(ra==ra->padre->Hder){
                        ra=ra->padre;
                        RotacionIzquierda(ra);
                    }
                    ra->padre->color=1;
                    ra->padre->padre->color=0;
                    RotacionDerecha(ra->padre->padre);

                }
            }else{
                ra->color=1;
                ra->padre->color=0;
                RotacionDerecha(ra->padre);
            }
        }else{
            y=ra->padre->padre->Hizq;
            if(y!=NULL){
                if(y->color==0){
                    ra->padre->color=1;
                    y->color=1;
                    ra->padre->padre->color=0;
                    ra=ra->padre->padre;
                }else{
                    if(ra==ra->padre->Hizq){
                        ra=ra->padre;
                        RotacionDerecha(ra);
                    }
                    ra->padre->color=1;
                    ra->padre->padre->color=0;
                    RotacionIzquierda(ra->padre->padre);
                }
            }else{
                ra->color=1;
                ra->padre->color=0;
                RotacionIzquierda(ra->padre);
            }
        }
    }
}

void RojiNegro::RotacionIzquierda(NodoRN* n){
     NodoRN* aux;
     aux=n;
     n=n->Hder;
     aux->Hder=n->Hizq;
     n->Hizq=aux;
     if(aux->padre->Hizq==aux){
        aux->padre->Hizq=n;
     }else{
        aux->padre->Hder=n;
     }
     n->padre=aux->padre;
     aux->padre=n;
     if(aux->Hder!=NULL){
        aux->Hder->padre=aux;
     }
     if(this->raiz==aux){
        this->raiz=n;
     }
}

void RojiNegro::RotacionDerecha(NodoRN* n){
     NodoRN* aux;
     aux=n;
     n=n->Hizq;
     aux->Hizq=n->Hder;
     n->Hder=aux;
     if(aux->padre->Hizq==aux){
        aux->padre->Hizq=n;
     }else{
        aux->padre->Hder=n;
     }
     n->padre=aux->padre;
     aux->padre=n;
     if(aux->Hizq!=NULL){
        aux->Hizq->padre=aux;
     }
     if(this->raiz==aux){
        this->raiz=n;
     }
}

void RojiNegro::CargaSupermercados(arbolBin arbolBin){
    string ciudad,nombre;
    int num;
    string supermercado;
    ifstream file;
    file.open("supermercado.txt");
    while(getline(file,supermercado)){
        string::size_type pos = supermercado.find(';');
        string codCiudad=supermercado.substr(0,pos);
        int cod=std::atoi(codCiudad.c_str());
        bool esta=false;
        arbolBin.BuscarCiudad(cod,esta);
        if(esta){
            for(int i=0;i<=2;i++){
                string::size_type pos=supermercado.find(';');
                if(i==0){
                    ciudad=supermercado.substr(0,pos);
                }else if(i==1){
                    num=std::atoi(supermercado.substr(0,pos).c_str());
                }else{
                    nombre=supermercado.substr(0,pos);
                }
                supermercado=supermercado.substr(pos+1);
            }
            Insertar(ciudad,num,nombre);
        }
    }
}

void NodoRN::Buscar(int cod,bool& esta,NodoRN* & aux,NodoRN* & V){
    if(cod==valor){
        esta=true;
        V=aux;
    }else if(cod<valor){
        if(Hizq!=nullptr){
            aux->Buscar(cod,esta,aux->Hizq,V);
        }
    }else{
        if(Hder!=nullptr){
            aux->Buscar(cod,esta,aux->Hder,V);
        }
    }
}

void RojiNegro::crearListaDeInventarios(){
    ifstream archivo;
    string texto;
    string msg = "";
    int codProducto = 0;
    int codSuper = 0;
    string nombre = "";
    int cantProducto = 0;
    int precio;
    bool esta=false;
    archivo.open("Inventariodatos.txt");
    if(archivo.fail()){
        cout<<"No se pudo abrir el archivo";
        exit(1);
    }
    while(getline(archivo,texto)){
        esta=false;
        string::size_type pos=texto.find(';');
        codSuper=std::atoi(texto.substr(0,pos).c_str());
        NodoRN* nuevo=raiz;
        nuevo->Buscar(codSuper,esta,raiz,nuevo);
        if(esta){
            for(int i=0;i<=4;i++){
                string::size_type pos=texto.find(';');
                if(i==0){
                    codSuper=std::atoi(texto.substr(0,pos).c_str());
                }else if(i==1){
                    codProducto=std::atoi(texto.substr(0,pos).c_str());
                }else if(i==2){
                    nombre=texto.substr(0,pos);
                }else if(i==3){
                    cantProducto=std::atoi(texto.substr(0,pos).c_str());
                }else{
                    precio=std::atoi(texto.substr(0,pos).c_str());
                }
                texto=texto.substr(pos+1);
            }
            nuevo->productos->insertar(codSuper,codProducto,nombre,cantProducto,precio,nuevo->productos->raiz);
        }
    }
    archivo.close();
}

void RojiNegro::ConsultarPrecio(){
    NodoRN* nuevo=raiz;
    bool esta=false;
    string codS,codP,respuesta;
    cout<<endl;
    cout<<"                                             Consultar Precio"<<endl;
    cout<<endl;
    cout<<"Ingrese el codigo del supermercado: ";
    cin>>codS;
    cout<<endl;
    cout<<"Ingrese el codigo del producto: ";
    cin>>codP;
    cout<<endl;
    nuevo->Buscar(atoi(codS.c_str()),esta,raiz,nuevo);
    if(esta){
        nodoAAInventarios* productoN= nuevo->productos->raiz;
        esta=false;
        productoN->Buscar(atoi(codP.c_str()),esta,productoN);
        if(esta){
            cout<<"precio: "<<productoN->precioUnitario<<endl;
        }else{
            cout<<"No se encuentra el producto, por favor intentelo de nuevo"<<endl;
        }
    }else{
        cout<<"No se encuentra el producto, por favor intentelo de nuevo"<<endl;

    }
    cout<<endl;

    bool correcta=true;
    while (correcta){
        cout<<"Desea consultar otro producto(S/N): ";
        cin>>respuesta;
        if (respuesta=="S"){
            ConsultarPrecio();
            correcta=false;

        }else if  (respuesta=="N"){
            correcta=false;
        }
        else{
            cout<<"respuesta invalida, intentelo de nuevo"<<endl;
        }
    }

}

void RojiNegro::ConsultarProducto(){
    NodoRN* nuevo=raiz;
    bool esta=false;
    string respuesta,pCodSuper;
    cout<<endl;
    cout<<"                                             Consultar Productos"<<endl;
    cout<<endl;
    cout<<"Ingrese el supermercado: ";
    cin>>pCodSuper;
    cout<<endl;
    nuevo->Buscar(atoi(pCodSuper.c_str()),esta,raiz,nuevo);
    if(esta){
        ArbolAAInventarios* productoN= nuevo->productos;
        productoN->Consulta(productoN->raiz);
        }
    else{
        cout<<"El super no existe, intentelo de nuevo por favor"<<endl;
    }
    cout<<endl;
    bool correcta=true;
    while (correcta){
        cout<<"Desea consultar otro supermercado(S/N): ";
        cin>>respuesta;
        if (respuesta=="S"){
            ConsultarPrecio();
            correcta=false;
        }else if  (respuesta=="N"){
            correcta=false;
        }
        else{
            cout<<"respuesta invalida, intentelo de nuevo"<<endl;
            cout<<endl;
        }
    }
}

void RojiNegro::InsertarNuevoProducto(nodoAAInventarios* & ultimo,nodoAAInventarios* & penultimo){
    string codProducto,codSuper,cantProducto,precio;
    string nombre;
    cout<<endl;
    cout<<"                                             Ingresar Producto";
    cout<<endl;
    cout<<endl;
    cout<<"Ingrese el codigo del super: ";
    cin>>codSuper;
    cout<<"Ingrese el codigo del producto: ";
    cin>>codProducto;
    cout<<"Ingrese el nombre del producto: ";
    cin.ignore();
    getline(cin, nombre);
    cout<<endl;
    cout<<"Ingrese la cantidad del producto: ";
    cin>>cantProducto;
    cout<<"Ingrese el precio del producto: ";
    cin>>precio;
    bool esta=false,esta2=false;
    NodoRN* nuevo=raiz;
    nuevo->Buscar(atoi(codSuper.c_str()),esta,raiz,nuevo);
    if (esta){
        nuevo->productos->BuscarV(nuevo->productos->raiz,atoi(codProducto.c_str()),esta2);
        if(not esta2){
            nodoAAInventarios* y=new nodoAAInventarios(atoi(codSuper.c_str()),atoi(codProducto.c_str()),nombre,atoi(cantProducto.c_str()),atoi(precio.c_str()));
            penultimo=ultimo;
            ultimo=y;
            nuevo->productos->insertar(atoi(codSuper.c_str()),atoi(codProducto.c_str()),nombre,atoi(cantProducto.c_str()),atoi(precio.c_str()),nuevo->productos->raiz);
        }else{
            cout<<"El producto ya esta registrado"<<endl;
        }
    }else{
        cout<<"El supermercado no esta registrado"<<endl;
    }
}

void ArbolAAInventarios::RetornarV(nodoAAInventarios*&R,int pValor,bool& esta,nodoAAInventarios* & y){
    if(R==nullptr){
        return;
    }else if(R->codProducto==pValor){
        esta=true;
        y=R;
    }else{
        if(R->Hizq!=nullptr){
            RetornarV(R->Hizq, pValor, esta,y);
        }else if(R->Hder){
            RetornarV(R->Hder, pValor, esta,y);
        }
    }
}


void ArbolAAInventarios::BuscarV(nodoAAInventarios* & R,int pValor,bool& esta){
    if(R==nullptr){
        return;
    }else if(R->codProducto==pValor){
        esta=true;
    }else{
        BuscarV(R->Hizq, pValor, esta);
        BuscarV(R->Hder, pValor,esta);
    }
}

void ArbolAAInventarios::ModificarV(nodoAAInventarios*& R,int pValor,bool& esta,nodoAAInventarios* L){
    if(R==nullptr){
        return;
    }else if(R->codProducto==pValor){
        esta=true;
        R=L;
    }else{
        if(R->Hizq!=nullptr){
            ModificarV(R->Hizq, pValor, esta,L);
        }else if(R->Hder){
            ModificarV(R->Hder, pValor, esta,L);
        }
    }
}



void RojiNegro::ModificarProducto(nodoAAInventarios*& modificado){
    string codProducto,codSuper,cantProducto,precio;
    string nombre;
    cout<<endl;
    cout<<"                                             Modificar Producto";
    cout<<endl;
    cout<<endl;
    cout<<"Ingrese el codigo del super: ";
    cin>>codSuper;
    cout<<"Ingrese el codigo del producto: ";
    cin>>codProducto;

    bool esta=false,esta2=false;
    NodoRN* nuevo=raiz;
    nuevo->Buscar(atoi(codSuper.c_str()),esta,raiz,nuevo);
    InordenR(raiz);
    if (esta){
        nodoAAInventarios* V=nuevo->productos->raiz;
        nuevo->productos->InordenR(V);
        nuevo->productos->RetornarV(V,atoi(codProducto.c_str()),esta2,V);

        if(esta2){
            cout<<"Opciones de Modificación"<<endl;
            cout<<"1. El nombre del articulo"<<endl;
            cout<<"2. La cantidad del producto"<<endl;
            cout<<"3. El precio del producto"<<endl;
            cout<<"Opcion:";
            string opcion;
            cin>>opcion;
            if(opcion=="1"){
                cout<<"Ingrese el nombre del producto: ";
                cin.ignore();
                getline(cin, nombre);
                V->nombre=nombre;
            }else if(opcion=="2"){
                cout<<"Ingrese la cantidad del producto: ";
                cin>>cantProducto;
                V->cantidadProducto=atoi(cantProducto.c_str());
            }else if(opcion=="3"){
                cout<<"Ingrese el precio del producto: ";
                cin>>precio;
                V->codProducto=atoi(precio.c_str());
            }
            modificado=V;
        }else{
            cout<<"El producto no esta registrado"<<endl;
        }
    }else{
        cout<<"El supermercado no esta registrado"<<endl;
    }
}
