#include "nodousuario.h"

NodoUsuario::NodoUsuario(){

}
