#ifndef _NODOAA_H
#define	_NODOAA_H

#include <iostream>
using namespace std;


class nodoAAInventarios{
   public:
    nodoAAInventarios(int pCodSuper, int pCodProducto, string pNombre, int pCantidadProducto, int pPrecioUnitario)
    {
       codSuper = pCodSuper;
       codProducto = pCodProducto;
       nombre = pNombre;
       cantidadProducto = pCantidadProducto;
       precioUnitario = pPrecioUnitario;
       nivel = 1;
       Hizq = nullptr;
       Hder = nullptr;
    }
    nodoAAInventarios *Torsion();
    void Buscar(int cod,bool& esta,nodoAAInventarios* & aux);
    void Buscar(int cod,bool& esta);
    nodoAAInventarios *division();
    int codSuper;
    int codProducto;
    string nombre;
    int cantidadProducto;
    int precioUnitario;
    int nivel;
    nodoAAInventarios *Hizq;
    nodoAAInventarios *Hder;
   friend class ArbolAA;
   friend class listaCarrito;
};

typedef nodoAAInventarios *pnodoAAInventarios;

void InordenR(nodoAAInventarios *R);
pnodoAAInventarios torsion(nodoAAInventarios *T);
pnodoAAInventarios division(nodoAAInventarios *T);

#endif // _NODOAA_H
