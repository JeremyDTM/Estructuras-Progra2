#ifndef CLAVE_H
#define CLAVE_H

#include <iostream>
#include <string>
#include "listacarrito.h"

using namespace std;

class clave{
    public:
        clave();
    private:
        int tipo;
        int valor;
        string codCiudad;
        string nombre;
        string telefono;
        int facturas=0;
        listaCarrito carrito;

    friend class Pagina;
    friend class ArbolB;
    friend class RojiNegro;
};
    typedef clave* pclave;

#endif // CLAVE_H
