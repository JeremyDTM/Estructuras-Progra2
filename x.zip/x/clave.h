#ifndef CLAVE_H
#define CLAVE_H

#include <iostream>
#include <string>

using namespace std;

class clave{
    public:
        clave();
    private:
        int tipo;
        int valor;
        string codCiudad;
        string nombre;
        string telefono;
    friend class Pagina;
    friend class ArbolB;
};

#endif // CLAVE_H
