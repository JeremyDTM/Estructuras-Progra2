#include "arbolb.h"
#include <iostream>
#include "pagina.h"
#include <string>

using namespace std;

ArbolB::ArbolB(){
}

bool ArbolB::ArbolVacio(pPagina pRaiz){
    bool vacio=true;
    if(pRaiz->getCuentas()!=0){
        return vacio=false;
    }else{
        return vacio;
    }
}




void ArbolB::MostrarRaiz(){
    raiz->Mostrar();
}

void Pagina::Mostrar(){
    int m=cuentas;
    if(ramas[0]!=nullptr){
        ramas[0]->Mostrar();
    }
    if (claves[0].valor!=NULL &&m>0){
        cout<<to_string(claves[0].valor)+":->";
        m--;
    }

    if(ramas[1]!=nullptr){
        ramas[1]->Mostrar();
    }
    if (claves[1].valor!=NULL&&m>0){
        cout<<to_string(claves[1].valor)+"::->";
        m--;
    }
    if(ramas[2]!=nullptr){
        ramas[2]->Mostrar();
    }
    if (claves[2].valor!=NULL&&m>0){
        cout<<to_string(claves[2].valor)+":::->";
        m--;
    }
    if(ramas[3]!=nullptr){
        ramas[3]->Mostrar();
    }
    if (claves[3].valor!=NULL&&m>0){
        cout<<to_string(claves[3].valor)+"::::->";

    }
    if(ramas[4]!=nullptr){
        ramas[4]->Mostrar();
    }
}

void ArbolB::InsertarValor(string pValor){
    bool EA=false;
    string X="0";
    pPagina Xr=nullptr;
    pPagina P=nullptr;
    Empujar(pValor,raiz,EA,X,Xr);
    if (EA){
        P=new Pagina();
        P->cuentas=1;
        for(int m=0; m<=4;m++){
            string::size_type pos=X.find(';');
            if(m==0){
                P->claves[0].codCiudad=X.substr(0,pos);
            }else if(m==1){
                P->claves[0].valor=std::atoi(X.substr(0,pos).c_str());
            }else if(m==2){
                P->claves[0].nombre=X.substr(0,pos);
            }else if(m==3){
                P->claves[0].telefono=X.substr(0,pos);
            }else{
                P->claves[0].tipo=std::atoi(X.substr(0,pos).c_str());
            }
            X=X.substr(pos+1);
        }
        P->ramas[0]=raiz;
        P->ramas[1]=Xr;
        raiz=P;
    }
}

void ArbolB::Empujar(string& pValor,pPagina& pRaiz,bool& EA,string& mdna,pPagina& x){
    int k=0;
    bool esta=false;
    if(ArbolVacio(pRaiz)){
        EA=true;
        mdna=pValor;
        x=new Pagina();
    }else{
        BuscarNodo(pValor,pRaiz,esta,k);
        if (esta==true){
        }else{
            Empujar(pValor,pRaiz->ramas[k],EA,mdna,x);
            if(EA){
                if (pRaiz->cuentas<4){
                    EA=false;
                    MeterHoja(mdna,x,pRaiz,k);
                }else{
                    EA=true;
                    DividirNodo(mdna,x,pRaiz,k,mdna,x);
                }
            }
        }
    }
}

void ArbolB::BuscarNodo(string& pValor,pPagina& pRaiz,bool& esta,int& k){
    string codUsuario;
    string::size_type pos = pValor.find(';');
    codUsuario=pValor.substr(pos+1);
    string::size_type pos1=codUsuario.find(';');
    codUsuario=codUsuario.substr(0,pos1);
    if(std::atoi(codUsuario.c_str())==pRaiz->claves[0].valor){
        esta=true;
    }

    if(std::atoi(codUsuario.c_str())<pRaiz->claves[0].valor){
        esta=false;
        k=0;
    }else{
        k=pRaiz->cuentas;
        while(std::atoi(codUsuario.c_str())<pRaiz->claves[k-1].valor&&k>0){
            k=k-1;
        }
        if (k!=4){
            if (atoi(codUsuario.c_str())==pRaiz->claves[1].valor){
                esta=true;
            }
        }
    }
}

void Pagina::RetornarUser(int pValor,int pTipo,bool& esta,clave& x){
    int m=cuentas;
    if(ramas[0]!=nullptr){
        ramas[0]->RetornarUser(pValor,pTipo,esta,x);
    }
    if (claves[0].valor!=NULL &&m>0){
        m--;
        if(pTipo==claves[0].tipo&&pValor==claves[0].valor){
            esta=true;
            x=claves[0];
            cout<<"arroz"<<endl;
        }
    }

    if(ramas[1]!=nullptr){
        ramas[1]->BuscarUser(pValor,pTipo,esta);
    }
    if (claves[1].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[1].tipo&&pValor==claves[1].valor){
            esta=true;
            x=claves[1];
            cout<<"arroz"<<endl;
        }
    }
    if(ramas[2]!=nullptr){
        ramas[2]->RetornarUser(pValor,pTipo,esta,x);
    }
    if (claves[2].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[2].tipo&&pValor==claves[2].valor){
            esta=true;
            x=claves[2];
            cout<<"arroz"<<endl;
        }
    }
    if(ramas[3]!=nullptr){
        ramas[3]->RetornarUser(pValor,pTipo,esta,x);
    }
    if (claves[3].valor!=NULL&&m>0){
        if(pTipo==claves[3].tipo&&pValor==claves[3].valor){
            esta=true;
            x=claves[3];
            cout<<"arroz"<<endl;
        }

    }
    if(ramas[4]!=nullptr){
        ramas[4]->RetornarUser(pValor,pTipo,esta,x);
    }
}

void Pagina::CambiarCarrito(int pValor,int pTipo,listaCarrito y){

    int m=cuentas;
    if(ramas[0]!=nullptr){
        ramas[0]->CambiarCarrito(pValor,pTipo,y);
    }
    if (claves[0].valor!=NULL &&m>0){
        m--;
        if(pTipo==claves[0].tipo&&pValor==claves[0].valor){
            claves[0].carrito=y;
            cout<<claves[0].telefono;

        }
    }
    if(ramas[1]!=nullptr){
        ramas[1]->CambiarCarrito(pValor,pTipo,y);
    }
    if (claves[1].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[1].tipo&&pValor==claves[1].valor){
            claves[1].carrito=y;
            cout<<"hola"<<endl;
        }
    }
    if(ramas[2]!=nullptr){
        ramas[2]->CambiarCarrito(pValor,pTipo,y);
    }
    if (claves[2].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[2].tipo&&pValor==claves[2].valor){
            claves[2].carrito=y;
            cout<<"hola"<<endl;
        }
    }
    if(ramas[3]!=nullptr){
        ramas[3]->CambiarCarrito(pValor,pTipo,y);
    }
    if (claves[3].valor!=NULL&&m>0){
        if(pTipo==claves[3].tipo&&pValor==claves[3].valor){
            claves[3].carrito=y;
            cout<<"hola"<<endl;
        }

    }
    if(ramas[4]!=nullptr){
        ramas[4]->CambiarCarrito(pValor,pTipo,y);
    }
}


void Pagina::BuscarUser(int pValor,int pTipo,bool& esta){
    int m=cuentas;
    if(ramas[0]!=nullptr){
        ramas[0]->BuscarUser(pValor,pTipo,esta);
    }
    if (claves[0].valor!=NULL &&m>0){
        m--;
        if(pTipo==claves[0].tipo&&pValor==claves[0].valor){
            esta=true;
        }
    }

    if(ramas[1]!=nullptr){
        ramas[1]->BuscarUser(pValor,pTipo,esta);
    }
    if (claves[1].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[1].tipo&&pValor==claves[1].valor){
            esta=true;
        }
    }
    if(ramas[2]!=nullptr){
        ramas[2]->BuscarUser(pValor,pTipo,esta);
    }
    if (claves[2].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[2].tipo&&pValor==claves[2].valor){
            esta=true;
        }
    }
    if(ramas[3]!=nullptr){
        ramas[3]->BuscarUser(pValor,pTipo,esta);
    }
    if (claves[3].valor!=NULL&&m>0){
        if(pTipo==claves[3].tipo&&pValor==claves[3].valor){
            esta=true;
        }

    }
    if(ramas[4]!=nullptr){
        ramas[4]->BuscarUser(pValor,pTipo,esta);
    }
}


int Pagina::Descuento(int pValor,int pTipo){
    int m=cuentas;
    if(ramas[0]!=nullptr){
        ramas[0]->Descuento(pValor,pTipo);
    }
    if (claves[0].valor!=NULL &&m>0){
        m--;
        if(pTipo==claves[0].tipo&&pValor==claves[0].valor){
            return claves[0].facturas;
        }
    }

    if(ramas[1]!=nullptr){
        ramas[1]->Descuento(pValor,pTipo);
    }
    if (claves[1].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[1].tipo&&pValor==claves[1].valor){
            return claves[1].facturas;
        }
    }
    if(ramas[2]!=nullptr){
        ramas[2]->Descuento(pValor,pTipo);
    }
    if (claves[2].valor!=NULL&&m>0){
        m--;
        if(pTipo==claves[2].tipo&&pValor==claves[2].valor){
            return claves[2].facturas;
        }
    }
    if(ramas[3]!=nullptr){
        ramas[3]->Descuento(pValor,pTipo);
    }
    if (claves[3].valor!=NULL&&m>0){
        if(pTipo==claves[3].tipo&&pValor==claves[3].valor){
            return claves[3].facturas;
        }

    }
    if(ramas[4]!=nullptr){
        ramas[4]->Descuento(pValor,pTipo);
    }
}

void ArbolB::MeterHoja(string& pValor,pPagina& x,pPagina& pRaiz,int& k){
    int i=pRaiz->cuentas-1;
    for(i;k<=i;i--){
        pRaiz->claves[i+1]=pRaiz->claves[i];
        pRaiz->ramas[i+2]=pRaiz->ramas[i+1];
        pRaiz->ramas[i+1]=pRaiz->ramas[i];
    }
    for(int m=0; m<=4;m++){
        string::size_type pos=pValor.find(';');
        if(m==0){
            pRaiz->claves[k].codCiudad=pValor.substr(0,pos);
        }else if(m==1){
            pRaiz->claves[k].valor=std::atoi(pValor.substr(0,pos).c_str());
        }else if(m==2){
            pRaiz->claves[k].nombre=pValor.substr(0,pos);
        }else if(m==3){
            pRaiz->claves[k].telefono=pValor.substr(0,pos);
        }else{
            pRaiz->claves[k].tipo=std::atoi(pValor.substr(0,pos).c_str());
        }
        pValor=pValor.substr(pos+1);
    }
    if(i==pRaiz->cuentas-1||i==-1){
       pRaiz->ramas[k+1]=x;
    }else{
       pRaiz->ramas[k]=x;
    }
    pRaiz->cuentas=pRaiz->cuentas+1;
}

void ArbolB::DividirNodo(string& pValor,pPagina Xder,pPagina& pRaiz,int& k,string& mda,pPagina& mder){
    int i;
    int posmda;
    if(k<=2){
        posmda=2;
    }else{
        posmda=3;
    }
    mder= new Pagina();

    for(i=posmda;i<4;i++){
        mder->claves[i-posmda]=pRaiz->claves[i];
        mder->ramas[i+1-posmda]=pRaiz->ramas[i+1];
        mder->ramas[i-posmda]=pRaiz->ramas[i];
    }
    mder->cuentas = 4-posmda;
    pRaiz->cuentas=posmda;

    if (k<=2){
       MeterHoja (pValor,Xder,pRaiz,k);

    }else{
        int y=k-posmda;
        MeterHoja (pValor,Xder,mder,y);
    }
    mda=pRaiz->claves[pRaiz->cuentas-1].codCiudad+";"+to_string(pRaiz->claves[pRaiz->cuentas-1].valor)+";"+pRaiz->claves[pRaiz->cuentas-1].nombre+";"+pRaiz->claves[pRaiz->cuentas-1].telefono+";"+to_string(pRaiz->claves[pRaiz->cuentas-1].tipo);
    mder->ramas[0]=pRaiz->ramas[pRaiz->cuentas];
    pRaiz->cuentas=pRaiz->cuentas-1;
}
