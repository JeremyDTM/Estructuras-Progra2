#include "listacarrito.h"

listaCarrito::listaCarrito(){

}

void listaCarrito:: Insertar(nodoAAInventarios* producto){
    if (primero==nullptr){
        primero=producto;
    }else{
       nodoAAInventarios* aux=primero;
       while (aux->Hder!=nullptr){
           aux=aux->Hder;
       }
       aux->Hder=producto;
    }
}


void listaCarrito::Eliminar(int codigo){
    nodoAAInventarios* aux=primero;
    bool esta=false;
    if(primero->codProducto==codigo){
        primero=primero->Hder;
        delete aux;
    }else{
        while (aux->Hder!=nullptr && esta==false){
            if (aux->Hder->codProducto==codigo){
                esta=true;
            }else{
                aux=aux->Hder;
            }
        }
        if(esta){
            nodoAAInventarios* temp=aux->Hder;
            aux->Hder=aux->Hder->Hder;
            delete temp;
        }
    }
}

void listaCarrito::Buscar(int codigo,bool& esta,nodoAAInventarios*& y){
    nodoAAInventarios* aux=primero;
    while (aux!=nullptr && esta==false){
        if (aux->codProducto==codigo){
            esta=true;
            y=aux;
        }else{
            aux=aux->Hder;
        }
    }
}

void listaCarrito::Mostrar(){
    if(primero==nullptr){
        cout<<"El carrito esta vacio"<<endl;
    }else{
        nodoAAInventarios* aux=primero;
        while(aux!=nullptr){
            cout<<aux->nombre<<","<<aux->cantidadProducto<<"-"<<endl;
            aux=aux->Hder;
        }
    }

}
