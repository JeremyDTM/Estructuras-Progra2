#ifndef PAGINA_H
#define PAGINA_H
#include <string>
#include <iostream>
#include "clave.h"

using namespace std;

class Pagina{
    public:
        Pagina();
        void Mostrar();
        string * getClaves();
        void annadirRamas(int posicion,Pagina *pagina);
        int getCuentas();
        void setCuentas(int pCuentas);
        void RetornarUser(int pValor,int pTipo,bool& esta,clave& x);
        void annadirClaves(int posicion,string valor);
        void BuscarUser(int pValor,int pTipo,bool& esta);
        int Descuento(int pValor,int pTipo);
        void CambiarCarrito(int pValor,int pTipo,listaCarrito y);
    private:
        clave claves[4];
        int max=4;
        int min=2;
        Pagina *ramas[5]={nullptr};
        int cuentas=0,factorBalance=0;
    friend class ArbolB;
    friend class listaSimple;
    friend class RojiNegro;
};
typedef  Pagina *pPagina;

#endif // PAGINA_H
