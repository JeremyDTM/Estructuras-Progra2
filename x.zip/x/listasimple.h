#ifndef LISTASIMPLE_H
#define LISTASIMPLE_H
#include "nodosimple.h"
#include "arbolbin.h"

class listaSimple
{
    public:
        listaSimple();
        void Insertar(int num, ArbolB* arbolB);
        void Insertar(int num, AVL* arbolAVL);
        void users(arbolBin arbolBin);
        void Mostrar();
        bool BuscarUsuario(int tipo, int cedula);
        void Descuento(int tipo, int cedula);
        nodoSimple* primero=nullptr;
        void RetornarUsuario(int pValor,int pTipo,bool& esta,clave& x);
};

#endif // LISTASIMPLE_H
