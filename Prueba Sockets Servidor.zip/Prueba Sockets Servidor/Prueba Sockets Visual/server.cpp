#include "pch.h"
#include <iostream>

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>

using namespace std;

int main()
{
	cout<<"\t\t-------TCP SERVER-------------"<<endl;
	cout<<endl;
	WSADATA Winsockdata;
	int iWsaStartup;
	int iWsaCleanup;
	
	SOCKET TCPServerSocket;
	int iCloseSocket;
	
	struct sockaddr_in TCPServerAdd;
	struct sockaddr_in TCPClientAdd;
	int iTCPClientAdd = sizeof(TCPClientAdd);

	int iBind;
	
	int iListen;
	
	SOCKET sAcceptSocket;
	
	int iSend;
	char SenderBuffer[512] = "Hello from Server!";
	int iSenderBuffer = strlen(SenderBuffer)+1;
	
	int iRecv;
	char RecvBuffer[512];
	int iRecvBuffer = strlen(RecvBuffer)+1;
	
	iWsaStartup = WSAStartup(MAKEWORD(2,2),&Winsockdata);
	if(iWsaStartup!=0){
		cout<<"WSAStartUp Failed"<<endl;
	}
	cout<<"WSAStartUp Success"<<endl;
	
	TCPServerAdd.sin_family = AF_INET;
	TCPServerAdd.sin_addr.s_addr = inet_addr("127.0.0.1");
	TCPServerAdd.sin_port = htons(8000);
	
	TCPServerSocket = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(TCPServerSocket == INVALID_SOCKET){
		cout<<"TCP Server Socket creation failed"<<WSAGetLastError()<<endl;
	}
	cout<<"TCP Server Socket creation success"<<endl;
	
	iBind = bind(TCPServerSocket,(SOCKADDR*)&TCPServerAdd,sizeof(TCPServerAdd));
	if(iBind == SOCKET_ERROR){
		cout<<"Binding failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Binding success"<<endl;
	iListen = listen(TCPServerSocket,2);
	if(iListen == SOCKET_ERROR){
		cout<<"Listen func failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Listen func success"<<endl;
	
	sAcceptSocket = accept(TCPServerSocket,(SOCKADDR*)&TCPClientAdd,&iTCPClientAdd);
	if(sAcceptSocket == INVALID_SOCKET){
		cout<<"Accept failed & Error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"connection accepted"<<endl;
	
	iSend = send(sAcceptSocket,SenderBuffer,iSenderBuffer,0);
	if(iSend == SOCKET_ERROR){
		cout<<"Sending failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Data sending success"<<endl;
	
	iRecv = recv(sAcceptSocket,RecvBuffer,iRecvBuffer,0);
	if(iRecv == SOCKET_ERROR){
		cout<<"Receive data failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Data received->"<<RecvBuffer<<endl;
	
	iCloseSocket = closesocket(TCPServerSocket);
	if(iCloseSocket == SOCKET_ERROR){
		cout<<"Closing socket failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"Closing socket success"<<endl;
	
	iWsaCleanup = WSACleanup();
	if(iWsaCleanup == SOCKET_ERROR){
		cout<<"CleanUp func failed & error No->"<<WSAGetLastError()<<endl;
	}
	cout<<"CleanUp func success"<<endl;
	
	system("PAUSE");
	return 0;
}
