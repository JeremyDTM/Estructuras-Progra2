
#include "ArbolAA.h"
#include "nodoAA.h"

using namespace std;


void ArbolAA::InsertaNodo(int num){
	if(raiz==NULL){
        raiz = new nodoAA(num);
    }else{
        raiz->InsertarNodoAA(num);
    }
}

void nodoAA::InsertarNodoAA(int num){
	if(num<valor){
        if(Hizq==NULL){
            Hizq = new nodoAA(num);
        }else{
            Hizq->InsertarNodoAA(num);
            //Aqui deberia ir el metodo torsion
        }
    }else{
        if(Hder==NULL){
            Hder = new nodoAA(num);
        }else{
            Hder->InsertarNodoAA(num);
            //Aqui deberia ir el metodo division
        }
    }
}

void InordenR(nodoAA *R){

    if(R==NULL){
        return;
    }else{
        InordenR(R->Hizq);
        cout<<R->valor<<" - ";
        InordenR(R->Hder);
    }
}

pnodoAA torsion(nodoAA *T){
	if(T == NULL){
		return NULL;
	}
	else if(T->Hizq->nivel == T->nivel){
		pnodoAA L;
		L = T->Hizq;
		T->Hizq = L->Hder;
		L->Hder;
		return L;
	}
	else{
		return T;
	}
}

pnodoAA division(nodoAA *T){
	if(T == NULL){
		return NULL;
	}
	else if(T->Hder->Hder == NULL){
		return T;
	}
	else if(T->nivel == T->Hder->Hder->nivel){
		pnodoAA R;
		R = T->Hder;
		T->Hder = R->Hizq;
		R->Hizq = T;
		R->nivel = R->nivel + 1;
		return R;
	}
	else{
		return T;
	}
}

/*
pnodoAA nodoAA::Torsion(){
	if(raiz == NULL){
		return NULL;
	}
	else if(Hizq->nivel = nivel){
		pnodoAA L;
		L = Hizq;
		Hizq = L->Hder;
		L->Hder = raiz;
		return L;
	}
	else{
		return raiz;
	}
}
*/


/*
void ArbolAA::InsertaNodo2(int num){
	if (raiz == NULL){
		raiz = new nodoAA(num);
		cout<<raiz->valor<<endl;
	}
	else if(num <= raiz->valor){
	    if(raiz->Hizq ==  NULL){
	    	pnodoAA aux = new nodoAA(num);
	    	raiz->anterior = aux;
	    	aux->siguiente = raiz;
	    	raiz = aux;
	    	cout<<raiz->valor<<endl;
	    	cout<<raiz->siguiente->valor<<endl;
	    	aux = NULL;
	    	delete aux;
		}
	}
	else if(num > raiz->valor){
		if(raiz->Hder == NULL){
			pnodoAA aux = raiz;
			while(aux->siguiente != NULL){
				aux = aux->siguiente;
			}
			aux->siguiente = new nodoAA(num);
		}
	}	
}

void ArbolAA::InsertaNodo(int num){
    if (raiz == NULL){
		raiz = new nodoAA(num);
		cout<<raiz->valor<<endl;
    }
    else if(num <= raiz->valor){
    	if(raiz->Hizq == NULL){
    		raiz->anterior = new nodoAA(num);
    		raiz->anterior->siguiente = raiz;
    		raiz = raiz->anterior;
    		cout<<raiz->valor<<endl;
	    	cout<<raiz->siguiente->valor<<endl;
		}
	}
	else if(num > raiz->valor){
		if(raiz->Hder == NULL){
			pnodoAA aux = raiz;
			while(aux->siguiente != NULL){
				aux = aux->siguiente;
			}
			aux->siguiente = new nodoAA(num);
			cout<<raiz->siguiente<<endl;
		}
	}
	if(largo(raiz) >= 3){
		raiz->siguiente->Hizq = raiz;
		raiz->siguiente = raiz;
		raiz->Hder = raiz->siguiente;
	}
}

int ArbolAA::largo(pnodoAA nodoRaiz){
	pnodoAA aux = nodoRaiz;
	int cont = 0;
	while(aux != NULL){
		aux = aux->siguiente;
		cont++;
	}
	return cont;
}*/

