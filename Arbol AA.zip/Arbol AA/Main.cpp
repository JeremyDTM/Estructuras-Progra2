#include <stdlib.h>
#include <iostream>

#include "ArbolAA.h"
#include "nodoAA.h"
#include "ArbolAA.cpp"

using namespace std;

int main(){
    ArbolAA aux1;
    aux1.InsertaNodo(15);
    aux1.InsertaNodo(10);
    aux1.InsertaNodo(8);
    aux1.InsertaNodo(6);
    aux1.InsertaNodo(12);
    
    InordenR(aux1.raiz);
    return 0;
}
